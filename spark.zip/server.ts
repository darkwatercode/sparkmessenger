import 'dotenv/config';
import http from 'node:http';
import path from 'node:path';
import express from 'express';
import { eq } from 'drizzle-orm';
import { createServer as createViteServer } from 'vite';
import { WebSocket, WebSocketServer } from 'ws';
import { GIFTS_CATALOG } from './src/data/giftsCatalog.ts';
import { db } from './src/db/index.ts';
import { presence, userSettings, users } from './src/db/schema.ts';
import {
  clearSessionCookie,
  createSessionForUser,
  ensureUserAuxRows,
  extractSessionToken,
  hashPassword,
  parseCookies,
  requireAuth,
  resolveSessionUserId,
  revokeSessionToken,
  SESSION_COOKIE_NAME,
  setSessionCookie,
  verifyPassword,
  type AuthedRequest,
} from './src/server/auth.ts';
import {
  createConversationMessage,
  createFriendRequest,
  expireStalePresenceRows,
  getAuthUserById,
  getFriendUserIds,
  getFriendsAndRequests,
  getOrCreateDirectConversation,
  getPublicUserProfile,
  listConversationMessages,
  listConversationsForUser,
  listOwnedGiftsForUser,
  markConversationAsRead,
  purchaseCatalogGift,
  removeFriendship,
  respondFriendRequest,
  searchUsers,
  sendCatalogGiftToUser,
  setPresenceOffline,
  setPresenceOnline,
  touchPresenceHeartbeat,
  upgradeUserGift,
} from './src/server/queries.ts';
import type { EquippedAccessoriesMap } from './src/types/spark.ts';
import {
  computeEffectivePresence,
  pickAvatarColor,
  STALE_PRESENCE_MS,
  USERNAME_NOT_FOUND_ERROR,
  USERNAME_TAKEN_ERROR,
  validateLoginInput,
  validateRegistrationInput,
} from './src/utils/sparkLogic.ts';

interface TrackedSocket {
  ws: WebSocket;
  userId: number;
  sessionToken: string;
  isAlive: boolean;
}

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '4mb' }));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  const socketsByUser = new Map<number, Set<TrackedSocket>>();

  function sendToUser(userId: number, payload: Record<string, unknown>) {
    const set = socketsByUser.get(userId);
    if (!set || set.size === 0) return;
    const raw = JSON.stringify(payload);
    for (const entry of set) {
      if (entry.ws.readyState === WebSocket.OPEN) {
        entry.ws.send(raw);
      }
    }
  }

  function sendToUsers(userIds: number[], payload: Record<string, unknown>) {
    const unique = new Set(userIds);
    for (const uid of unique) {
      sendToUser(uid, payload);
    }
  }

  async function broadcastPresenceToFriends(userId: number) {
    try {
      const [[settingsRow], [presenceRow], friendIds] = await Promise.all([
        db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1),
        db.select().from(presence).where(eq(presence.userId, userId)).limit(1),
        getFriendUserIds(userId),
      ]);

      const effective = computeEffectivePresence(
        {
          isOnline: presenceRow?.isOnline ?? false,
          lastHeartbeatAt: presenceRow?.lastHeartbeatAt ?? null,
          lastSeenAt: presenceRow?.lastSeenAt ?? null,
          hideOnlineStatus: settingsRow?.hideOnlineStatus ?? false,
          showLastSeen: settingsRow?.showLastSeen ?? true,
        },
        STALE_PRESENCE_MS
      );

      sendToUsers(friendIds, {
        type: 'presence:update',
        userId,
        isOnline: effective.isOnline,
        lastSeenAt: effective.lastSeenAt,
      });
    } catch (error) {
      console.error('broadcastPresenceToFriends error:', error);
    }
  }

  async function disconnectSessionSockets(userId: number, sessionToken: string) {
    const set = socketsByUser.get(userId);
    if (!set) return;
    for (const entry of Array.from(set)) {
      if (entry.sessionToken === sessionToken) {
        set.delete(entry);
        try {
          entry.ws.close(1000, 'Logged out');
        } catch {
          // ignore
        }
      }
    }
    if (set.size === 0) {
      socketsByUser.delete(userId);
      await setPresenceOffline(userId);
      await broadcastPresenceToFriends(userId);
    }
  }

  wss.on('connection', async (ws, req) => {
    try {
      const cookies = parseCookies(req.headers.cookie);
      const token = cookies[SESSION_COOKIE_NAME];
      const userId = await resolveSessionUserId(token);
      if (!userId || !token) {
        ws.close(4001, 'Unauthorized');
        return;
      }

      const tracked: TrackedSocket = {
        ws,
        userId,
        sessionToken: token,
        isAlive: true,
      };

      let userSockets = socketsByUser.get(userId);
      if (!userSockets) {
        userSockets = new Set();
        socketsByUser.set(userId, userSockets);
      }
      const wasFirstSocket = userSockets.size === 0;
      userSockets.add(tracked);

      await setPresenceOnline(userId);
      if (wasFirstSocket) {
        await broadcastPresenceToFriends(userId);
      }

      ws.send(JSON.stringify({ type: 'ws:ready', userId }));

      ws.on('pong', () => {
        tracked.isAlive = true;
      });

      ws.on('message', async (raw) => {
        try {
          const data = JSON.parse(raw.toString()) as { type?: string };
          if (data.type === 'heartbeat') {
            tracked.isAlive = true;
            await touchPresenceHeartbeat(userId);
            ws.send(JSON.stringify({ type: 'heartbeat:ack', ts: Date.now() }));
          }
        } catch {
          // ignore malformed frames
        }
      });

      ws.on('close', async () => {
        const set = socketsByUser.get(userId);
        if (set) {
          set.delete(tracked);
          if (set.size === 0) {
            socketsByUser.delete(userId);
            await setPresenceOffline(userId);
            await broadcastPresenceToFriends(userId);
          }
        }
      });
    } catch (error) {
      console.error('WebSocket connection error:', error);
      ws.close(1011, 'Server error');
    }
  });

  // Periodic stale heartbeat & dead socket reaper
  const presenceReaper = setInterval(async () => {
    for (const [uid, set] of socketsByUser.entries()) {
      for (const entry of Array.from(set)) {
        if (!entry.isAlive) {
          set.delete(entry);
          entry.ws.terminate();
        } else {
          entry.isAlive = false;
          if (entry.ws.readyState === WebSocket.OPEN) {
            entry.ws.ping();
          }
        }
      }
      if (set.size === 0) {
        socketsByUser.delete(uid);
        await setPresenceOffline(uid);
        await broadcastPresenceToFriends(uid);
      }
    }

    try {
      const expiredIds = await expireStalePresenceRows(STALE_PRESENCE_MS);
      for (const expiredUid of expiredIds) {
        if (!socketsByUser.has(expiredUid)) {
          await broadcastPresenceToFriends(expiredUid);
        }
      }
    } catch (error) {
      console.error('Presence reaper error:', error);
    }
  }, 5000);

  server.on('close', () => clearInterval(presenceReaper));

  // -------------------- AUTH ROUTES --------------------

  app.post('/api/auth/register', async (req, res) => {
    try {
      const { username, password, confirmPassword, rememberMe } = req.body ?? {};
      const validation = validateRegistrationInput({
        username: String(username ?? ''),
        password: String(password ?? ''),
        confirmPassword: String(confirmPassword ?? ''),
      });

      if (!validation.valid) {
        const firstError =
          validation.errors.username ||
          validation.errors.password ||
          validation.errors.confirmPassword ||
          'Invalid registration input.';
        res.status(400).json({ error: firstError, fieldErrors: validation.errors });
        return;
      }

      const [existing] = await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.username, validation.normalizedUsername))
        .limit(1);

      if (existing) {
        res.status(409).json({
          error: USERNAME_TAKEN_ERROR,
          fieldErrors: { username: USERNAME_TAKEN_ERROR },
        });
        return;
      }

      const passwordHash = await hashPassword(String(password));
      const cleanDisplay = String(username ?? '').trim() || validation.normalizedUsername;

      const [created] = await db
        .insert(users)
        .values({
          username: validation.normalizedUsername,
          displayName: cleanDisplay,
          passwordHash,
          avatarColor: pickAvatarColor(validation.normalizedUsername),
        })
        .returning({ id: users.id });

      await ensureUserAuxRows(created.id);
      await setPresenceOnline(created.id);

      const remember = Boolean(rememberMe);
      const token = await createSessionForUser(created.id, remember);
      setSessionCookie(req, res, token, remember);

      const authUser = await getAuthUserById(created.id);
      res.status(201).json({ user: authUser });
    } catch (error: unknown) {
      const pgCode = (error as { code?: string })?.code;
      if (pgCode === '23505') {
        res.status(409).json({
          error: USERNAME_TAKEN_ERROR,
          fieldErrors: { username: USERNAME_TAKEN_ERROR },
        });
        return;
      }
      console.error('Register error:', error);
      res.status(500).json({ error: 'Unable to register account right now.' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password, rememberMe } = req.body ?? {};
      const validation = validateLoginInput({
        username: String(username ?? ''),
        password: String(password ?? ''),
      });

      if (!validation.valid) {
        res.status(400).json({ error: validation.error });
        return;
      }

      const [userRow] = await db
        .select()
        .from(users)
        .where(eq(users.username, validation.normalizedUsername))
        .limit(1);

      if (!userRow) {
        res.status(401).json({ error: USERNAME_NOT_FOUND_ERROR });
        return;
      }

      const matches = await verifyPassword(String(password), userRow.passwordHash);
      if (!matches) {
        res.status(401).json({ error: 'Incorrect password.' });
        return;
      }

      await ensureUserAuxRows(userRow.id);
      await setPresenceOnline(userRow.id);

      const remember = Boolean(rememberMe);
      const token = await createSessionForUser(userRow.id, remember);
      setSessionCookie(req, res, token, remember);

      const authUser = await getAuthUserById(userRow.id);
      res.json({ user: authUser });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Unable to sign in right now.' });
    }
  });

  app.post('/api/auth/logout', async (req, res) => {
    try {
      const token = extractSessionToken(req);
      const userId = await revokeSessionToken(token);
      clearSessionCookie(req, res);
      if (userId && token) {
        await disconnectSessionSockets(userId, token);
      }
      res.json({ ok: true });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ error: 'Failed to log out.' });
    }
  });

  app.get('/api/auth/session', async (req, res) => {
    try {
      const token = extractSessionToken(req);
      const userId = await resolveSessionUserId(token);
      if (!userId) {
        res.json({ user: null });
        return;
      }
      const user = await getAuthUserById(userId);
      res.json({ user: user ?? null });
    } catch (error) {
      console.error('/api/auth/session error:', error);
      res.status(500).json({ error: 'Failed to check session.' });
    }
  });

  app.get('/api/auth/me', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const user = await getAuthUserById(req.userId!);
      if (!user) {
        res.status(401).json({ error: 'Session expired.' });
        return;
      }
      res.json({ user });
    } catch (error) {
      console.error('/api/auth/me error:', error);
      res.status(500).json({ error: 'Failed to verify session.' });
    }
  });

  // -------------------- PROFILE & SETTINGS ROUTES --------------------

  app.patch('/api/profile', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const userId = req.userId!;
      const { displayName, bio, avatarUrl, bannerTemplate, bannerUrl, accentColor, equippedAccessories } =
        req.body ?? {};

      const updates: Partial<typeof users.$inferInsert> = {};
      if (typeof displayName === 'string') {
        const trimmed = displayName.trim().slice(0, 40);
        if (!trimmed) {
          res.status(400).json({ error: 'Display name cannot be empty.' });
          return;
        }
        updates.displayName = trimmed;
      }
      if (typeof bio === 'string') {
        updates.bio = bio.trim().slice(0, 280);
      }
      if (avatarUrl === null || typeof avatarUrl === 'string') {
        if (typeof avatarUrl === 'string' && avatarUrl.length > 2_000_000) {
          res.status(400).json({ error: 'Avatar image is too large.' });
          return;
        }
        updates.avatarUrl = avatarUrl;
      }
      if (typeof bannerTemplate === 'string') {
        updates.bannerTemplate = bannerTemplate;
      }
      if (bannerUrl === null || typeof bannerUrl === 'string') {
        if (typeof bannerUrl === 'string' && bannerUrl.length > 2_500_000) {
          res.status(400).json({ error: 'Banner image is too large.' });
          return;
        }
        updates.bannerUrl = bannerUrl;
      }
      if (typeof accentColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(accentColor)) {
        updates.accentColor = accentColor;
      }
      if (equippedAccessories && typeof equippedAccessories === 'object') {
        updates.equippedAccessories = equippedAccessories as EquippedAccessoriesMap;
      }

      if (Object.keys(updates).length > 0) {
        await db.update(users).set(updates).where(eq(users.id, userId));
      }

      const authUser = await getAuthUserById(userId);
      res.json({ user: authUser });
    } catch (error) {
      console.error('PATCH /api/profile error:', error);
      res.status(500).json({ error: 'Failed to update profile.' });
    }
  });

  app.patch('/api/settings', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const userId = req.userId!;
      const { hideOnlineStatus, showLastSeen, readReceipts, reduceMotion } = req.body ?? {};
      const updates: Partial<typeof userSettings.$inferInsert> = {};

      if (typeof hideOnlineStatus === 'boolean') updates.hideOnlineStatus = hideOnlineStatus;
      if (typeof showLastSeen === 'boolean') updates.showLastSeen = showLastSeen;
      if (typeof readReceipts === 'boolean') updates.readReceipts = readReceipts;
      if (typeof reduceMotion === 'boolean') updates.reduceMotion = reduceMotion;

      await ensureUserAuxRows(userId);
      if (Object.keys(updates).length > 0) {
        await db.update(userSettings).set(updates).where(eq(userSettings.userId, userId));
      }

      if (typeof hideOnlineStatus === 'boolean' || typeof showLastSeen === 'boolean') {
        await broadcastPresenceToFriends(userId);
      }

      const authUser = await getAuthUserById(userId);
      res.json({ user: authUser });
    } catch (error) {
      console.error('PATCH /api/settings error:', error);
      res.status(500).json({ error: 'Failed to update settings.' });
    }
  });

  // -------------------- USER SEARCH & PROFILES --------------------

  app.get('/api/users/search', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const q = String(req.query.q ?? '');
      const results = await searchUsers(req.userId!, q);
      res.json({ users: results });
    } catch (error) {
      console.error('GET /api/users/search error:', error);
      res.status(500).json({ error: 'Failed to search users.' });
    }
  });

  app.get('/api/users/:username', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const profile = await getPublicUserProfile(req.userId!, req.params.username);
      if (!profile) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }
      res.json(profile);
    } catch (error) {
      console.error('GET /api/users/:username error:', error);
      res.status(500).json({ error: 'Failed to load profile.' });
    }
  });

  // -------------------- FRIENDS & REQUESTS --------------------

  app.get('/api/friends', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const data = await getFriendsAndRequests(req.userId!);
      res.json(data);
    } catch (error) {
      console.error('GET /api/friends error:', error);
      res.status(500).json({ error: 'Failed to fetch friends.' });
    }
  });

  app.post('/api/friends/request', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const receiverId = Number(req.body?.userId);
      if (!Number.isInteger(receiverId) || receiverId <= 0) {
        res.status(400).json({ error: 'Valid target user is required.' });
        return;
      }

      const result = await createFriendRequest(req.userId!, receiverId);
      sendToUsers([req.userId!, receiverId], {
        type: 'friend:updated',
        actorId: req.userId!,
        targetId: receiverId,
        status: result.status,
      });

      const data = await getFriendsAndRequests(req.userId!);
      res.status(201).json({ result, ...data });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to send friend request.';
      res.status(400).json({ error: msg });
    }
  });

  app.post('/api/friends/respond', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const requestId = Number(req.body?.requestId);
      const action = req.body?.action === 'accept' ? 'accept' : req.body?.action === 'decline' ? 'decline' : null;
      if (!Number.isInteger(requestId) || !action) {
        res.status(400).json({ error: 'Invalid friend request response.' });
        return;
      }

      const result = await respondFriendRequest(req.userId!, requestId, action);
      sendToUsers([result.senderId, result.receiverId], {
        type: 'friend:updated',
        actorId: req.userId!,
        status: result.status,
      });

      const data = await getFriendsAndRequests(req.userId!);
      res.json({ result, ...data });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to respond to request.';
      res.status(400).json({ error: msg });
    }
  });

  app.delete('/api/friends/:friendId', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const friendId = Number(req.params.friendId);
      if (!Number.isInteger(friendId) || friendId <= 0) {
        res.status(400).json({ error: 'Invalid friend ID.' });
        return;
      }
      await removeFriendship(req.userId!, friendId);
      sendToUsers([req.userId!, friendId], {
        type: 'friend:updated',
        actorId: req.userId!,
        status: 'removed',
      });
      const data = await getFriendsAndRequests(req.userId!);
      res.json(data);
    } catch (error) {
      console.error('DELETE /api/friends error:', error);
      res.status(500).json({ error: 'Failed to remove friend.' });
    }
  });

  // -------------------- CONVERSATIONS & MESSAGES --------------------

  app.get('/api/chats', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const chats = await listConversationsForUser(req.userId!);
      res.json({ chats });
    } catch (error) {
      console.error('GET /api/chats error:', error);
      res.status(500).json({ error: 'Failed to load chats.' });
    }
  });

  app.post('/api/chats/direct', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const peerId = Number(req.body?.peerId);
      if (!Number.isInteger(peerId) || peerId <= 0) {
        res.status(400).json({ error: 'Valid user ID is required.' });
        return;
      }
      const chat = await getOrCreateDirectConversation(req.userId!, peerId);
      res.json({ chat });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to open chat.';
      res.status(400).json({ error: msg });
    }
  });

  app.get('/api/chats/:id/messages', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const convId = Number(req.params.id);
      if (!Number.isInteger(convId) || convId <= 0) {
        res.status(400).json({ error: 'Invalid chat ID.' });
        return;
      }
      const msgs = await listConversationMessages(req.userId!, convId);
      res.json({ messages: msgs });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to load messages.';
      const status = msg === 'Conversation access denied.' ? 403 : 500;
      res.status(status).json({ error: msg });
    }
  });

  app.post('/api/chats/:id/messages', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const convId = Number(req.params.id);
      if (!Number.isInteger(convId) || convId <= 0) {
        res.status(400).json({ error: 'Invalid chat ID.' });
        return;
      }
      const body = String(req.body?.body ?? '');
      const mediaUrl = typeof req.body?.mediaUrl === 'string' ? req.body.mediaUrl : null;
      if (mediaUrl && mediaUrl.length > 2_500_000) {
        res.status(400).json({ error: 'Image attachment is too large.' });
        return;
      }

      const convs = await listConversationsForUser(req.userId!, convId);
      const peerOnline = Boolean(convs[0] && socketsByUser.has(convs[0].peer.id));

      const { message, participantIds } = await createConversationMessage(req.userId!, convId, {
        body,
        mediaUrl,
        peerOnline,
      });

      sendToUsers(participantIds, {
        type: 'message:new',
        conversationId: convId,
        message,
      });

      res.status(201).json({ message });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to send message.';
      const status = msg === 'Conversation access denied.' ? 403 : 400;
      res.status(status).json({ error: msg });
    }
  });

  app.post('/api/chats/:id/read', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const convId = Number(req.params.id);
      if (!Number.isInteger(convId) || convId <= 0) {
        res.status(400).json({ error: 'Invalid chat ID.' });
        return;
      }
      const result = await markConversationAsRead(req.userId!, convId);
      if (result.lastReadMessageId && result.participantIds.length > 0) {
        sendToUsers(result.participantIds, {
          type: 'message:read',
          conversationId: convId,
          readerId: req.userId!,
          lastReadMessageId: result.lastReadMessageId,
        });
      }
      res.json({ ok: true, lastReadMessageId: result.lastReadMessageId });
    } catch (error) {
      console.error('POST /api/chats/:id/read error:', error);
      res.status(500).json({ error: 'Failed to mark chat read.' });
    }
  });

  // -------------------- GIFTS ROUTES --------------------

  app.get('/api/gifts/catalog', requireAuth, (_req, res) => {
    res.json({ catalog: GIFTS_CATALOG });
  });

  app.get('/api/gifts/owned', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const owned = await listOwnedGiftsForUser(req.userId!, true);
      res.json({ owned });
    } catch (error) {
      console.error('GET /api/gifts/owned error:', error);
      res.status(500).json({ error: 'Failed to load owned gifts.' });
    }
  });

  app.post('/api/gifts/purchase', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const catalogGiftId = String(req.body?.catalogGiftId ?? '');
      const result = await purchaseCatalogGift(req.userId!, catalogGiftId);
      res.status(201).json(result);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to purchase gift.';
      res.status(400).json({ error: msg });
    }
  });

  app.post('/api/gifts/send', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const recipientId = Number(req.body?.recipientId);
      const catalogGiftId = String(req.body?.catalogGiftId ?? '');
      const note = typeof req.body?.note === 'string' ? req.body.note : undefined;
      if (!Number.isInteger(recipientId) || recipientId <= 0) {
        res.status(400).json({ error: 'Valid recipient is required.' });
        return;
      }

      const result = await sendCatalogGiftToUser(req.userId!, recipientId, catalogGiftId, note);

      sendToUsers(result.participantIds, {
        type: 'message:new',
        conversationId: result.conversationId,
        message: result.message,
      });
      sendToUser(recipientId, {
        type: 'gift:received',
        owned: result.owned,
      });

      res.status(201).json(result);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to send gift.';
      res.status(400).json({ error: msg });
    }
  });

  app.post('/api/gifts/:ownershipId/upgrade', requireAuth, async (req: AuthedRequest, res) => {
    try {
      const ownershipId = Number(req.params.ownershipId);
      if (!Number.isInteger(ownershipId) || ownershipId <= 0) {
        res.status(400).json({ error: 'Invalid gift ID.' });
        return;
      }
      const result = await upgradeUserGift(req.userId!, ownershipId);
      res.json(result);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Failed to upgrade gift.';
      res.status(400).json({ error: msg });
    }
  });

  // -------------------- FRONTEND SERVING (VITE / DIST) --------------------

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Spark server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
