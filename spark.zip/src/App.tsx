import { useEffect } from 'react';
import { AuthScreen } from './components/auth/AuthScreen';
import { GiftsView } from './components/gifts/GiftsView';
import { ChatsView } from './components/messaging/ChatsView';
import { MobileNav } from './components/navigation/MobileNav';
import { SidebarRail } from './components/navigation/SidebarRail';
import { ProfileView } from './components/profile/ProfileView';
import { UserProfileModal } from './components/profile/UserProfileModal';
import { SettingsModal } from './components/settings/SettingsModal';
import { FriendsView } from './components/social/FriendsView';
import { useSparkStore } from './store/useSparkStore';

export default function App() {
  const { user, authInitialized, activeSection, bootstrapSession, disconnectWebSocket } =
    useSparkStore();

  useEffect(() => {
    void bootstrapSession();
    return () => {
      disconnectWebSocket();
    };
  }, [bootstrapSession, disconnectWebSocket]);

  useEffect(() => {
    if (user?.settings.reduceMotion) {
      document.documentElement.classList.add('reduce-motion');
    } else {
      document.documentElement.classList.remove('reduce-motion');
    }
  }, [user?.settings.reduceMotion]);

  if (!authInitialized) {
    return (
      <div className="min-h-screen bg-[#161616] text-[#A8A8A8] flex items-center justify-center text-sm">
        Loading Spark...
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <div className="h-screen w-screen overflow-hidden flex bg-[#161616] text-[#F4F4F4]">
      <SidebarRail />

      <main className="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">
        {activeSection === 'chats' && <ChatsView />}
        {activeSection === 'friends' && <FriendsView />}
        {activeSection === 'gifts' && <GiftsView />}
        {activeSection === 'profile' && <ProfileView />}
      </main>

      <MobileNav />
      <SettingsModal />
      <UserProfileModal />
    </div>
  );
}
