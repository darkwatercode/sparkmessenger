import {
  boolean,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core';
import type { EquippedAccessoriesMap } from '../types/spark';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: text('username').notNull().unique(),
  displayName: text('display_name').notNull(),
  passwordHash: text('password_hash').notNull(),
  bio: text('bio').notNull().default(''),
  avatarUrl: text('avatar_url'),
  avatarColor: text('avatar_color').notNull().default('#0F62FE'),
  bannerTemplate: text('banner_template').notNull().default('obsidian-grid'),
  bannerUrl: text('banner_url'),
  accentColor: text('accent_color').notNull().default('#0F62FE'),
  equippedAccessories: jsonb('equipped_accessories')
    .$type<EquippedAccessoriesMap>()
    .notNull()
    .default({}),
  coins: integer('coins').notNull().default(1200),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const userSettings = pgTable('user_settings', {
  userId: integer('user_id')
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade' }),
  hideOnlineStatus: boolean('hide_online_status').notNull().default(false),
  showLastSeen: boolean('show_last_seen').notNull().default(true),
  readReceipts: boolean('read_receipts').notNull().default(true),
  reduceMotion: boolean('reduce_motion').notNull().default(false),
});

export const sessions = pgTable('sessions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull().unique(),
  rememberMe: boolean('remember_me').notNull().default(false),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const presence = pgTable('presence', {
  userId: integer('user_id')
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade' }),
  isOnline: boolean('is_online').notNull().default(false),
  lastSeenAt: timestamp('last_seen_at').defaultNow().notNull(),
  lastHeartbeatAt: timestamp('last_heartbeat_at').defaultNow().notNull(),
});

export const friendRequests = pgTable('friend_requests', {
  id: serial('id').primaryKey(),
  senderId: integer('sender_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  receiverId: integer('receiver_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  status: text('status').notNull().default('pending'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const friendships = pgTable(
  'friendships',
  {
    id: serial('id').primaryKey(),
    userAId: integer('user_a_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    userBId: integer('user_b_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [uniqueIndex('friendships_pair_idx').on(table.userAId, table.userBId)]
);

export const conversations = pgTable('conversations', {
  id: serial('id').primaryKey(),
  type: text('type').notNull().default('direct'),
  directKey: text('direct_key').unique(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const conversationParticipants = pgTable(
  'conversation_participants',
  {
    conversationId: integer('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    userId: integer('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    lastReadMessageId: integer('last_read_message_id'),
    joinedAt: timestamp('joined_at').defaultNow().notNull(),
  },
  (table) => [primaryKey({ columns: [table.conversationId, table.userId] })]
);

export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  conversationId: integer('conversation_id')
    .notNull()
    .references(() => conversations.id, { onDelete: 'cascade' }),
  senderId: integer('sender_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  body: text('body').notNull().default(''),
  giftCatalogId: text('gift_catalog_id'),
  giftOwnershipId: integer('gift_ownership_id'),
  mediaUrl: text('media_url'),
  deliveryStatus: text('delivery_status').notNull().default('sent'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const giftOwnership = pgTable('gift_ownership', {
  id: serial('id').primaryKey(),
  catalogGiftId: text('catalog_gift_id').notNull(),
  ownerId: integer('owner_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  senderId: integer('sender_id').references(() => users.id, { onDelete: 'set null' }),
  serialNumber: text('serial_number').notNull(),
  level: integer('level').notNull().default(1),
  hiddenFromProfile: boolean('hidden_from_profile').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
