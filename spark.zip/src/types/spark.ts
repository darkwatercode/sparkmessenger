export type NavSection = 'chats' | 'friends' | 'gifts' | 'profile';

export type OnlinePresence = 'online' | 'away' | 'focus' | 'offline';

export type AvatarFrameStyle = 'none' | 'cobalt' | 'carbon-grid' | 'amber-brass' | 'mono-double';

export type AccessorySlot = 'frame' | 'head' | 'effect' | 'badge';
export type AccessoryRarity =
  | 'Common'
  | 'Uncommon'
  | 'Rare'
  | 'Epic'
  | 'Legendary'
  | 'Mythic'
  | 'Exclusive';

export interface AccessoryTransform {
  offsetX: number;
  offsetY: number;
  scale: number;
  rotation: number;
}

export interface AvatarAccessory {
  id: string;
  name: string;
  description: string;
  slot: AccessorySlot;
  categoryLabel: string;
  rarity: AccessoryRarity;
  variant: string;
  accentHex: string;
  animated?: boolean;
  unlockType: 'loyalty' | 'achievement' | 'starter' | 'event';
  unlockRequirement: string;
  loyaltyDaysRequired?: number;
  achievementId?: string;
}

export interface EquippedAccessoryEntry {
  accessoryId: string;
  transform: AccessoryTransform;
}

export type EquippedAccessoriesMap = Partial<Record<AccessorySlot, EquippedAccessoryEntry>>;

export interface LoyaltyMilestone {
  days: number;
  title: string;
  subtitle: string;
  badgeText?: string;
  rewardAccessoryIds: string[];
  rewardCoins: number;
  rewardMaterials: number;
}

export type AchievementCategory = 'Loyalty' | 'Social' | 'Messaging' | 'Gifts' | 'Creativity';

export interface Achievement {
  id: string;
  category: AchievementCategory;
  name: string;
  description: string;
  conditionLabel: string;
  iconName: string;
  target: number;
  rarity: AccessoryRarity;
  rewardAccessoryId?: string;
  rewardCoins: number;
  rewardMaterials: number;
}

export type BannerMode = 'template' | 'upload' | 'builder';
export type BannerPattern = 'none' | 'grid' | 'dots' | 'diagonal' | 'waves' | 'topographic';

export interface ProfileBannerConfig {
  id: string;
  name: string;
  mode: BannerMode;
  templateId?: 'obsidian-grid' | 'alpine' | 'cobalt-mesh' | 'mono-slate' | 'nocturne-rain' | 'amber-studio';
  imageUrl?: string;
  primaryColor?: string;
  secondaryColor?: string;
  pattern?: BannerPattern;
  zoom: number;
  posX: number;
  posY: number;
  brightness: number;
  removed?: boolean;
}

export interface AvatarImageConfig {
  url?: string;
  isDefault?: boolean;
  zoom: number;
  posX: number;
  posY: number;
}

export type GiftCategory =
  | 'Animals'
  | 'Flowers'
  | 'Jewelry'
  | 'Technology'
  | 'Fantasy'
  | 'Food'
  | 'Luxury objects'
  | 'Collectibles'
  | 'Seasonal gifts'
  | 'Meme-inspired gifts'
  | 'Special limited editions';

export type GiftRarity =
  | 'Common'
  | 'Uncommon'
  | 'Rare'
  | 'Epic'
  | 'Legendary'
  | 'Mythic'
  | 'Limited'
  | 'Exclusive';

export interface CatalogGift {
  id: string;
  name: string;
  description: string;
  category: GiftCategory;
  rarity: GiftRarity;
  collection: string;
  edition: string;
  creator: string;
  priceCredits: number;
  level: 1 | 2 | 3 | 4 | 5;
  maxLevel: 5;
  upgradePathLabel: string;
  artworkVariant: string;
  accentHex: string;
  featured?: boolean;
  trending?: boolean;
  isNew?: boolean;
  isLimitedDrop?: boolean;
  imageUrl?: string;
}

// Compatibility shape expected by GiftArtwork component
export interface Gift extends CatalogGift {
  serialNumber: string;
  ownerId: string;
  senderId?: string;
  receivedDate?: string;
  hiddenFromProfile?: boolean;
  isFavorite?: boolean;
  history: {
    id: string;
    event: 'Minted' | 'Acquired' | 'Gifted' | 'Showcased' | 'Upgraded';
    actorName: string;
    targetName?: string;
    timestamp: string;
    note?: string;
  }[];
}

export type FriendshipStatus = 'none' | 'friends' | 'incoming' | 'outgoing' | 'self';

export interface UserSettings {
  hideOnlineStatus: boolean;
  showLastSeen: boolean;
  readReceipts: boolean;
  reduceMotion: boolean;
}

export interface PublicUser {
  id: number;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string | null;
  avatarColor: string;
  initials: string;
  bannerTemplate: string;
  bannerUrl: string | null;
  accentColor: string;
  equippedAccessories: EquippedAccessoriesMap;
  isOnline: boolean;
  lastSeenAt: string | null;
  friendshipStatus: FriendshipStatus;
  friendRequestId?: number;
  createdAt: string;
}

export interface AuthUser extends PublicUser {
  coins: number;
  settings: UserSettings;
}

export interface FriendRequestItem {
  id: number;
  senderId: number;
  receiverId: number;
  status: 'pending' | 'accepted' | 'declined';
  direction: 'incoming' | 'outgoing';
  user: PublicUser;
  createdAt: string;
}

export interface ChatMessage {
  id: number;
  conversationId: number;
  senderId: number;
  body: string;
  giftCatalogId: string | null;
  giftOwnershipId: number | null;
  giftLevel?: number | null;
  mediaUrl: string | null;
  deliveryStatus: 'sent' | 'delivered' | 'read';
  createdAt: string;
}

export interface DirectConversation {
  id: number;
  peer: PublicUser;
  lastMessage: ChatMessage | null;
  unreadCount: number;
  updatedAt: string;
}

export interface OwnedGiftItem {
  id: number;
  catalogGiftId: string;
  ownerId: number;
  senderId: number | null;
  senderUsername?: string | null;
  serialNumber: string;
  level: 1 | 2 | 3 | 4 | 5;
  hiddenFromProfile: boolean;
  createdAt: string;
}
