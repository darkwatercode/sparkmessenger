import React, { useState } from 'react';
import { Eye, EyeOff, Sparkles } from 'lucide-react';
import { useSparkStore } from '../../store/useSparkStore';
import { validateLoginInput, validateRegistrationInput } from '../../utils/sparkLogic';

export const AuthScreen: React.FC = () => {
  const { register, login, authBusy } = useSparkStore();
  const [mode, setMode] = useState<'register' | 'login'>('register');

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{
    username?: string;
    password?: string;
    confirmPassword?: string;
  }>({});

  const switchMode = (nextMode: 'register' | 'login') => {
    setMode(nextMode);
    setErrorMsg(null);
    setFieldErrors({});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setFieldErrors({});

    if (mode === 'register') {
      const check = validateRegistrationInput({ username, password, confirmPassword });
      if (!check.valid) {
        setFieldErrors(check.errors);
        setErrorMsg(
          check.errors.username ||
            check.errors.password ||
            check.errors.confirmPassword ||
            'Please check your registration details.'
        );
        return;
      }

      try {
        await register({
          username,
          password,
          confirmPassword,
          rememberMe,
        });
      } catch (err: unknown) {
        const apiErr = err as Error & { fieldErrors?: Record<string, string> };
        if (apiErr.fieldErrors) {
          setFieldErrors(apiErr.fieldErrors);
        }
        setErrorMsg(apiErr.message || 'Unable to create account.');
      }
      return;
    }

    const loginCheck = validateLoginInput({ username, password });
    if (!loginCheck.valid) {
      setErrorMsg(loginCheck.error || 'Enter your username and password.');
      return;
    }

    try {
      await login({
        username,
        password,
        rememberMe,
      });
    } catch (err: unknown) {
      const apiErr = err as Error;
      setErrorMsg(apiErr.message || 'Sign in failed.');
    }
  };

  return (
    <div className="min-h-screen bg-[#161616] text-[#F4F4F4] flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] bg-[#212121] border border-[#333333] p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-9 h-9 bg-[#0F62FE] flex items-center justify-center text-white shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-display text-xl font-semibold tracking-tight text-[#F4F4F4]">
              Spark
            </h1>
            <p className="text-xs text-[#A8A8A8]">Clean, real-time messaging</p>
          </div>
        </div>

        <div className="grid grid-cols-2 border border-[#393939] bg-[#161616] p-0.5 mb-6">
          <button
            type="button"
            onClick={() => switchMode('register')}
            className={`h-9 text-xs font-medium transition-colors cursor-pointer ${
              mode === 'register'
                ? 'bg-[#262626] text-[#F4F4F4]'
                : 'text-[#A8A8A8] hover:text-[#F4F4F4]'
            }`}
          >
            Create account
          </button>
          <button
            type="button"
            onClick={() => switchMode('login')}
            className={`h-9 text-xs font-medium transition-colors cursor-pointer ${
              mode === 'login'
                ? 'bg-[#262626] text-[#F4F4F4]'
                : 'text-[#A8A8A8] hover:text-[#F4F4F4]'
            }`}
          >
            Sign in
          </button>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="mb-4 px-3 py-2.5 bg-[#DA1E28]/15 border border-[#FA4D56]/60 text-xs text-[#FFB3B8]"
          >
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div>
            <label htmlFor="spark-username" className="block text-xs font-medium text-[#A8A8A8] mb-1.5">
              Username
            </label>
            <input
              id="spark-username"
              name="username"
              type="text"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="darkwater"
              className={`w-full h-11 px-3 bg-[#161616] border text-sm text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE] ${
                fieldErrors.username ? 'border-[#FA4D56]' : 'border-[#393939]'
              }`}
            />
          </div>

          <div>
            <label htmlFor="spark-password" className="block text-xs font-medium text-[#A8A8A8] mb-1.5">
              Password
            </label>
            <div className="relative">
              <input
                id="spark-password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full h-11 pl-3 pr-11 bg-[#161616] border text-sm text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE] ${
                  fieldErrors.password ? 'border-[#FA4D56]' : 'border-[#393939]'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                className="absolute right-0 top-0 h-11 w-11 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {mode === 'register' && (
              <p className="mt-1 text-[11px] text-[#7A7A7A]">Minimum 8 characters.</p>
            )}
          </div>

          {mode === 'register' && (
            <div>
              <label
                htmlFor="spark-confirm-password"
                className="block text-xs font-medium text-[#A8A8A8] mb-1.5"
              >
                Confirm password
              </label>
              <div className="relative">
                <input
                  id="spark-confirm-password"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full h-11 pl-3 pr-11 bg-[#161616] border text-sm text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE] ${
                    fieldErrors.confirmPassword ? 'border-[#FA4D56]' : 'border-[#393939]'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((v) => !v)}
                  aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                  className="absolute right-0 top-0 h-11 w-11 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          )}

          <label className="flex items-center gap-2.5 text-xs text-[#A8A8A8] cursor-pointer select-none pt-1">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 accent-[#0F62FE] bg-[#161616] border-[#393939]"
            />
            Remember me
          </label>

          <button
            type="submit"
            disabled={authBusy}
            className="w-full h-11 bg-[#0F62FE] hover:bg-[#0353E9] disabled:opacity-60 text-white text-sm font-medium transition-colors cursor-pointer"
          >
            {authBusy
              ? mode === 'register'
                ? 'Creating account...'
                : 'Signing in...'
              : mode === 'register'
              ? 'Create Spark account'
              : 'Sign in'}
          </button>
        </form>

        <div className="mt-5 pt-4 border-t border-[#2E2E2E] text-center text-xs text-[#A8A8A8]">
          {mode === 'register' ? (
            <>
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => switchMode('login')}
                className="text-[#78A9FF] hover:underline cursor-pointer"
              >
                Sign in
              </button>
            </>
          ) : (
            <>
              New to Spark?{' '}
              <button
                type="button"
                onClick={() => switchMode('register')}
                className="text-[#78A9FF] hover:underline cursor-pointer"
              >
                Create account
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
