import React from 'react';
import { INITIAL_ACCESSORIES } from '../../data/accessoriesData';
import type { AccessoryTransform, AvatarAccessory } from '../../types/spark';
import { DEFAULT_ACCESSORY_TRANSFORM } from '../../utils/sparkLogic';

export function getAccessoryById(id?: string): AvatarAccessory | undefined {
  if (!id) return undefined;
  return INITIAL_ACCESSORIES.find((a) => a.id === id);
}

interface AccessoryRendererProps {
  accessory: AvatarAccessory;
  transform?: AccessoryTransform;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'preview';
  animated?: boolean;
}

export const AccessoryRenderer: React.FC<AccessoryRendererProps> = ({
  accessory,
  transform = DEFAULT_ACCESSORY_TRANSFORM,
  size = 'md',
  animated = true,
}) => {
  const uid = React.useId().replace(/:/g, '');
  const isMini = size === 'xs' || size === 'sm';
  const color = accessory.accentHex;
  const animSpin = animated && accessory.animated ? 'gift-anim-spin' : '';
  const animPulse = animated && accessory.animated ? 'gift-anim-pulse' : '';
  const animFloat = animated && accessory.animated ? 'gift-anim-float' : '';

  const style: React.CSSProperties = {
    transform: `translate(${transform.offsetX}%, ${transform.offsetY}%) scale(${transform.scale}) rotate(${transform.rotation}deg)`,
    transformOrigin: 'center center',
  };

  if (accessory.slot === 'frame') {
    return (
      <svg
        viewBox="0 0 100 100"
        className="absolute -inset-[10%] w-[120%] h-[120%] pointer-events-none z-20"
        style={style}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id={`fr-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={color} />
            <stop offset="55%" stopColor="#F4F4F4" stopOpacity="0.85" />
            <stop offset="100%" stopColor={color} />
          </linearGradient>
        </defs>
        {renderFrameVariant(accessory.variant, color, `url(#fr-${uid})`, animSpin, animPulse)}
      </svg>
    );
  }

  if (accessory.slot === 'head') {
    return (
      <svg
        viewBox="0 0 100 60"
        className={`absolute left-[-12%] right-[-12%] ${
          isMini ? '-top-[36%]' : '-top-[40%]'
        } w-[124%] h-[68%] pointer-events-none z-30 overflow-visible`}
        style={style}
        aria-hidden="true"
      >
        <g className={animFloat}>{renderHeadVariant(accessory.variant, color, animPulse)}</g>
      </svg>
    );
  }

  if (accessory.slot === 'effect') {
    return (
      <svg
        viewBox="0 0 120 120"
        className="absolute -inset-[22%] w-[144%] h-[144%] pointer-events-none z-30 overflow-visible"
        style={style}
        aria-hidden="true"
      >
        {renderEffectVariant(accessory.variant, color, animSpin, animPulse, animFloat)}
      </svg>
    );
  }

  // badge slot
  return (
    <svg
      viewBox="0 0 40 40"
      className={`absolute ${
        size === 'xl' || size === 'preview'
          ? '-bottom-1.5 -left-1.5 w-7 h-7'
          : size === 'lg'
          ? '-bottom-1 -left-1 w-5 h-5'
          : '-bottom-1 -left-1 w-4 h-4'
      } pointer-events-none z-30 overflow-visible`}
      style={style}
      aria-hidden="true"
    >
      {renderBadgeVariant(accessory.variant, color, animPulse)}
    </svg>
  );
};

function renderFrameVariant(
  variant: string,
  color: string,
  grad: string,
  animSpin: string,
  animPulse: string
) {
  switch (variant) {
    case 'minimal-spark':
      return (
        <g>
          <rect x="8" y="8" width="84" height="84" rx="5" fill="none" stroke={color} strokeWidth="2.5" />
          <path d="M50 3 L52 8 L57 10 L52 12 L50 17 L48 12 L43 10 L48 8 Z" fill="#78A9FF" />
        </g>
      );
    case 'carbon-frame':
      return (
        <g>
          <rect x="7" y="7" width="86" height="86" rx="4" fill="none" stroke="#525252" strokeWidth="3" />
          <path d="M7 22 V7 H22 M78 7 H93 V22 M93 78 V93 H78 M22 93 H7 V78" fill="none" stroke={color} strokeWidth="3.2" />
        </g>
      );
    case 'silver-frame':
      return (
        <g>
          <rect x="7" y="7" width="86" height="86" rx="5" fill="none" stroke={grad} strokeWidth="4" />
          <rect x="11" y="11" width="78" height="78" rx="3" fill="none" stroke="#161616" strokeWidth="1.2" />
        </g>
      );
    case 'neon-frame':
      return (
        <g className={animPulse}>
          <rect x="7" y="7" width="86" height="86" rx="6" fill="none" stroke={color} strokeWidth="3.2" />
          <rect x="4" y="4" width="92" height="92" rx="8" fill="none" stroke="#78A9FF" strokeOpacity="0.45" strokeWidth="1.4" />
        </g>
      );
    case 'animated-frame':
      return (
        <g>
          <rect x="8" y="8" width="84" height="84" rx="6" fill="none" stroke="#393939" strokeWidth="2.5" />
          <circle
            cx="50"
            cy="50"
            r="46"
            fill="none"
            stroke={color}
            strokeWidth="2"
            strokeDasharray="12 8 4 8"
            className={animSpin}
          />
        </g>
      );
    case 'vintage-frame':
      return (
        <g>
          <rect x="7" y="7" width="86" height="86" rx="4" fill="none" stroke={color} strokeWidth="3.5" />
          <circle cx="9" cy="9" r="3" fill="#F4F4F4" />
          <circle cx="91" cy="9" r="3" fill="#F4F4F4" />
          <circle cx="9" cy="91" r="3" fill="#F4F4F4" />
          <circle cx="91" cy="91" r="3" fill="#F4F4F4" />
        </g>
      );
    case 'golden-frame':
    case 'anniversary-frame':
      return (
        <g>
          <rect x="6" y="6" width="88" height="88" rx="6" fill="none" stroke={grad} strokeWidth="4" />
          <polygon points="50,1 55,8 50,13 45,8" fill={color} className={animPulse} />
          <polygon points="50,87 55,92 50,99 45,92" fill={color} />
        </g>
      );
    case 'seasonal-frame':
      return (
        <g>
          <rect x="7" y="7" width="86" height="86" rx="5" fill="none" stroke="#BAE6FD" strokeWidth="2.8" strokeDasharray="16 4" />
          <circle cx="14" cy="14" r="2.5" fill="#E0F2FE" />
          <circle cx="86" cy="86" r="2.5" fill="#E0F2FE" />
        </g>
      );
    case 'legendary-frame':
    default:
      return (
        <g>
          <rect x="6" y="6" width="88" height="88" rx="7" fill="none" stroke={grad} strokeWidth="4.2" className={animPulse} />
          <circle cx="50" cy="50" r="47" fill="none" stroke={color} strokeOpacity="0.55" strokeWidth="1.6" strokeDasharray="8 6" className={animSpin} />
        </g>
      );
  }
}

function renderHeadVariant(variant: string, color: string, animPulse: string) {
  switch (variant) {
    case 'crown':
    case 'birthday-crown':
    case 'legacy-crown':
      return (
        <g>
          <polygon
            points="22,48 26,20 40,34 50,12 60,34 74,20 78,48"
            fill="#262626"
            stroke={color}
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <rect x="22" y="45" width="56" height="7" rx="2" fill={color} />
          <circle cx="50" cy="12" r="3.5" fill="#F4F4F4" className={animPulse} />
          <circle cx="26" cy="20" r="2.5" fill={color} />
          <circle cx="74" cy="20" r="2.5" fill={color} />
        </g>
      );
    case 'blue-laurel':
    case 'gold-laurel':
      return (
        <g fill="none" stroke={color} strokeWidth="2.6" strokeLinecap="round">
          <path d="M22 48 C18 30, 30 16, 46 14" />
          <path d="M78 48 C82 30, 70 16, 54 14" />
          {[22, 30, 38].map((y, idx) => (
            <React.Fragment key={y}>
              <ellipse cx={24 + idx * 5} cy={y} rx="5" ry="2.5" transform={`rotate(-30 ${24 + idx * 5} ${y})`} fill={color} fillOpacity="0.85" />
              <ellipse cx={76 - idx * 5} cy={y} rx="5" ry="2.5" transform={`rotate(30 ${76 - idx * 5} ${y})`} fill={color} fillOpacity="0.85" />
            </React.Fragment>
          ))}
        </g>
      );
    case 'halo':
      return (
        <g className={animPulse}>
          <ellipse cx="50" cy="24" rx="28" ry="8" fill="none" stroke={color} strokeWidth="3.5" />
          <ellipse cx="50" cy="24" rx="22" ry="5" fill="none" stroke="#F4F4F4" strokeOpacity="0.65" strokeWidth="1.4" />
        </g>
      );
    case 'beanie':
      return (
        <g>
          <path d="M22 46 C22 22, 78 22, 78 46 Z" fill="#393939" stroke={color} strokeWidth="2.2" />
          <rect x="20" y="42" width="60" height="10" rx="3" fill="#262626" stroke={color} strokeWidth="2" />
          <circle cx="50" cy="21" r="5" fill={color} />
        </g>
      );
    case 'santa-hat':
      return (
        <g>
          <path d="M22 46 C26 24, 54 14, 76 26 L68 38 L22 46 Z" fill="#DA1E28" stroke="#F4F4F4" strokeWidth="1.6" />
          <rect x="20" y="42" width="54" height="9" rx="4" fill="#F4F4F4" />
          <circle cx="77" cy="27" r="5.5" fill="#F4F4F4" />
        </g>
      );
    case 'witch-hat':
      return (
        <g>
          <ellipse cx="50" cy="46" rx="36" ry="7" fill="#262626" stroke={color} strokeWidth="2" />
          <polygon points="28,45 50,6 72,45" fill="#1E1B2E" stroke={color} strokeWidth="2.2" />
          <rect x="35" y="38" width="30" height="5" fill={color} />
        </g>
      );
    case 'cat-ears':
      return (
        <g>
          <polygon points="18,52 24,18 42,42" fill="#262626" stroke={color} strokeWidth="2.6" strokeLinejoin="round" />
          <polygon points="23,46 26,26 36,41" fill={color} fillOpacity="0.65" />
          <polygon points="82,52 76,18 58,42" fill="#262626" stroke={color} strokeWidth="2.6" strokeLinejoin="round" />
          <polygon points="77,46 74,26 64,41" fill={color} fillOpacity="0.65" />
        </g>
      );
    case 'bunny-ears':
      return (
        <g>
          <ellipse cx="36" cy="26" rx="7" ry="20" transform="rotate(-10 36 26)" fill="#262626" stroke="#F4F4F4" strokeWidth="2.2" />
          <ellipse cx="36" cy="27" rx="3.2" ry="13" transform="rotate(-10 36 27)" fill="#FF7EB6" fillOpacity="0.7" />
          <ellipse cx="64" cy="26" rx="7" ry="20" transform="rotate(10 64 26)" fill="#262626" stroke="#F4F4F4" strokeWidth="2.2" />
          <ellipse cx="64" cy="27" rx="3.2" ry="13" transform="rotate(10 64 27)" fill="#FF7EB6" fillOpacity="0.7" />
        </g>
      );
    case 'party-hat':
      return (
        <g>
          <polygon points="34,48 50,10 66,48" fill="#262626" stroke={color} strokeWidth="2.4" />
          <line x1="40" y1="34" x2="60" y2="34" stroke={color} strokeWidth="2.4" />
          <circle cx="50" cy="10" r="4.5" fill="#F1C21B" />
        </g>
      );
    case 'cowboy-hat':
      return (
        <g>
          <path d="M12 44 Q50 52 88 44" fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" />
          <path d="M28 43 L34 22 Q50 18 66 22 L72 43 Z" fill="#2B221B" stroke={color} strokeWidth="2.2" />
          <line x1="30" y1="37" x2="70" y2="37" stroke="#F1C21B" strokeWidth="2.4" />
        </g>
      );
    case 'cyber-helmet':
    default:
      return (
        <g>
          <path d="M20 48 C22 20, 78 20, 80 48 Z" fill="#1F242D" stroke={color} strokeWidth="2.4" />
          <rect x="26" y="34" width="48" height="10" rx="2" fill="#0F62FE" fillOpacity="0.55" stroke="#78A9FF" strokeWidth="1.6" />
          <line x1="50" y1="18" x2="50" y2="34" stroke="#F4F4F4" strokeWidth="2" />
        </g>
      );
  }
}

function renderEffectVariant(
  variant: string,
  color: string,
  animSpin: string,
  animPulse: string,
  animFloat: string
) {
  switch (variant) {
    case 'spark-particles':
    case 'small-stars':
      return (
        <g className={animPulse}>
          <path d="M18 22 L20 27 L25 29 L20 31 L18 36 L16 31 L11 29 L16 27 Z" fill={color} />
          <path d="M102 24 L104 28 L108 30 L104 32 L102 36 L100 32 L96 30 L100 28 Z" fill="#F4F4F4" />
          <path d="M98 92 L100 97 L105 99 L100 101 L98 106 L96 101 L91 99 L96 97 Z" fill={color} />
          <circle cx="22" cy="94" r="2.8" fill="#78A9FF" />
        </g>
      );
    case 'hearts':
      return (
        <g className={animFloat}>
          <path d="M22 28 C18 22, 12 27, 22 36 C32 27, 26 22, 22 28 Z" fill={color} />
          <path d="M98 24 C95 19, 90 23, 98 31 C106 23, 101 19, 98 24 Z" fill={color} fillOpacity="0.8" />
        </g>
      );
    case 'flames':
      return (
        <g className={animPulse}>
          <path d="M16 96 C10 82, 22 72, 18 58 C26 68, 28 82, 20 96 Z" fill={color} />
          <path d="M104 96 C96 82, 98 68, 106 58 C102 72, 114 82, 104 96 Z" fill="#F1C21B" />
        </g>
      );
    case 'snow':
      return (
        <g className={animFloat} stroke={color} strokeWidth="1.6" strokeLinecap="round">
          <line x1="20" y1="18" x2="20" y2="28" />
          <line x1="15" y1="23" x2="25" y2="23" />
          <circle cx="98" cy="24" r="2.2" fill={color} stroke="none" />
          <circle cx="102" cy="88" r="2.6" fill="#F4F4F4" stroke="none" />
          <circle cx="18" cy="90" r="2" fill={color} stroke="none" />
        </g>
      );
    case 'electric-effects':
      return (
        <g className={animPulse} fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="16,38 22,28 16,24 24,14" />
          <polyline points="104,82 98,92 104,96 96,106" />
        </g>
      );
    case 'orbiting-objects':
    case 'holographic-ring':
      return (
        <g className={animSpin}>
          <ellipse cx="60" cy="60" rx="54" ry="22" fill="none" stroke={color} strokeOpacity="0.65" strokeWidth="1.8" transform="rotate(-24 60 60)" />
          <circle cx="108" cy="39" r="4" fill="#F4F4F4" />
          <circle cx="12" cy="81" r="3.5" fill={color} />
        </g>
      );
    case 'pixel-accessories':
    default:
      return (
        <g className={animPulse}>
          <rect x="14" y="16" width="6" height="6" fill={color} />
          <rect x="22" y="22" width="4" height="4" fill="#F4F4F4" />
          <rect x="98" y="20" width="6" height="6" fill={color} />
          <rect x="94" y="96" width="6" height="6" fill="#78A9FF" />
        </g>
      );
  }
}

function renderBadgeVariant(variant: string, color: string, animPulse: string) {
  const shortText =
    variant === 'badge-1d'
      ? '1D'
      : variant === 'badge-7d'
      ? '7D'
      : variant === 'badge-1y'
      ? '1Y'
      : variant === 'founder-badge'
      ? 'F'
      : variant === 'legacy-badge'
      ? '5Y'
      : '★';
  return (
    <g className={animPulse}>
      <polygon points="20,2 36,11 36,29 20,38 4,29 4,11" fill="#161616" stroke={color} strokeWidth="3" />
      <text
        x="20"
        y="25"
        textAnchor="middle"
        fill="#F4F4F4"
        fontSize="13"
        fontWeight="700"
        fontFamily="monospace"
      >
        {shortText}
      </text>
    </g>
  );
}
