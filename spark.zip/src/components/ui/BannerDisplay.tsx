import React from 'react';
import type { BannerPattern, ProfileBannerConfig } from '../../types/spark';

const IMG_ALPINE_RIDGE = '/src/assets/images/spark_moment_alpine_ridge_1795448049610.jpg';

interface BannerDisplayProps {
  banner: ProfileBannerConfig;
  accentColor?: string;
  className?: string;
}

function renderBannerPattern(pattern: BannerPattern | undefined, uid: string) {
  if (!pattern || pattern === 'none') return null;

  switch (pattern) {
    case 'grid':
      return (
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" aria-hidden="true">
          <defs>
            <pattern id={`pat-grid-${uid}`} width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#F4F4F4" strokeOpacity="0.3" strokeWidth="0.7" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#pat-grid-${uid})`} />
        </svg>
      );
    case 'dots':
      return (
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-35" aria-hidden="true">
          <defs>
            <pattern id={`pat-dots-${uid}`} width="18" height="18" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1.1" fill="#F4F4F4" fillOpacity="0.45" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#pat-dots-${uid})`} />
        </svg>
      );
    case 'diagonal':
      return (
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-25" aria-hidden="true">
          <defs>
            <pattern
              id={`pat-diag-${uid}`}
              width="16"
              height="16"
              patternTransform="rotate(35)"
              patternUnits="userSpaceOnUse"
            >
              <line x1="0" y1="0" x2="0" y2="16" stroke="#F4F4F4" strokeOpacity="0.45" strokeWidth="1.2" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#pat-diag-${uid})`} />
        </svg>
      );
    case 'waves':
      return (
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" aria-hidden="true">
          <defs>
            <pattern id={`pat-waves-${uid}`} width="48" height="20" patternUnits="userSpaceOnUse">
              <path
                d="M0 10 Q12 2, 24 10 T48 10"
                fill="none"
                stroke="#F4F4F4"
                strokeOpacity="0.4"
                strokeWidth="1"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#pat-waves-${uid})`} />
        </svg>
      );
    case 'topographic':
      return (
        <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-30" aria-hidden="true">
          <defs>
            <pattern id={`pat-topo-${uid}`} width="80" height="80" patternUnits="userSpaceOnUse">
              <path
                d="M10 40 C22 15, 58 15, 70 40 C58 65, 22 65, 10 40 Z"
                fill="none"
                stroke="#F4F4F4"
                strokeOpacity="0.35"
                strokeWidth="0.9"
              />
              <path
                d="M22 40 C28 24, 52 24, 58 40 C52 56, 28 56, 22 40 Z"
                fill="none"
                stroke="#78A9FF"
                strokeOpacity="0.4"
                strokeWidth="0.8"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill={`url(#pat-topo-${uid})`} />
        </svg>
      );
    default:
      return null;
  }
}

export const BannerDisplay: React.FC<BannerDisplayProps> = ({
  banner,
  accentColor = '#0F62FE',
  className = 'h-36 sm:h-44',
}) => {
  const uid = React.useId().replace(/:/g, '');
  const [imgFailed, setImgFailed] = React.useState(false);

  React.useEffect(() => {
    setImgFailed(false);
  }, [banner.imageUrl]);

  if (banner.removed) {
    return (
      <div
        className={`relative overflow-hidden bg-[#181818] border-b border-[#333333] ${className}`}
      >
        <div
          className="absolute bottom-0 left-0 right-0 h-0.5"
          style={{ backgroundColor: accentColor }}
        />
      </div>
    );
  }

  const filterStyle: React.CSSProperties = {
    filter: `brightness(${banner.brightness ?? 100}%)`,
  };

  let backgroundStyle: string | undefined;
  let showAlpineImage = false;
  let patternOverlay: BannerPattern | undefined = banner.pattern;

  if (banner.mode === 'template') {
    switch (banner.templateId) {
      case 'alpine':
        showAlpineImage = true;
        break;
      case 'cobalt-mesh':
        backgroundStyle = `radial-gradient(circle at 20% 30%, ${accentColor}55, transparent 55%), linear-gradient(125deg, #12151E 0%, #1F2A3D 60%, #161616 100%)`;
        patternOverlay = patternOverlay ?? 'topographic';
        break;
      case 'nocturne-rain':
        backgroundStyle = 'linear-gradient(135deg, #10131C 0%, #1A2234 55%, #12141A 100%)';
        patternOverlay = patternOverlay ?? 'diagonal';
        break;
      case 'amber-studio':
        backgroundStyle = 'linear-gradient(125deg, #1D1712 0%, #3A2514 55%, #161616 100%)';
        patternOverlay = patternOverlay ?? 'dots';
        break;
      case 'mono-slate':
        backgroundStyle = 'linear-gradient(120deg, #161616 0%, #2E2E2E 60%, #181818 100%)';
        break;
      case 'obsidian-grid':
      default:
        backgroundStyle = 'linear-gradient(120deg, #141414 0%, #20232B 100%)';
        patternOverlay = patternOverlay ?? 'grid';
        break;
    }
  } else if (banner.mode === 'builder') {
    const c1 = banner.primaryColor || '#161616';
    const c2 = banner.secondaryColor || accentColor;
    backgroundStyle = `linear-gradient(125deg, ${c1} 0%, ${c2} 100%)`;
  }

  return (
    <div
      className={`relative overflow-hidden bg-[#161616] border-b border-[#333333] ${className}`}
    >
      {banner.mode === 'upload' && banner.imageUrl && !imgFailed ? (
        <img
          src={banner.imageUrl}
          alt={banner.name || 'Custom profile banner'}
          className="w-full h-full object-cover"
          onError={() => setImgFailed(true)}
          style={{
            ...filterStyle,
            objectPosition: `${banner.posX}% ${banner.posY}%`,
            transform: `scale(${banner.zoom})`,
            transformOrigin: `${banner.posX}% ${banner.posY}%`,
          }}
        />
      ) : showAlpineImage ? (
        <img
          src={IMG_ALPINE_RIDGE}
          alt="Alpine Ridge banner"
          className="w-full h-full object-cover"
          style={{
            ...filterStyle,
            objectPosition: `${banner.posX}% ${banner.posY}%`,
            transform: `scale(${banner.zoom})`,
            transformOrigin: `${banner.posX}% ${banner.posY}%`,
          }}
        />
      ) : (
        <div
          className="w-full h-full relative"
          style={{
            ...filterStyle,
            background: backgroundStyle,
          }}
        >
          {renderBannerPattern(patternOverlay, uid)}
        </div>
      )}

      {/* Subtle bottom gradient for avatar readability */}
      <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#161616]/75 to-transparent pointer-events-none" />
      <div
        className="absolute bottom-0 left-0 right-0 h-0.5 pointer-events-none"
        style={{ backgroundColor: accentColor }}
      />
    </div>
  );
};
