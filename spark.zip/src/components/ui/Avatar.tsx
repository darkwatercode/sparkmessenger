import React from 'react';
import type {
  AvatarFrameStyle,
  AvatarImageConfig,
  EquippedAccessoriesMap,
  OnlinePresence,
} from '../../types/spark';
import { AccessoryRenderer, getAccessoryById } from './AccessoryRenderer';

interface AvatarProps {
  name: string;
  initials: string;
  color: string;
  avatarUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  presence?: OnlinePresence;
  frame?: AvatarFrameStyle;
  showPresence?: boolean;
  equippedAccessories?: EquippedAccessoriesMap;
  avatarConfig?: AvatarImageConfig;
}

const SIZE_MAP = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-xs',
  lg: 'w-12 h-12 text-sm',
  xl: 'w-20 h-20 text-xl',
};

const FRAME_CLASSES: Record<AvatarFrameStyle, string> = {
  none: 'ring-1 ring-[#393939]',
  cobalt: 'ring-2 ring-[#0F62FE] ring-offset-2 ring-offset-[#161616]',
  'carbon-grid': 'ring-2 ring-[#78A9FF] ring-offset-1 ring-offset-[#262626]',
  'amber-brass': 'ring-2 ring-[#D97706] ring-offset-2 ring-offset-[#161616]',
  'mono-double': 'ring-2 ring-[#F4F4F4] ring-offset-2 ring-offset-[#161616]',
};

const PRESENCE_STYLES: Record<OnlinePresence, { bg: string; label: string }> = {
  online: { bg: 'bg-[#42BE65]', label: 'Online' },
  away: { bg: 'bg-[#F1C21B]', label: 'Away' },
  focus: { bg: 'bg-[#78A9FF]', label: 'Focus' },
  offline: { bg: 'bg-[#525252]', label: 'Offline' },
};

export const Avatar: React.FC<AvatarProps> = ({
  name,
  initials,
  color,
  avatarUrl,
  size = 'md',
  presence,
  frame = 'none',
  showPresence = false,
  equippedAccessories,
  avatarConfig,
}) => {
  const [imgFailed, setImgFailed] = React.useState(false);

  const effectiveUrl = avatarConfig ? avatarConfig.url : avatarUrl;
  React.useEffect(() => {
    setImgFailed(false);
  }, [effectiveUrl]);

  const frameEntry = equippedAccessories?.frame;
  const headEntry = equippedAccessories?.head;
  const effectEntry = equippedAccessories?.effect;
  const badgeEntry = equippedAccessories?.badge;

  const frameAcc = getAccessoryById(frameEntry?.accessoryId);
  const headAcc = getAccessoryById(headEntry?.accessoryId);
  const effectAcc = getAccessoryById(effectEntry?.accessoryId);
  const badgeAcc = getAccessoryById(badgeEntry?.accessoryId);

  const showDetails = size !== 'xs';

  const imgStyle: React.CSSProperties | undefined = avatarConfig
    ? {
        objectPosition: `${avatarConfig.posX}% ${avatarConfig.posY}%`,
        transform: `scale(${avatarConfig.zoom})`,
        transformOrigin: `${avatarConfig.posX}% ${avatarConfig.posY}%`,
      }
    : undefined;

  return (
    <div className="relative inline-flex shrink-0 select-none">
      {/* Inner Clipped Avatar Surface */}
      <div
        className={`${SIZE_MAP[size]} ${frameAcc ? '' : FRAME_CLASSES[frame]} rounded-sm overflow-hidden flex items-center justify-center font-medium tracking-tight text-[#F4F4F4] relative z-10`}
        style={{ backgroundColor: color }}
        aria-label={name}
      >
        {effectiveUrl && !imgFailed ? (
          <img
            src={effectiveUrl}
            alt={name}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            style={imgStyle}
            className="w-full h-full object-cover transition-transform duration-150"
          />
        ) : (
          <span className="font-mono-tabular">{initials}</span>
        )}
      </div>

      {/* Layered Cosmetics (Never clipped by inner avatar box) */}
      {frameAcc && frameEntry && (
        <AccessoryRenderer
          accessory={frameAcc}
          transform={frameEntry.transform}
          size={size}
        />
      )}
      {showDetails && headAcc && headEntry && (
        <AccessoryRenderer
          accessory={headAcc}
          transform={headEntry.transform}
          size={size}
        />
      )}
      {showDetails && effectAcc && effectEntry && (
        <AccessoryRenderer
          accessory={effectAcc}
          transform={effectEntry.transform}
          size={size}
        />
      )}
      {showDetails && badgeAcc && badgeEntry && (
        <AccessoryRenderer
          accessory={badgeAcc}
          transform={badgeEntry.transform}
          size={size}
        />
      )}

      {showPresence && presence && (
        <span
          title={PRESENCE_STYLES[presence].label}
          aria-label={`Status: ${PRESENCE_STYLES[presence].label}`}
          className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-xs border border-[#161616] z-40 ${PRESENCE_STYLES[presence].bg}`}
        />
      )}
    </div>
  );
};
