import React from 'react';
import { LogOut, X } from 'lucide-react';
import { useSparkStore } from '../../store/useSparkStore';

export const SettingsModal: React.FC = () => {
  const { user, settingsOpen, setSettingsOpen, updateSettings, logout } = useSparkStore();

  if (!settingsOpen || !user) return null;

  const { settings } = user;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Settings"
        className="w-full max-w-md bg-[#212121] border border-[#393939] p-6"
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#333333] mb-5">
          <div>
            <h2 className="font-display text-base font-semibold text-[#F4F4F4]">Settings</h2>
            <p className="text-xs text-[#A8A8A8]">@{user.username}</p>
          </div>
          <button
            type="button"
            onClick={() => setSettingsOpen(false)}
            aria-label="Close settings"
            className="w-8 h-8 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4">
          <label className="flex items-start justify-between gap-4 cursor-pointer">
            <div>
              <div className="text-sm font-medium text-[#F4F4F4]">Hide online status</div>
              <div className="text-xs text-[#A8A8A8]">
                Appear offline to friends even while active on Spark.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.hideOnlineStatus}
              onChange={(e) => void updateSettings({ hideOnlineStatus: e.target.checked })}
              className="mt-1 w-4 h-4 accent-[#0F62FE] cursor-pointer"
            />
          </label>

          <label className="flex items-start justify-between gap-4 cursor-pointer">
            <div>
              <div className="text-sm font-medium text-[#F4F4F4]">Show last seen</div>
              <div className="text-xs text-[#A8A8A8]">
                Display when you were last active when offline.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.showLastSeen}
              onChange={(e) => void updateSettings({ showLastSeen: e.target.checked })}
              className="mt-1 w-4 h-4 accent-[#0F62FE] cursor-pointer"
            />
          </label>

          <label className="flex items-start justify-between gap-4 cursor-pointer">
            <div>
              <div className="text-sm font-medium text-[#F4F4F4]">Read receipts</div>
              <div className="text-xs text-[#A8A8A8]">
                Let friends see when you read incoming messages.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.readReceipts}
              onChange={(e) => void updateSettings({ readReceipts: e.target.checked })}
              className="mt-1 w-4 h-4 accent-[#0F62FE] cursor-pointer"
            />
          </label>

          <label className="flex items-start justify-between gap-4 cursor-pointer">
            <div>
              <div className="text-sm font-medium text-[#F4F4F4]">Reduce motion</div>
              <div className="text-xs text-[#A8A8A8]">
                Minimize UI and collectible gift animations.
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.reduceMotion}
              onChange={(e) => void updateSettings({ reduceMotion: e.target.checked })}
              className="mt-1 w-4 h-4 accent-[#0F62FE] cursor-pointer"
            />
          </label>
        </div>

        <div className="mt-6 pt-4 border-t border-[#333333] flex items-center justify-between">
          <button
            type="button"
            onClick={() => void logout()}
            className="h-9 px-3.5 bg-[#DA1E28]/15 hover:bg-[#DA1E28]/25 border border-[#FA4D56]/60 text-xs font-medium text-[#FFB3B8] flex items-center gap-2 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log out</span>
          </button>

          <button
            type="button"
            onClick={() => setSettingsOpen(false)}
            className="h-9 px-4 bg-[#262626] hover:bg-[#333333] border border-[#393939] text-xs text-[#F4F4F4] cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
