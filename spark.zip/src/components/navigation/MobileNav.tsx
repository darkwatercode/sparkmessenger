import React from 'react';
import { Gift, MessageSquare, User, Users } from 'lucide-react';
import { useSparkStore } from '../../store/useSparkStore';
import type { NavSection } from '../../types/spark';

const MOBILE_TABS: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'chats', label: 'Chats', icon: MessageSquare },
  { id: 'friends', label: 'Friends', icon: Users },
  { id: 'gifts', label: 'Gifts', icon: Gift },
  { id: 'profile', label: 'Profile', icon: User },
];

export const MobileNav: React.FC = () => {
  const { activeSection, setActiveSection, conversations, incomingRequests } = useSparkStore();
  const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);
  const requestCount = incomingRequests.length;

  return (
    <nav
      aria-label="Mobile navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#212121]/95 backdrop-blur-md border-t border-[#333333] grid grid-cols-4 items-center"
    >
      {MOBILE_TABS.map((tab) => {
        const Icon = tab.icon;
        const active = activeSection === tab.id;
        const badge =
          tab.id === 'chats' ? totalUnread : tab.id === 'friends' ? requestCount : 0;

        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveSection(tab.id)}
            aria-current={active ? 'page' : undefined}
            className={`relative h-full min-h-[44px] flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
              active ? 'text-[#78A9FF]' : 'text-[#A8A8A8]'
            }`}
          >
            <span className="relative">
              <Icon className="w-5 h-5" />
              {badge > 0 && (
                <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 bg-[#0F62FE] text-white text-[10px] font-mono-tabular flex items-center justify-center">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </span>
            <span className="text-[11px] font-medium tracking-tight">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
