import React from 'react';
import { Gift, LogOut, MessageSquare, Settings, Sparkles, User, Users } from 'lucide-react';
import { useSparkStore } from '../../store/useSparkStore';
import type { NavSection } from '../../types/spark';
import { Avatar } from '../ui/Avatar';

const NAV_ITEMS: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'chats', label: 'Chats', icon: MessageSquare },
  { id: 'friends', label: 'Friends', icon: Users },
  { id: 'gifts', label: 'Gifts', icon: Gift },
  { id: 'profile', label: 'Profile', icon: User },
];

export const SidebarRail: React.FC = () => {
  const {
    user,
    activeSection,
    setActiveSection,
    setSettingsOpen,
    logout,
    conversations,
    incomingRequests,
  } = useSparkStore();

  if (!user) return null;

  const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);
  const requestCount = incomingRequests.length;

  return (
    <aside className="hidden md:flex flex-col w-20 lg:w-56 shrink-0 bg-[#212121] border-r border-[#333333] select-none">
      <div className="h-14 px-4 flex items-center gap-3 border-b border-[#333333]">
        <div className="w-8 h-8 bg-[#0F62FE] flex items-center justify-center text-white shrink-0">
          <Sparkles className="w-4 h-4" />
        </div>
        <span className="hidden lg:block font-display text-base font-semibold tracking-tight text-[#F4F4F4]">
          Spark
        </span>
      </div>

      <nav className="flex-1 py-3 px-2 space-y-1" aria-label="Main navigation">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          const badge =
            item.id === 'chats' ? totalUnread : item.id === 'friends' ? requestCount : 0;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveSection(item.id)}
              aria-current={active ? 'page' : undefined}
              className={`w-full h-11 px-3 flex items-center justify-center lg:justify-between transition-colors cursor-pointer ${
                active
                  ? 'bg-[#262626] text-[#F4F4F4] border-l-2 border-[#0F62FE]'
                  : 'text-[#A8A8A8] hover:text-[#F4F4F4] hover:bg-[#262626]/60'
              }`}
            >
              <span className="flex items-center gap-3">
                <Icon className="w-5 h-5 shrink-0" />
                <span className="hidden lg:inline text-sm font-medium">{item.label}</span>
              </span>
              {badge > 0 && (
                <span className="hidden lg:inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 bg-[#0F62FE] text-white text-[11px] font-mono-tabular font-semibold">
                  {badge > 99 ? '99+' : badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-2 border-t border-[#333333] space-y-1">
        <div className="hidden lg:flex items-center gap-2.5 px-2.5 py-2">
          <Avatar
            name={user.displayName}
            initials={user.initials}
            color={user.avatarColor}
            avatarUrl={user.avatarUrl ?? undefined}
            size="sm"
            presence={user.settings.hideOnlineStatus ? 'offline' : 'online'}
            showPresence
            equippedAccessories={user.equippedAccessories}
          />
          <div className="min-w-0 flex-1">
            <div className="text-xs font-medium text-[#F4F4F4] truncate">{user.displayName}</div>
            <div className="text-[11px] text-[#A8A8A8] truncate">@{user.username}</div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-1">
          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            aria-label="Settings"
            title="Settings"
            className="w-full lg:flex-1 h-10 px-2.5 flex items-center justify-center lg:justify-start gap-2 text-xs text-[#A8A8A8] hover:text-[#F4F4F4] hover:bg-[#262626] transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4 shrink-0" />
            <span className="hidden lg:inline">Settings</span>
          </button>

          <button
            type="button"
            onClick={() => void logout()}
            aria-label="Log out"
            title="Log out"
            className="w-full lg:w-10 h-10 flex items-center justify-center text-[#A8A8A8] hover:text-[#FA4D56] hover:bg-[#262626] transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
