import React, { useMemo, useState } from 'react';
import { ArrowUpRight, Coins, Gift as GiftIcon, Search, Send, Sparkles, X } from 'lucide-react';
import { toGiftArtworkModel } from '../../data/giftsCatalog';
import { useSparkStore } from '../../store/useSparkStore';
import type { CatalogGift, OwnedGiftItem } from '../../types/spark';
import { GiftArtwork, RARITY_COLOR } from './GiftArtwork';

export const GiftsView: React.FC = () => {
  const {
    user,
    friends,
    giftCatalog,
    ownedGifts,
    purchaseGift,
    sendGiftToFriend,
    upgradeGift,
    setActiveSection,
  } = useSparkStore();

  const [tab, setTab] = useState<'owned' | 'shop'>('owned');
  const [category, setCategory] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | number | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [sendTargetGift, setSendTargetGift] = useState<CatalogGift | null>(null);
  const [recipientId, setRecipientId] = useState<number | ''>('');
  const [giftNote, setGiftNote] = useState('');

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(giftCatalog.map((g) => g.category)))],
    [giftCatalog]
  );

  const filteredCatalog = useMemo(() => {
    const q = search.trim().toLowerCase();
    return giftCatalog.filter((item) => {
      if (category !== 'All' && item.category !== category) return false;
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.rarity.toLowerCase().includes(q)
      );
    });
  }, [giftCatalog, category, search]);

  if (!user) return null;

  const handleBuy = async (gift: CatalogGift) => {
    setBusyId(gift.id);
    setFeedback(null);
    try {
      await purchaseGift(gift.id);
      setFeedback({ type: 'ok', text: `Purchased ${gift.name}.` });
      setTab('owned');
    } catch (err: unknown) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Unable to purchase gift.',
      });
    } finally {
      setBusyId(null);
    }
  };

  const handleUpgrade = async (owned: OwnedGiftItem, name: string) => {
    setBusyId(owned.id);
    setFeedback(null);
    try {
      await upgradeGift(owned.id);
      setFeedback({ type: 'ok', text: `Upgraded ${name} to Level ${owned.level + 1}.` });
    } catch (err: unknown) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Unable to upgrade gift.',
      });
    } finally {
      setBusyId(null);
    }
  };

  const handleSendSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sendTargetGift || !recipientId) return;
    setBusyId(sendTargetGift.id);
    setFeedback(null);
    try {
      await sendGiftToFriend(Number(recipientId), sendTargetGift.id, giftNote);
      setFeedback({ type: 'ok', text: `Sent ${sendTargetGift.name}!` });
      setSendTargetGift(null);
      setGiftNote('');
      setRecipientId('');
    } catch (err: unknown) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to send gift.',
      });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#161616] pb-20 md:pb-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#333333]">
          <div>
            <h1 className="font-display text-xl font-semibold text-[#F4F4F4]">Gifts</h1>
            <p className="text-xs text-[#A8A8A8] mt-0.5">
              Collect animated gifts or send them directly into a friend&apos;s chat.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-9 px-3 bg-[#212121] border border-[#393939] flex items-center gap-2 text-xs">
              <Coins className="w-3.5 h-3.5 text-[#F1C21B]" />
              <span className="font-mono-tabular font-semibold text-[#F4F4F4]">{user.coins}</span>
              <span className="text-[#A8A8A8]">credits</span>
            </div>

            <div className="grid grid-cols-2 border border-[#393939] bg-[#212121] p-0.5">
              <button
                type="button"
                onClick={() => setTab('owned')}
                className={`h-8 px-3 text-xs font-medium transition-colors cursor-pointer ${
                  tab === 'owned' ? 'bg-[#0F62FE] text-white' : 'text-[#A8A8A8] hover:text-[#F4F4F4]'
                }`}
              >
                My Gifts ({ownedGifts.length})
              </button>
              <button
                type="button"
                onClick={() => setTab('shop')}
                className={`h-8 px-3 text-xs font-medium transition-colors cursor-pointer ${
                  tab === 'shop' ? 'bg-[#0F62FE] text-white' : 'text-[#A8A8A8] hover:text-[#F4F4F4]'
                }`}
              >
                Shop
              </button>
            </div>
          </div>
        </header>

        {feedback && (
          <div
            className={`px-3.5 py-2.5 border text-xs flex items-center justify-between ${
              feedback.type === 'ok'
                ? 'bg-[#198038]/15 border-[#42BE65]/60 text-[#A7F0BA]'
                : 'bg-[#DA1E28]/15 border-[#FA4D56]/60 text-[#FFB3B8]'
            }`}
          >
            <span>{feedback.text}</span>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              aria-label="Dismiss"
              className="cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {tab === 'owned' ? (
          ownedGifts.length === 0 ? (
            <div className="bg-[#212121] border border-[#333333] p-10 text-center">
              <div className="w-12 h-12 mx-auto bg-[#262626] border border-[#393939] flex items-center justify-center text-[#A8A8A8] mb-3">
                <GiftIcon className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-[#F4F4F4] mb-1">No gifts collected yet</p>
              <p className="text-xs text-[#A8A8A8] max-w-sm mx-auto mb-5">
                Purchase an animated collectible from the Shop or receive one from a friend.
              </p>
              <button
                type="button"
                onClick={() => setTab('shop')}
                className="h-10 px-4 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium cursor-pointer"
              >
                Browse Gift Shop
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {ownedGifts.map((owned) => {
                const cat = giftCatalog.find((g) => g.id === owned.catalogGiftId);
                if (!cat) return null;
                const upgradeCost = owned.level * 150;
                return (
                  <div
                    key={owned.id}
                    className="bg-[#212121] border border-[#333333] p-4 flex flex-col justify-between gap-4"
                  >
                    <div className="flex items-start gap-3.5">
                      <GiftArtwork
                        gift={toGiftArtworkModel(cat, {
                          serialNumber: owned.serialNumber,
                          level: owned.level,
                        })}
                        size="md"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="text-sm font-semibold text-[#F4F4F4] truncate">
                            {cat.name}
                          </h3>
                          <span className="text-[11px] font-mono-tabular text-[#A8A8A8]">
                            {owned.serialNumber}
                          </span>
                        </div>
                        <div
                          className="text-[11px] font-medium mt-0.5"
                          style={{ color: RARITY_COLOR[cat.rarity] }}
                        >
                          {cat.rarity} • Level {owned.level}/5
                        </div>
                        {owned.senderUsername && (
                          <p className="text-[11px] text-[#A8A8A8] mt-1">
                            From @{owned.senderUsername}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#2E2E2E]">
                      {owned.level < 5 ? (
                        <button
                          type="button"
                          disabled={busyId === owned.id}
                          onClick={() => void handleUpgrade(owned, cat.name)}
                          className="w-full h-9 bg-[#262626] hover:bg-[#333333] border border-[#393939] text-xs text-[#F4F4F4] flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-[#78A9FF]" />
                          <span>Upgrade ({upgradeCost} credits)</span>
                        </button>
                      ) : (
                        <span className="w-full h-9 flex items-center justify-center text-xs text-[#42BE65]">
                          Max Level Reached
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )
        ) : (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#8D8D8D] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search collectibles..."
                  className="w-full h-10 pl-9 pr-3 bg-[#212121] border border-[#393939] text-xs text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE]"
                />
              </div>

              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                aria-label="Filter gift category"
                className="h-10 px-3 bg-[#212121] border border-[#393939] text-xs text-[#F4F4F4] focus:outline-none focus:border-[#0F62FE]"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCatalog.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#212121] border border-[#333333] p-4 flex flex-col justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <GiftArtwork gift={toGiftArtworkModel(item)} size="md" />
                    <div className="min-w-0 flex-1">
                      <h3 className="text-sm font-semibold text-[#F4F4F4] truncate">{item.name}</h3>
                      <div
                        className="text-[11px] font-medium mt-0.5"
                        style={{ color: RARITY_COLOR[item.rarity] }}
                      >
                        {item.rarity} • {item.category}
                      </div>
                      <p className="text-xs text-[#A8A8A8] mt-1.5 line-clamp-2">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#2E2E2E]">
                    <span className="text-xs font-mono-tabular font-semibold text-[#F4F4F4]">
                      {item.priceCredits} cr
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={busyId === item.id || user.coins < item.priceCredits}
                        onClick={() => {
                          setSendTargetGift(item);
                          setRecipientId(friends[0]?.id ?? '');
                        }}
                        className="h-8 px-2.5 bg-[#262626] hover:bg-[#333333] border border-[#393939] disabled:opacity-40 text-xs text-[#F4F4F4] flex items-center gap-1 cursor-pointer"
                      >
                        <Send className="w-3 h-3" />
                        <span>Send</span>
                      </button>
                      <button
                        type="button"
                        disabled={busyId === item.id || user.coins < item.priceCredits}
                        onClick={() => void handleBuy(item)}
                        className="h-8 px-3 bg-[#0F62FE] hover:bg-[#0353E9] disabled:opacity-40 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                      >
                        <span>Buy</span>
                        <ArrowUpRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Send Gift to Friend Modal */}
      {sendTargetGift && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#212121] border border-[#393939] p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-base font-semibold text-[#F4F4F4]">
                Send {sendTargetGift.name}
              </h2>
              <button
                type="button"
                onClick={() => setSendTargetGift(null)}
                aria-label="Close"
                className="w-8 h-8 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {friends.length === 0 ? (
              <div className="space-y-4">
                <p className="text-xs text-[#A8A8A8]">
                  Add a friend first so you can send them a collectible gift in chat.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSendTargetGift(null);
                    setActiveSection('friends');
                  }}
                  className="w-full h-10 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium cursor-pointer"
                >
                  Go to Friends
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs text-[#A8A8A8] mb-1.5">Recipient</label>
                  <select
                    value={recipientId}
                    onChange={(e) => setRecipientId(Number(e.target.value))}
                    className="w-full h-10 px-3 bg-[#161616] border border-[#393939] text-sm text-[#F4F4F4] focus:outline-none focus:border-[#0F62FE]"
                    required
                  >
                    {friends.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.displayName} (@{f.username})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#A8A8A8] mb-1.5">Message note</label>
                  <input
                    type="text"
                    value={giftNote}
                    onChange={(e) => setGiftNote(e.target.value)}
                    placeholder="Optional note..."
                    className="w-full h-10 px-3 bg-[#161616] border border-[#393939] text-sm text-[#F4F4F4] focus:outline-none focus:border-[#0F62FE]"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSendTargetGift(null)}
                    className="h-10 px-4 bg-[#262626] border border-[#393939] text-xs text-[#F4F4F4] cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={busyId === sendTargetGift.id}
                    className="h-10 px-4 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium cursor-pointer"
                  >
                    Send ({sendTargetGift.priceCredits} cr)
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
