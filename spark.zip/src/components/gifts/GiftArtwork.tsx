import React from 'react';
import type { Gift, GiftCategory, GiftRarity } from '../../types/spark';

export type GiftArtworkSize = 'sm' | 'md' | 'lg' | 'xl' | 'stage';

interface GiftArtworkProps {
  gift: Gift;
  size?: GiftArtworkSize;
  animated?: boolean;
  interactive3D?: boolean;
  showRibbon?: boolean;
  className?: string;
}

export const RARITY_COLOR: Record<GiftRarity, string> = {
  Common: '#A8A8A8',
  Uncommon: '#42BE65',
  Rare: '#78A9FF',
  Epic: '#3B82F6',
  Legendary: '#F1C21B',
  Mythic: '#FF832B',
  Limited: '#FA4D56',
  Exclusive: '#F4F4F4',
};

export const BACKDROP_LABEL: Record<GiftCategory, string> = {
  Animals: 'Fauna Slate',
  Flowers: 'Botanical Dusk',
  Jewelry: 'Foundry Velvet',
  Technology: 'Phosphor Matrix',
  Fantasy: 'Arcane Nebula',
  Food: 'Studio Ceramic',
  'Luxury objects': 'Obsidian Radial',
  Collectibles: 'Archive Cobalt',
  'Seasonal gifts': 'Arctic Solstice',
  'Meme-inspired gifts': 'Signal Neon',
  'Special limited editions': 'Sovereign Foundry',
};

const SIZE_CLASSES: Record<GiftArtworkSize, string> = {
  sm: 'w-12 h-12',
  md: 'w-20 h-20',
  lg: 'w-36 h-36',
  xl: 'w-56 h-56',
  stage: 'w-full h-44',
};

function renderPatternGlyph(category: GiftCategory, color: string) {
  switch (category) {
    case 'Animals':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.16" strokeWidth="0.8">
          <path d="M12 5 C15 8, 17 11, 12 19 C7 11, 9 8, 12 5 Z" />
        </g>
      );
    case 'Flowers':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.16" strokeWidth="0.8">
          <circle cx="12" cy="8" r="2.2" />
          <circle cx="16" cy="12" r="2.2" />
          <circle cx="12" cy="16" r="2.2" />
          <circle cx="8" cy="12" r="2.2" />
        </g>
      );
    case 'Jewelry':
    case 'Luxury objects':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.18" strokeWidth="0.8">
          <polygon points="12,4 19,12 12,20 5,12" />
          <circle cx="12" cy="12" r="2.2" />
        </g>
      );
    case 'Technology':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.15" strokeWidth="0.8">
          <rect x="6" y="6" width="12" height="12" rx="1.5" />
          <circle cx="12" cy="12" r="2" fill={color} fillOpacity="0.14" />
        </g>
      );
    case 'Fantasy':
    case 'Special limited editions':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.18" strokeWidth="0.8">
          <path d="M12 4 L13.4 10.6 L20 12 L13.4 13.4 L12 20 L10.6 13.4 L4 12 L10.6 10.6 Z" />
        </g>
      );
    case 'Seasonal gifts':
      return (
        <g fill="none" stroke={color} strokeOpacity="0.16" strokeWidth="0.8">
          <line x1="12" y1="4" x2="12" y2="20" />
          <line x1="4" y1="12" x2="20" y2="12" />
          <line x1="6.5" y1="6.5" x2="17.5" y2="17.5" />
          <line x1="17.5" y1="6.5" x2="6.5" y2="17.5" />
        </g>
      );
    default:
      return (
        <g fill="none" stroke={color} strokeOpacity="0.14" strokeWidth="0.8">
          <polygon points="12,5 18,9 18,15 12,19 6,15 6,9" />
        </g>
      );
  }
}

function renderTgCollectible(
  variant: string,
  accent: string,
  rarityColor: string,
  uid: string,
  animated: boolean
) {
  const animFloat = animated ? 'gift-anim-float' : '';
  const animSpin = animated ? 'gift-anim-spin' : '';
  const animSpinFast = animated ? 'gift-anim-spin-fast' : '';
  const animSpinRev = animated ? 'gift-anim-spin-reverse' : '';
  const animSwing = animated ? 'gift-anim-swing' : '';
  const animPulse = animated ? 'gift-anim-pulse' : '';
  const animWave = animated ? 'gift-anim-wave' : '';
  const animWing = animated ? 'gift-anim-wing' : '';

  const metalGrad = `url(#metal-${uid})`;
  const accentGrad = `url(#accent-${uid})`;
  const coreGlow = `url(#glow-${uid})`;

  switch (variant) {
    // ANIMALS
    case 'cyber-koi':
    case 'koi-crest':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="36" fill="#131922" stroke={accent} strokeWidth="2" />
          <circle cx="60" cy="58" r="28" fill="none" stroke={rarityColor} strokeOpacity="0.45" strokeWidth="1.2" strokeDasharray="4 4" className={animPulse} />
          <g className={animSpin}>
            <path d="M60 32 C74 32, 82 44, 76 56 C72 64, 62 56, 60 48 C58 40, 50 32, 60 32 Z" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.7" strokeWidth="1.2" />
            <path d="M60 84 C46 84, 38 72, 44 60 C48 52, 58 60, 60 68 C62 76, 70 84, 60 84 Z" fill={rarityColor} fillOpacity="0.85" stroke="#F4F4F4" strokeOpacity="0.7" strokeWidth="1.2" />
          </g>
        </g>
      );
    case 'clockwork-owl':
      return (
        <g className={animFloat}>
          <ellipse cx="60" cy="96" rx="24" ry="4" fill="#000" fillOpacity="0.4" />
          <ellipse cx="60" cy="60" rx="26" ry="30" fill={metalGrad} stroke={rarityColor} strokeWidth="2" />
          <polygon points="36,36 42,22 50,34" fill={accentGrad} />
          <polygon points="84,36 78,22 70,34" fill={accentGrad} />
          <circle cx="49" cy="48" r="9" fill="#161616" stroke={rarityColor} strokeWidth="2" />
          <circle cx="71" cy="48" r="9" fill="#161616" stroke={rarityColor} strokeWidth="2" />
          <circle cx="49" cy="48" r="3.5" fill={coreGlow} className={animPulse} />
          <circle cx="71" cy="48" r="3.5" fill={coreGlow} className={animPulse} />
          <polygon points="60,54 55,62 65,62" fill={rarityColor} />
          <circle cx="60" cy="74" r="8" fill="none" stroke={accent} strokeWidth="1.8" strokeDasharray="3 3" className={animSpin} />
        </g>
      );
    case 'origami-fox':
      return (
        <g className={animFloat}>
          <ellipse cx="60" cy="96" rx="24" ry="4" fill="#000" fillOpacity="0.4" />
          <polygon points="30,30 46,48 26,64" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.6" strokeWidth="1.4" />
          <polygon points="90,30 74,48 94,64" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.6" strokeWidth="1.4" />
          <polygon points="26,64 60,40 94,64 60,88" fill={metalGrad} stroke={rarityColor} strokeWidth="1.8" />
          <polygon points="46,66 60,88 74,66" fill={accent} fillOpacity="0.85" />
          <circle cx="48" cy="58" r="2.6" fill="#F4F4F4" />
          <circle cx="72" cy="58" r="2.6" fill="#F4F4F4" />
        </g>
      );
    case 'jellyfish':
      return (
        <g className={animFloat}>
          <path d="M32 54 C32 24, 88 24, 88 54 Z" fill={accentGrad} fillOpacity="0.6" stroke="#E0F2FE" strokeWidth="1.8" />
          <ellipse cx="60" cy="54" rx="28" ry="6" fill={coreGlow} fillOpacity="0.5" />
          <path d="M40 58 Q36 74 44 92 M52 60 Q54 78 48 96 M64 60 Q68 76 62 96 M76 58 Q82 74 74 92" fill="none" stroke={rarityColor} strokeWidth="2.2" strokeLinecap="round" className={animPulse} />
        </g>
      );
    case 'velvet-cat':
      return (
        <g className={animFloat}>
          <polygon points="34,42 36,20 50,36" fill={metalGrad} stroke={accent} strokeWidth="1.8" />
          <polygon points="86,42 84,20 70,36" fill={metalGrad} stroke={accent} strokeWidth="1.8" />
          <circle cx="60" cy="60" r="26" fill={metalGrad} stroke={rarityColor} strokeWidth="1.8" />
          <path d="M30 56 C30 28, 90 28, 90 56" fill="none" stroke={accent} strokeWidth="3.2" />
          <rect x="24" y="48" width="9" height="18" rx="3" fill={accent} />
          <rect x="87" y="48" width="9" height="18" rx="3" fill={accent} />
          <circle cx="50" cy="58" r="3" fill={coreGlow} />
          <circle cx="70" cy="58" r="3" fill={coreGlow} />
        </g>
      );
    case 'cicada':
      return (
        <g className={animFloat}>
          <g className={animWing}>
            <path d="M58 46 C36 26, 18 38, 22 62 C30 70, 48 64, 58 54 Z" fill={accentGrad} fillOpacity="0.35" stroke={rarityColor} strokeWidth="1.5" />
            <path d="M62 46 C84 26, 102 38, 98 62 C90 70, 72 64, 62 54 Z" fill={accentGrad} fillOpacity="0.35" stroke={rarityColor} strokeWidth="1.5" />
          </g>
          <ellipse cx="60" cy="56" rx="10" ry="24" fill={metalGrad} stroke={rarityColor} strokeWidth="1.8" />
          <circle cx="54" cy="36" r="3" fill={accent} />
          <circle cx="66" cy="36" r="3" fill={accent} />
        </g>
      );

    // FLOWERS
    case 'obsidian-rose':
      return (
        <g className={animFloat}>
          <line x1="60" y1="62" x2="60" y2="98" stroke="#42BE65" strokeWidth="3" strokeLinecap="round" />
          <path d="M60 76 L76 68" stroke="#42BE65" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="60" cy="44" r="22" fill={metalGrad} stroke={accent} strokeWidth="2" />
          <path d="M44 44 C44 28, 76 28, 76 44 C76 58, 44 58, 44 44 Z" fill={accentGrad} fillOpacity="0.7" stroke="#F4F4F4" strokeOpacity="0.5" strokeWidth="1.2" />
          <path d="M52 42 C52 34, 68 34, 68 42 C68 50, 52 50, 52 42 Z" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'frost-lotus':
      return (
        <g className={animFloat}>
          <polygon points="60,20 72,56 60,78 48,56" fill="#BAE6FD" fillOpacity="0.65" stroke="#F4F4F4" strokeWidth="1.4" />
          <polygon points="36,34 56,56 54,78 30,62" fill={accentGrad} fillOpacity="0.55" stroke="#E0F2FE" strokeWidth="1.4" />
          <polygon points="84,34 64,56 66,78 90,62" fill={accentGrad} fillOpacity="0.55" stroke="#E0F2FE" strokeWidth="1.4" />
          <circle cx="60" cy="56" r="6" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'golden-bonsai':
      return (
        <g className={animFloat}>
          <rect x="34" y="78" width="52" height="14" rx="2" fill={metalGrad} stroke="#8E8E93" strokeWidth="1.6" />
          <path d="M56 78 C54 62, 46 56, 48 44 C50 34, 66 36, 66 48" fill="none" stroke={rarityColor} strokeWidth="4.5" strokeLinecap="round" />
          <ellipse cx="44" cy="40" rx="18" ry="10" fill={accentGrad} fillOpacity="0.85" stroke="#F4F4F4" strokeOpacity="0.5" strokeWidth="1.2" />
          <ellipse cx="74" cy="48" rx="14" ry="8" fill={rarityColor} fillOpacity="0.85" />
          <ellipse cx="62" cy="28" rx="15" ry="9" fill={coreGlow} />
        </g>
      );
    case 'neon-orchid':
      return (
        <g className={animFloat}>
          <path d="M60 94 Q54 68 60 44" fill="none" stroke="#42BE65" strokeWidth="2.6" />
          <circle cx="60" cy="44" r="14" fill="none" stroke={accent} strokeWidth="2.2" />
          <ellipse cx="42" cy="44" rx="12" ry="7" fill={accentGrad} fillOpacity="0.5" stroke="#F4F4F4" strokeOpacity="0.5" strokeWidth="1" />
          <ellipse cx="78" cy="44" rx="12" ry="7" fill={accentGrad} fillOpacity="0.5" stroke="#F4F4F4" strokeOpacity="0.5" strokeWidth="1" />
          <circle cx="60" cy="44" r="6" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'starlight-tulip':
      return (
        <g className={animFloat}>
          <line x1="60" y1="56" x2="60" y2="96" stroke="#42BE65" strokeWidth="3" />
          <path d="M40 36 C40 62, 80 62, 80 36 L68 24 L60 34 L52 24 Z" fill={accentGrad} stroke="#F4F4F4" strokeWidth="1.5" />
          <circle cx="60" cy="20" r="4" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'sakura-branch':
      return (
        <g className={animFloat}>
          <path d="M22 80 Q54 60 96 34" fill="none" stroke="#8E8E93" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="48" cy="54" r="9" fill={accent} fillOpacity="0.85" stroke="#F4F4F4" strokeWidth="1" />
          <circle cx="72" cy="40" r="11" fill={accent} fillOpacity="0.85" stroke="#F4F4F4" strokeWidth="1" />
          <circle cx="88" cy="64" r="4" fill={accent} className={animPulse} />
          <circle cx="38" cy="36" r="3" fill={accent} className={animPulse} />
        </g>
      );

    // JEWELRY
    case 'sapphire-signet':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="64" r="26" fill="none" stroke={metalGrad} strokeWidth="9" />
          <circle cx="60" cy="64" r="26" fill="none" stroke="#8E8E93" strokeWidth="1.5" />
          <polygon points="60,24 76,34 76,48 60,54 44,48 44,34" fill={accentGrad} stroke="#F4F4F4" strokeWidth="1.6" />
          <polygon points="60,28 69,36 60,46 51,36" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'diamond-monocle':
      return (
        <g className={animFloat}>
          <circle cx="58" cy="52" r="28" fill="none" stroke="#E5E7EB" strokeWidth="4.5" />
          <circle cx="58" cy="52" r="22" fill={accentGrad} fillOpacity="0.22" stroke="#F4F4F4" strokeOpacity="0.6" strokeWidth="1" />
          <line x1="80" y1="72" x2="96" y2="96" stroke={rarityColor} strokeWidth="3.5" strokeLinecap="round" />
          <polygon points="58,36 68,52 58,68 48,52" fill={coreGlow} fillOpacity="0.6" className={animPulse} />
        </g>
      );
    case 'emerald-pendant':
      return (
        <g className={animSwing}>
          <polyline points="42,16 60,36 78,16" fill="none" stroke="#E5E7EB" strokeWidth="2" />
          <polygon points="60,36 82,78 38,78" fill="none" stroke="#E5E7EB" strokeWidth="2.4" />
          <polygon points="60,44 74,74 46,74" fill={accentGrad} stroke="#F4F4F4" strokeWidth="1.2" />
          <circle cx="60" cy="62" r="5" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'crown-ring':
      return (
        <g className={animFloat}>
          <polygon points="28,58 34,26 48,42 60,18 72,42 86,26 92,58" fill={metalGrad} stroke={rarityColor} strokeWidth="2.2" />
          <ellipse cx="60" cy="68" rx="32" ry="12" fill="none" stroke={rarityColor} strokeWidth="6" />
          <circle cx="60" cy="18" r="4" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'pearl-brooch':
      return (
        <g className={animFloat}>
          <ellipse cx="60" cy="58" rx="34" ry="14" fill="none" stroke={rarityColor} strokeWidth="2" transform="rotate(-28 60 58)" className={animSpin} />
          <ellipse cx="60" cy="58" rx="34" ry="14" fill="none" stroke={accent} strokeWidth="2" transform="rotate(28 60 58)" className={animSpinRev} />
          <circle cx="60" cy="58" r="16" fill={coreGlow} stroke="#F4F4F4" strokeWidth="1.5" />
        </g>
      );
    case 'starlight-tiara':
      return (
        <g className={animFloat}>
          <path d="M22 68 Q60 78 98 68 L88 42 L72 54 L60 24 L48 54 L32 42 Z" fill={metalGrad} stroke={accent} strokeWidth="2.2" />
          <polygon points="60,28 65,40 60,52 55,40" fill={coreGlow} className={animPulse} />
          <circle cx="32" cy="42" r="3.5" fill={rarityColor} />
          <circle cx="88" cy="42" r="3.5" fill={rarityColor} />
        </g>
      );

    // TECHNOLOGY
    case 'oscilloscope':
      return (
        <g className={animFloat}>
          <rect x="18" y="24" width="84" height="66" rx="9" fill={metalGrad} stroke="#636366" strokeWidth="1.8" />
          <rect x="26" y="32" width="68" height="40" rx="5" fill="#0C1712" stroke={accent} strokeWidth="1.5" />
          <path d="M26 52 Q 38 34, 50 52 T 74 52 T 94 52" fill="none" stroke={rarityColor} strokeWidth="2.4" className={animWave} />
          <circle cx="34" cy="81" r="3.5" fill={rarityColor} className={animPulse} />
          <circle cx="46" cy="81" r="3.5" fill={accent} />
        </g>
      );
    case 'matrix-pin':
      return (
        <g className={animFloat}>
          <rect x="22" y="22" width="76" height="76" rx="8" fill={metalGrad} stroke="#636366" strokeWidth="1.8" />
          {[38, 53, 68, 82].map((y, rIdx) =>
            [38, 53, 68, 82].map((x, cIdx) => {
              const active = (rIdx + cIdx) % 3 === 0;
              return (
                <circle
                  key={`${x}-${y}`}
                  cx={x}
                  cy={y}
                  r={active ? '4.2' : '2.6'}
                  fill={active ? rarityColor : '#3A3A3C'}
                  className={active ? animPulse : ''}
                />
              );
            })
          )}
          <path d="M38 38 C50 20, 74 42, 68 68" fill="none" stroke={accent} strokeWidth="2.4" strokeLinecap="round" />
        </g>
      );
    case 'keycap':
      return (
        <g className={animFloat}>
          <polygon points="24,78 32,30 88,30 96,78" fill={metalGrad} stroke="#525252" strokeWidth="1.8" />
          <rect x="33" y="27" width="54" height="40" rx="7" fill="#242730" stroke={accent} strokeWidth="1.8" />
          <polygon points="60,36 72,47 60,58 48,47" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'tuning-fork':
      return (
        <g className={animFloat}>
          <rect x="44" y="84" width="32" height="10" rx="2" fill={metalGrad} stroke="#636366" strokeWidth="1.4" />
          <path d="M48 22 L48 56 C48 65, 72 65, 72 56 L72 22" fill="none" stroke="#E5E5EA" strokeWidth="5" strokeLinecap="round" />
          <line x1="60" y1="63" x2="60" y2="85" stroke={accent} strokeWidth="5" strokeLinecap="round" />
          <circle cx="60" cy="40" r="24" fill="none" stroke={rarityColor} strokeOpacity="0.45" strokeWidth="1.4" className={animPulse} />
        </g>
      );
    case 'quantum-core':
      return (
        <g className={animFloat}>
          <line x1="36" y1="22" x2="84" y2="22" stroke={rarityColor} strokeWidth="3" />
          <line x1="44" y1="22" x2="44" y2="56" stroke="#8E8E93" strokeWidth="1.6" />
          <line x1="60" y1="22" x2="60" y2="66" stroke={accent} strokeWidth="2" />
          <line x1="76" y1="22" x2="76" y2="56" stroke="#8E8E93" strokeWidth="1.6" />
          <ellipse cx="60" cy="54" rx="28" ry="6" fill="none" stroke={rarityColor} strokeWidth="2" />
          <ellipse cx="60" cy="68" rx="20" ry="5" fill="none" stroke={accent} strokeWidth="2" />
          <circle cx="60" cy="82" r="8" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'turntable':
      return (
        <g className={animFloat}>
          <rect x="18" y="24" width="84" height="68" rx="6" fill={metalGrad} stroke="#636366" strokeWidth="1.8" />
          <g className={animSpin}>
            <circle cx="52" cy="58" r="24" fill="#141414" stroke={accent} strokeWidth="2" />
            <circle cx="52" cy="58" r="14" fill="none" stroke="#393939" strokeWidth="1.2" />
            <circle cx="52" cy="58" r="6" fill={rarityColor} />
          </g>
          <line x1="88" y1="36" x2="74" y2="68" stroke="#E5E5EA" strokeWidth="2.6" strokeLinecap="round" />
          <circle cx="88" cy="36" r="4" fill={rarityColor} />
        </g>
      );
    case 'retro-handheld':
      return (
        <g className={animFloat}>
          <rect x="30" y="18" width="60" height="82" rx="7" fill={metalGrad} stroke="#8E8E93" strokeWidth="1.8" />
          <rect x="38" y="26" width="44" height="32" rx="3" fill="#0C1912" stroke={accent} strokeWidth="1.5" />
          <rect x="46" y="34" width="12" height="12" fill={accent} className={animPulse} />
          <rect x="40" y="70" width="14" height="4" fill="#F4F4F4" />
          <rect x="45" y="65" width="4" height="14" fill="#F4F4F4" />
          <circle cx="74" cy="70" r="3.5" fill={rarityColor} />
          <circle cx="82" cy="76" r="3.5" fill={accent} />
        </g>
      );

    // FANTASY
    case 'phoenix-feather':
      return (
        <g className={animFloat}>
          <path d="M32 90 C36 58, 56 30, 88 20 C84 48, 66 70, 32 90 Z" fill={accentGrad} stroke={rarityColor} strokeWidth="1.8" />
          <line x1="28" y1="94" x2="88" y2="20" stroke="#F4F4F4" strokeWidth="2" strokeLinecap="round" />
          <circle cx="78" cy="32" r="5" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'arcane-grimoire':
      return (
        <g className={animFloat}>
          <rect x="30" y="22" width="60" height="76" rx="4" fill="#1E1A2E" stroke={accent} strokeWidth="2.2" />
          <line x1="40" y1="22" x2="40" y2="98" stroke={rarityColor} strokeWidth="2" />
          <circle cx="64" cy="58" r="14" fill="none" stroke={rarityColor} strokeWidth="1.8" className={animSpin} />
          <polygon points="64,46 74,64 54,64" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'dragon-egg':
      return (
        <g className={animFloat}>
          <path d="M60 18 C82 32, 86 68, 76 84 C68 94, 52 94, 44 84 C34 68, 38 32, 60 18 Z" fill={metalGrad} stroke={accent} strokeWidth="2.2" />
          <polyline points="44,54 58,48 64,64 78,56" fill="none" stroke={rarityColor} strokeWidth="2.5" className={animPulse} />
          <circle cx="60" cy="60" r="6" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'crystal-wand':
      return (
        <g className={animFloat}>
          <line x1="26" y1="92" x2="72" y2="46" stroke="#E5E5EA" strokeWidth="3.5" strokeLinecap="round" />
          <polygon points="80,22 94,38 78,54 64,38" fill={accentGrad} stroke="#F4F4F4" strokeWidth="1.6" className={animPulse} />
          <circle cx="80" cy="38" r="18" fill="none" stroke={rarityColor} strokeOpacity="0.4" strokeWidth="1.2" strokeDasharray="3 3" className={animSpin} />
        </g>
      );
    case 'astrolabe':
      return (
        <g className={animFloat}>
          <g className={animSpin}>
            <circle cx="60" cy="58" r="36" fill="none" stroke={rarityColor} strokeWidth="2.2" />
            <circle cx="60" cy="22" r="3.5" fill={rarityColor} />
          </g>
          <g className={animSpinRev}>
            <ellipse cx="60" cy="58" rx="34" ry="15" fill="none" stroke={accent} strokeWidth="2" transform="rotate(28 60 58)" />
            <ellipse cx="60" cy="58" rx="34" ry="15" fill="none" stroke="#F4F4F4" strokeOpacity="0.55" strokeWidth="1.5" transform="rotate(-34 60 58)" />
          </g>
          <circle cx="60" cy="58" r="9" fill={coreGlow} stroke="#F4F4F4" strokeWidth="1.5" className={animPulse} />
        </g>
      );
    case 'potion-vial':
      return (
        <g className={animFloat}>
          <rect x="52" y="20" width="16" height="10" rx="2" fill="#8E8E93" />
          <polygon points="50,30 70,30 86,62 76,88 44,88 34,62" fill="#132220" stroke="#E5E5EA" strokeWidth="1.8" />
          <polygon points="40,62 80,62 74,84 46,84" fill={accentGrad} fillOpacity="0.8" className={animPulse} />
          <circle cx="56" cy="70" r="3" fill="#F4F4F4" />
        </g>
      );

    // FOOD
    case 'matcha-parfait':
      return (
        <g className={animFloat}>
          <polygon points="40,56 80,56 72,92 48,92" fill={metalGrad} stroke="#8E8E93" strokeWidth="1.6" />
          <circle cx="60" cy="46" r="16" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.5" strokeWidth="1.2" />
          <circle cx="48" cy="52" r="7" fill="#F4F4F4" />
          <rect x="68" y="26" width="6" height="28" rx="2" transform="rotate(14 71 40)" fill="#F1C21B" />
        </g>
      );
    case 'croissant':
      return (
        <g className={animFloat}>
          <path d="M26 66 C32 40, 88 40, 94 66 C78 78, 42 78, 26 66 Z" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.6" strokeWidth="1.5" />
          <line x1="48" y1="45" x2="44" y2="72" stroke="#161616" strokeOpacity="0.4" strokeWidth="2" />
          <line x1="60" y1="43" x2="60" y2="74" stroke="#161616" strokeOpacity="0.4" strokeWidth="2" />
          <line x1="72" y1="45" x2="76" y2="72" stroke="#161616" strokeOpacity="0.4" strokeWidth="2" />
        </g>
      );
    case 'ramen-bowl':
      return (
        <g className={animFloat}>
          <path d="M26 56 L94 56 C92 84, 76 92, 60 92 C44 92, 28 84, 26 56 Z" fill={metalGrad} stroke={rarityColor} strokeWidth="2" />
          <ellipse cx="60" cy="56" rx="34" ry="7" fill="#3A2514" stroke={accent} strokeWidth="1.5" />
          <line x1="44" y1="26" x2="88" y2="48" stroke="#E5E5EA" strokeWidth="2.4" strokeLinecap="round" />
          <line x1="40" y1="34" x2="86" y2="52" stroke="#E5E5EA" strokeWidth="2.4" strokeLinecap="round" />
        </g>
      );
    case 'espresso-press':
      return (
        <g className={animFloat}>
          <rect x="34" y="24" width="52" height="68" rx="4" fill={metalGrad} stroke="#8E8E93" strokeWidth="1.8" />
          <circle cx="60" cy="40" r="9" fill="#161616" stroke={rarityColor} strokeWidth="1.8" />
          <line x1="60" y1="40" x2="65" y2="34" stroke="#F4F4F4" strokeWidth="1.6" />
          <rect x="46" y="64" width="28" height="20" rx="2" fill="#161616" stroke={accent} strokeWidth="1.4" />
        </g>
      );
    case 'neon-donut':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="30" fill="#523624" stroke={accent} strokeWidth="2.5" />
          <circle cx="60" cy="58" r="28" fill="none" stroke={accentGrad} strokeWidth="8" strokeDasharray="36 6" />
          <circle cx="60" cy="58" r="11" fill="#14161B" stroke="#F4F4F4" strokeOpacity="0.4" strokeWidth="1.2" />
        </g>
      );

    // LUXURY OBJECTS & EXISTING
    case 'obsidian-prism':
      return (
        <g className={animFloat}>
          <polygon points="60,16 94,46 80,92 40,92 26,46" fill={metalGrad} stroke={accent} strokeWidth="2.4" />
          <polygon points="60,16 74,48 60,92 46,48" fill={accentGrad} fillOpacity="0.35" stroke="#F4F4F4" strokeOpacity="0.55" strokeWidth="1.2" />
          <polygon points="60,34 72,52 60,70 48,52" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'tourbillon':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="38" fill={metalGrad} stroke={rarityColor} strokeWidth="2.4" />
          <circle cx="60" cy="58" r="30" fill="#151412" stroke="#636366" strokeWidth="1.4" />
          <g className={animSpinFast}>
            <circle cx="60" cy="58" r="22" fill="none" stroke={accent} strokeWidth="2" />
            <rect x="56" y="34" width="8" height="48" rx="2" fill="none" stroke={rarityColor} strokeWidth="1.6" />
            <rect x="36" y="54" width="48" height="8" rx="2" fill="none" stroke={rarityColor} strokeWidth="1.6" />
          </g>
          <circle cx="60" cy="58" r="6" fill={coreGlow} stroke="#F4F4F4" strokeWidth="1.4" />
        </g>
      );
    case 'pendulum':
      return (
        <g>
          <line x1="36" y1="20" x2="84" y2="20" stroke="#8E8E93" strokeWidth="3" strokeLinecap="round" />
          <g className={animSwing}>
            <line x1="60" y1="20" x2="60" y2="74" stroke="#E5E5EA" strokeWidth="2.4" />
            <circle cx="60" cy="78" r="14" fill={accentGrad} stroke={rarityColor} strokeWidth="2.4" />
            <circle cx="60" cy="78" r="5" fill="#F4F4F4" />
          </g>
        </g>
      );
    case 'fountain-pen':
      return (
        <g className={animFloat}>
          <polygon points="60,18 72,44 66,92 54,92 48,44" fill={metalGrad} stroke={rarityColor} strokeWidth="2" />
          <polygon points="60,18 68,40 52,40" fill={rarityColor} />
          <line x1="60" y1="18" x2="60" y2="34" stroke="#161616" strokeWidth="1.6" />
          <circle cx="60" cy="30" r="2" fill="#161616" />
        </g>
      );
    case 'brass-telescope':
      return (
        <g className={animFloat}>
          <line x1="30" y1="74" x2="90" y2="34" stroke={rarityColor} strokeWidth="12" strokeLinecap="round" />
          <line x1="30" y1="74" x2="90" y2="34" stroke="#F4F4F4" strokeOpacity="0.4" strokeWidth="2" />
          <line x1="58" y1="56" x2="42" y2="94" stroke="#8E8E93" strokeWidth="3" strokeLinecap="round" />
          <line x1="58" y1="56" x2="76" y2="94" stroke="#8E8E93" strokeWidth="3" strokeLinecap="round" />
          <circle cx="92" cy="32" r="6" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'aperture':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="37" fill={metalGrad} stroke="#636366" strokeWidth="2.2" />
          <circle cx="60" cy="58" r="30" fill="#14161A" stroke={accent} strokeWidth="1.5" />
          <g className={animSpin}>
            <polygon points="60,29 85,48 75,80 45,80 35,48" fill="none" stroke={accent} strokeWidth="2" />
            <polygon points="60,37 77,50 70,73 50,73 43,50" fill={accentGrad} fillOpacity="0.28" stroke={rarityColor} strokeWidth="1.6" />
          </g>
          <circle cx="60" cy="58" r="8" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'rotary-dial':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="36" fill={metalGrad} stroke="#6E6E6E" strokeWidth="2" />
          <circle cx="60" cy="58" r="30" fill="#16181D" stroke={accent} strokeOpacity="0.5" strokeWidth="1" />
          <g className={animSpin}>
            <circle cx="60" cy="58" r="20" fill={accentGrad} stroke="#E5E5EA" strokeOpacity="0.6" strokeWidth="1.5" />
            <line x1="60" y1="58" x2="60" y2="36" stroke={rarityColor} strokeWidth="3" strokeLinecap="round" />
          </g>
        </g>
      );

    // COLLECTIBLES
    case 'phase-cube':
      return (
        <g className={animFloat}>
          <polygon points="60,18 94,38 94,76 60,96 26,76 26,38" fill={accentGrad} fillOpacity="0.32" stroke={accent} strokeWidth="2" />
          <polyline points="26,38 60,57 94,38" fill="none" stroke="#F4F4F4" strokeOpacity="0.7" strokeWidth="1.5" />
          <line x1="60" y1="57" x2="60" y2="96" stroke={rarityColor} strokeWidth="2" />
          <polygon points="60,41 75,50 60,59 45,50" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'astronaut-helmet':
      return (
        <g className={animFloat}>
          <rect x="32" y="24" width="56" height="64" rx="22" fill="#E5E7EB" stroke="#8E8E93" strokeWidth="2" />
          <rect x="40" y="34" width="40" height="30" rx="12" fill={rarityColor} stroke="#161616" strokeWidth="2" />
          <path d="M46 42 L58 42" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
          <rect x="38" y="82" width="44" height="10" rx="3" fill={metalGrad} stroke={accent} strokeWidth="1.5" />
        </g>
      );
    case 'crane':
      return (
        <g className={animFloat}>
          <g className={animWing}>
            <polygon points="24,62 60,22 72,56 46,78" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.65" strokeWidth="1.4" />
            <polygon points="60,22 96,38 72,56" fill={metalGrad} stroke={rarityColor} strokeWidth="1.6" />
          </g>
          <polygon points="46,78 72,56 88,88" fill="#1F242D" stroke={accent} strokeWidth="1.6" />
        </g>
      );
    case 'gold-cassette':
      return (
        <g className={animFloat}>
          <rect x="20" y="32" width="80" height="52" rx="5" fill={metalGrad} stroke={rarityColor} strokeWidth="2" />
          <rect x="32" y="44" width="56" height="22" rx="3" fill="#161616" stroke="#525252" strokeWidth="1.2" />
          <circle cx="44" cy="55" r="7" fill="none" stroke={rarityColor} strokeWidth="2.2" className={animSpin} />
          <circle cx="76" cy="55" r="7" fill="none" stroke={rarityColor} strokeWidth="2.2" className={animSpin} />
          <polygon points="34,84 42,74 78,74 86,84" fill="#262626" stroke="#525252" strokeWidth="1.2" />
        </g>
      );
    case 'vintage-stamp':
      return (
        <g className={animFloat}>
          <rect x="26" y="22" width="68" height="74" fill={metalGrad} stroke="#F4F4F4" strokeWidth="2" strokeDasharray="4 4" />
          <rect x="34" y="30" width="52" height="58" fill="#161616" stroke={accent} strokeWidth="1.5" />
          <circle cx="60" cy="56" r="14" fill="none" stroke={rarityColor} strokeWidth="1.8" />
          <polygon points="60,44 68,62 52,62" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'gyro':
      return (
        <g className={animFloat}>
          <polygon points="60,18 94,38 94,78 60,98 26,78 26,38" fill={metalGrad} stroke="#636366" strokeWidth="1.8" />
          <g className={animSpin}>
            <circle cx="60" cy="58" r="24" fill="none" stroke={accent} strokeWidth="2.5" />
          </g>
          <g className={animSpinRev}>
            <ellipse cx="60" cy="58" rx="22" ry="9" fill="none" stroke={rarityColor} strokeWidth="2" />
          </g>
          <circle cx="60" cy="58" r="7.5" fill={coreGlow} className={animPulse} />
        </g>
      );

    // SEASONAL GIFTS
    case 'vessel':
      return (
        <g className={animFloat}>
          <path d="M44 30 L76 30 L84 58 C84 78, 72 90, 60 90 C48 90, 36 78, 36 58 Z" fill={metalGrad} stroke={rarityColor} strokeWidth="1.8" />
          <ellipse cx="60" cy="30" rx="16" ry="4.5" fill="#161616" stroke={accent} strokeWidth="1.5" />
          <path d="M38 56 Q60 64 82 56" fill="none" stroke={accent} strokeWidth="2.5" />
        </g>
      );
    case 'ice-lens':
      return (
        <g className={animFloat}>
          <polygon points="60,16 88,46 76,88 44,88 32,46" fill={accentGrad} fillOpacity="0.38" stroke="#E0F2FE" strokeWidth="1.8" />
          <polygon points="60,30 72,50 60,72 48,50" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'snow-globe':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="52" r="30" fill="#132234" stroke="#E0F2FE" strokeWidth="2" />
          <polygon points="46,66 60,46 74,66" fill={metalGrad} stroke={rarityColor} strokeWidth="1.5" />
          <rect x="34" y="78" width="52" height="14" rx="3" fill={metalGrad} stroke="#8E8E93" strokeWidth="1.6" />
          <circle cx="48" cy="40" r="2.2" fill="#F4F4F4" className={animPulse} />
          <circle cx="72" cy="44" r="2" fill="#BAE6FD" className={animPulse} />
        </g>
      );
    case 'sundial':
      return (
        <g className={animFloat}>
          <ellipse cx="60" cy="70" rx="38" ry="18" fill={metalGrad} stroke={rarityColor} strokeWidth="2" />
          <polygon points="60,26 60,70 84,64" fill={accentGrad} stroke="#F4F4F4" strokeOpacity="0.65" strokeWidth="1.4" />
          <circle cx="60" cy="24" r="5" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'solstice-wreath':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="56" r="28" fill="none" stroke={accent} strokeWidth="12" strokeDasharray="10 4" />
          <circle cx="60" cy="56" r="28" fill="none" stroke="#F4F4F4" strokeOpacity="0.4" strokeWidth="1.5" />
          <polygon points="60,74 48,92 60,86 72,92" fill="#FA4D56" />
          <circle cx="60" cy="82" r="5" fill="#F1C21B" />
        </g>
      );
    case 'sparkler-baton':
      return (
        <g className={animFloat}>
          <line x1="60" y1="48" x2="60" y2="96" stroke="#8E8E93" strokeWidth="4" strokeLinecap="round" />
          <g className={animSpin}>
            {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
              <line
                key={deg}
                x1="60"
                y1="44"
                x2="60"
                y2="20"
                stroke={rarityColor}
                strokeWidth="2.2"
                strokeLinecap="round"
                transform={`rotate(${deg} 60 44)`}
              />
            ))}
          </g>
          <circle cx="60" cy="44" r="7" fill={coreGlow} className={animPulse} />
        </g>
      );

    // MEME-INSPIRED GIFTS
    case 'stonks-arrow':
      return (
        <g className={animFloat}>
          <rect x="20" y="24" width="80" height="68" rx="4" fill="#131917" stroke="#393939" strokeWidth="1.5" />
          <polyline points="26,80 46,66 60,70 88,30" fill="none" stroke={accent} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
          <polygon points="92,24 76,30 88,42" fill={rarityColor} className={animPulse} />
        </g>
      );
    case 'pixel-shades':
      return (
        <g className={animFloat}>
          <rect x="20" y="42" width="36" height="22" fill="#0A0A0A" stroke="#F4F4F4" strokeWidth="2.5" />
          <rect x="64" y="42" width="36" height="22" fill="#0A0A0A" stroke="#F4F4F4" strokeWidth="2.5" />
          <rect x="54" y="44" width="12" height="6" fill="#F4F4F4" />
          <rect x="26" y="48" width="8" height="4" fill={accent} />
          <rect x="70" y="48" width="8" height="4" fill={accent} />
        </g>
      );
    case 'calm-mug':
      return (
        <g className={animFloat}>
          <rect x="34" y="48" width="44" height="42" rx="4" fill={metalGrad} stroke="#E5E5EA" strokeWidth="2" />
          <path d="M78 56 C90 56, 90 80, 78 80" fill="none" stroke="#E5E5EA" strokeWidth="3.5" />
          <path d="M24 90 Q32 68 38 90 M84 90 Q92 66 98 90" fill="none" stroke={accent} strokeWidth="2.6" className={animPulse} />
          <path d="M50 38 Q54 28 50 22 M64 38 Q68 28 64 22" fill="none" stroke="#F4F4F4" strokeWidth="2" strokeLinecap="round" />
        </g>
      );
    case 'galaxy-core':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="34" fill="none" stroke={accent} strokeOpacity="0.4" strokeWidth="1.5" className={animSpin} />
          <circle cx="60" cy="58" r="22" fill="none" stroke={rarityColor} strokeWidth="2" className={animSpinRev} />
          <circle cx="60" cy="58" r="10" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'bonk-mallet':
      return (
        <g className={animSwing}>
          <line x1="60" y1="48" x2="86" y2="92" stroke="#D97706" strokeWidth="6" strokeLinecap="round" />
          <rect x="28" y="28" width="48" height="24" rx="5" transform="rotate(-30 52 40)" fill={accentGrad} stroke="#F4F4F4" strokeWidth="1.8" />
        </g>
      );

    // SPECIAL LIMITED EDITIONS
    case 'pulsar':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="38" fill="none" stroke={accent} strokeOpacity="0.35" strokeWidth="1.4" strokeDasharray="4 4" className={animSpin} />
          <circle cx="60" cy="58" r="27" fill="none" stroke={rarityColor} strokeOpacity="0.7" strokeWidth="1.8" strokeDasharray="10 6" className={animSpinRev} />
          <circle cx="60" cy="58" r="13" fill={coreGlow} stroke="#F4F4F4" strokeWidth="1.8" className={animPulse} />
        </g>
      );
    case 'resonator':
      return (
        <g className={animFloat}>
          <rect x="24" y="24" width="72" height="68" rx="12" fill={metalGrad} stroke={accent} strokeWidth="2" />
          <circle cx="60" cy="58" r="23" fill="none" stroke={rarityColor} strokeWidth="1.8" strokeDasharray="5 3" className={animSpin} />
          <circle cx="60" cy="58" r="12" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'founders-seal':
      return (
        <g className={animFloat}>
          <polygon points="60,16 94,36 94,80 60,100 26,80 26,36" fill={metalGrad} stroke={rarityColor} strokeWidth="2.8" />
          <polygon points="60,28 82,42 82,74 60,88 38,74 38,42" fill="none" stroke="#F4F4F4" strokeOpacity="0.6" strokeWidth="1.4" />
          <path d="M60 40 L65 54 L79 58 L65 62 L60 76 L55 62 L41 58 L55 54 Z" fill={coreGlow} className={animPulse} />
        </g>
      );
    case 'eclipse-relic':
      return (
        <g className={animFloat}>
          <circle cx="60" cy="58" r="26" fill={rarityColor} fillOpacity="0.3" className={animPulse} />
          <circle cx="60" cy="58" r="20" fill="#0B0B0D" stroke={rarityColor} strokeWidth="2.6" />
          <ellipse cx="60" cy="58" rx="38" ry="12" fill="none" stroke={accent} strokeWidth="2" transform="rotate(-20 60 58)" className={animSpin} />
        </g>
      );

    default:
      return (
        <g className={animFloat}>
          <polygon points="60,20 92,58 60,96 28,58" fill={accentGrad} stroke={rarityColor} strokeWidth="2" />
          <circle cx="60" cy="58" r="10" fill={coreGlow} className={animPulse} />
        </g>
      );
  }
}

export const GiftArtwork: React.FC<GiftArtworkProps> = ({
  gift,
  size = 'md',
  animated = true,
  interactive3D = false,
  showRibbon,
  className = '',
}) => {
  const uid = React.useId().replace(/:/g, '');
  const [imgFailed, setImgFailed] = React.useState(false);
  const [tilt, setTilt] = React.useState({ rx: 0, ry: 0, gx: 50, gy: 50, active: false });

  const rarityColor = RARITY_COLOR[gift.rarity];
  const shouldShowRibbon =
    showRibbon ?? (size === 'lg' || size === 'xl' || size === 'stage');
  const showSparkles = animated && size !== 'sm' && gift.level >= 2;

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!interactive3D) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    setTilt({
      rx: (0.5 - py) * 18,
      ry: (px - 0.5) * 20,
      gx: px * 100,
      gy: py * 100,
      active: true,
    });
  };

  const handlePointerLeave = () => {
    if (!interactive3D) return;
    setTilt({ rx: 0, ry: 0, gx: 50, gy: 50, active: false });
  };

  const editionShort = gift.serialNumber.replace('#', '');
  const lv = gift.level;

  return (
    <div
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      style={{
        perspective: interactive3D ? '700px' : undefined,
      }}
      className={`${SIZE_CLASSES[size]} relative shrink-0 rounded-sm overflow-hidden flex items-center justify-center group select-none ${className}`}
    >
      <div
        className="w-full h-full relative flex items-center justify-center border rounded-sm overflow-hidden transition-transform duration-200 ease-out"
        style={{
          borderColor: lv >= 4 ? rarityColor : '#393939',
          boxShadow: lv >= 4 ? `inset 0 0 24px ${rarityColor}26` : undefined,
          background: `radial-gradient(circle at 50% 48%, ${gift.accentHex}${lv >= 3 ? '44' : '30'} 0%, ${rarityColor}14 42%, #13151A 88%)`,
          transform: interactive3D
            ? `rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg) scale(${tilt.active ? 1.02 : 1})`
            : undefined,
        }}
      >
        <svg
          viewBox="0 0 120 120"
          preserveAspectRatio="xMidYMid slice"
          className="absolute inset-0 w-full h-full pointer-events-none"
          aria-hidden="true"
        >
          <defs>
            <pattern id={`tg-pat-${uid}`} width="24" height="24" patternUnits="userSpaceOnUse">
              {renderPatternGlyph(gift.category, gift.accentHex)}
            </pattern>
          </defs>
          <rect width="120" height="120" fill={`url(#tg-pat-${uid})`} />
        </svg>

        {/* Level 2+ Architectural Corner Accents */}
        {lv >= 2 && size !== 'sm' && (
          <div className="absolute inset-2 pointer-events-none z-10 opacity-75">
            <span className="absolute top-0 left-0 w-2.5 h-2.5 border-t border-l" style={{ borderColor: rarityColor }} />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 border-b border-r" style={{ borderColor: rarityColor }} />
          </div>
        )}

        {/* Main animated 3D object or custom photo collectible */}
        {gift.imageUrl && !imgFailed ? (
          <div
            className={`relative z-10 flex items-center justify-center ${
              size === 'sm' ? 'w-9 h-9' : size === 'md' ? 'w-14 h-14' : size === 'stage' ? 'w-32 h-32' : 'w-4/5 h-4/5'
            } ${animated ? 'gift-anim-float' : ''}`}
          >
            <div
              className="w-full h-full rounded-sm overflow-hidden border shadow-lg relative"
              style={{
                borderColor: `${rarityColor}90`,
                boxShadow: `0 10px 28px -8px ${gift.accentHex}66`,
              }}
            >
              <img
                src={gift.imageUrl}
                alt={gift.name}
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full h-full object-cover"
              />
              {animated && lv >= 2 && (
                <div
                  className="absolute inset-0 pointer-events-none gift-anim-sheen"
                  style={{
                    background:
                      'linear-gradient(105deg, transparent 25%, rgba(255,255,255,0.28) 50%, transparent 75%)',
                  }}
                />
              )}
            </div>
          </div>
        ) : (
          <svg
            viewBox="0 0 120 120"
            className={`relative z-10 ${
              size === 'stage' ? 'w-36 h-36' : 'w-[86%] h-[86%]'
            } transition-transform duration-300 group-hover:scale-105`}
            aria-hidden="true"
          >
            <defs>
              <linearGradient id={`metal-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3B3F4A" />
                <stop offset="50%" stopColor="#22252C" />
                <stop offset="100%" stopColor="#14161B" />
              </linearGradient>
              <linearGradient id={`accent-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={gift.accentHex} />
                <stop offset="100%" stopColor={rarityColor} />
              </linearGradient>
              <radialGradient id={`glow-${uid}`} cx="38%" cy="35%" r="65%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.95" />
                <stop offset="45%" stopColor={rarityColor} stopOpacity="0.9" />
                <stop offset="100%" stopColor={gift.accentHex} stopOpacity="0.95" />
              </radialGradient>
            </defs>
            {renderTgCollectible(gift.artworkVariant, gift.accentHex, rarityColor, uid, animated)}
          </svg>
        )}

        {/* Twinkling 4-point sparkles (richer at Lv.3-5) */}
        {showSparkles && (
          <div className="absolute inset-0 pointer-events-none z-20" aria-hidden="true">
            <svg
              viewBox="0 0 16 16"
              className="w-3 h-3 absolute top-3 left-3 gift-anim-twinkle"
              style={{ animationDelay: '0s' }}
            >
              <path d="M8 0 L9.6 6.4 L16 8 L9.6 9.6 L8 16 L6.4 9.6 L0 8 L6.4 6.4 Z" fill={rarityColor} />
            </svg>
            {lv >= 3 && (
              <svg
                viewBox="0 0 16 16"
                className="w-2.5 h-2.5 absolute bottom-4 right-4 gift-anim-twinkle"
                style={{ animationDelay: '1.1s' }}
              >
                <path d="M8 0 L9.6 6.4 L16 8 L9.6 9.6 L8 16 L6.4 9.6 L0 8 L6.4 6.4 Z" fill="#F4F4F4" />
              </svg>
            )}
            {lv >= 5 && (
              <svg
                viewBox="0 0 16 16"
                className="w-2.5 h-2.5 absolute bottom-5 left-5 gift-anim-twinkle"
                style={{ animationDelay: '1.8s' }}
              >
                <path d="M8 0 L9.6 6.4 L16 8 L9.6 9.6 L8 16 L6.4 9.6 L0 8 L6.4 6.4 Z" fill="#F1C21B" />
              </svg>
            )}
          </div>
        )}

        {/* Level 5 Sovereign Crown Indicator */}
        {lv === 5 && size !== 'sm' && (
          <div
            className="absolute top-2 left-1/2 -translate-x-1/2 z-30 text-[9px] font-mono-tabular px-1.5 py-0.5 bg-[#161616]/90 border rounded-xs"
            style={{ borderColor: '#F1C21B', color: '#F1C21B' }}
          >
            MAX LV.5
          </div>
        )}

        {/* Level Badge */}
        {size !== 'sm' && lv < 5 && (
          <div className="absolute bottom-2 left-2.5 z-30 text-[10px] font-mono-tabular px-1.5 py-0.5 bg-[#161616]/85 border border-[#393939] text-[#F4F4F4] rounded-xs">
            Lv.{lv}
          </div>
        )}

        {interactive3D && (
          <div
            className="absolute inset-0 pointer-events-none z-20 transition-opacity duration-200"
            style={{
              opacity: tilt.active ? 0.36 : 0,
              background: `radial-gradient(circle at ${tilt.gx}% ${tilt.gy}%, rgba(255,255,255,0.45), transparent 55%)`,
            }}
          />
        )}

        {shouldShowRibbon && (
          <div
            className="absolute top-3 -right-7 w-24 py-0.5 text-center text-[9px] font-mono-tabular font-semibold tracking-tight rotate-45 z-30 shadow-sm pointer-events-none"
            style={{
              backgroundColor: rarityColor,
              color: '#111111',
            }}
          >
            {editionShort}
          </div>
        )}

        <span
          className="absolute top-0 left-0 right-0 h-0.5 z-30"
          style={{ backgroundColor: rarityColor }}
        />
      </div>
    </div>
  );
};
