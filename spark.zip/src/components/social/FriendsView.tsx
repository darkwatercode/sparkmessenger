import React, { useEffect, useState } from 'react';
import {
  Check,
  Clock,
  MessageSquare,
  Search,
  UserMinus,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useSparkStore } from '../../store/useSparkStore';
import type { PublicUser } from '../../types/spark';
import { formatLastSeen } from '../../utils/sparkLogic';
import { Avatar } from '../ui/Avatar';

export const FriendsView: React.FC = () => {
  const {
    friends,
    incomingRequests,
    outgoingRequests,
    searchUsers,
    sendFriendRequest,
    respondToFriendRequest,
    removeFriend,
    openDirectChat,
    setProfileModalUser,
  } = useSparkStore();

  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<PublicUser[]>([]);
  const [searching, setSearching] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setSearchResults([]);
      return;
    }
    let cancelled = false;
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const res = await searchUsers(trimmed);
        if (!cancelled) {
          setSearchResults(res);
        }
      } catch {
        if (!cancelled) setSearchResults([]);
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, searchUsers, friends, incomingRequests, outgoingRequests]);

  const handleAddFriend = async (target: PublicUser) => {
    setActionError(null);
    try {
      await sendFriendRequest(target.id);
      const refreshed = await searchUsers(query);
      setSearchResults(refreshed);
    } catch (err: unknown) {
      setActionError(err instanceof Error ? err.message : 'Unable to send friend request.');
    }
  };

  const handleRespond = async (requestId: number, action: 'accept' | 'decline') => {
    setActionError(null);
    try {
      await respondToFriendRequest(requestId, action);
    } catch (err: unknown) {
      setActionError(err instanceof Error ? err.message : 'Unable to respond to request.');
    }
  };

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#161616] pb-20 md:pb-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#333333]">
          <div>
            <h1 className="font-display text-xl font-semibold text-[#F4F4F4]">Friends</h1>
            <p className="text-xs text-[#A8A8A8] mt-0.5">
              Search real Spark accounts by username and connect.
            </p>
          </div>
          <span className="text-xs font-mono-tabular text-[#A8A8A8]">
            {friends.length} {friends.length === 1 ? 'friend' : 'friends'}
          </span>
        </header>

        {/* Search Users by Username */}
        <section aria-label="Find users">
          <label htmlFor="friend-search-input" className="block text-xs font-medium text-[#A8A8A8] mb-2">
            Find people on Spark
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#8D8D8D] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="friend-search-input"
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by username..."
              className="w-full h-11 pl-10 pr-4 bg-[#212121] border border-[#393939] text-sm text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE]"
            />
          </div>

          {actionError && (
            <div className="mt-3 px-3 py-2 bg-[#DA1E28]/15 border border-[#FA4D56]/60 text-xs text-[#FFB3B8]">
              {actionError}
            </div>
          )}

          {query.trim() && (
            <div className="mt-3 bg-[#212121] border border-[#333333] divide-y divide-[#2E2E2E]">
              {searching ? (
                <div className="p-4 text-xs text-[#A8A8A8]">Searching users...</div>
              ) : searchResults.length === 0 ? (
                <div className="p-4 text-xs text-[#A8A8A8]">
                  No Spark users found matching &ldquo;{query.trim()}&rdquo;.
                </div>
              ) : (
                searchResults.map((result) => (
                  <div
                    key={result.id}
                    className="p-3.5 flex items-center justify-between gap-3"
                  >
                    <button
                      type="button"
                      onClick={() => setProfileModalUser(result)}
                      className="flex items-center gap-3 min-w-0 text-left hover:opacity-90 cursor-pointer"
                    >
                      <Avatar
                        name={result.displayName}
                        initials={result.initials}
                        color={result.avatarColor}
                        avatarUrl={result.avatarUrl ?? undefined}
                        size="md"
                        presence={result.isOnline ? 'online' : 'offline'}
                        showPresence
                        equippedAccessories={result.equippedAccessories}
                      />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[#F4F4F4] truncate">
                          {result.displayName}
                        </div>
                        <div className="text-xs text-[#A8A8A8] truncate">
                          @{result.username} •{' '}
                          <span className={result.isOnline ? 'text-[#42BE65]' : 'text-[#8D8D8D]'}>
                            {formatLastSeen(result.lastSeenAt, result.isOnline)}
                          </span>
                        </div>
                      </div>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      {result.friendshipStatus === 'friends' ? (
                        <button
                          type="button"
                          onClick={() => void openDirectChat(result.id)}
                          className="h-9 px-3 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Message</span>
                        </button>
                      ) : result.friendshipStatus === 'outgoing' ? (
                        <span className="h-9 px-3 bg-[#262626] border border-[#393939] text-xs text-[#A8A8A8] flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Requested</span>
                        </span>
                      ) : result.friendshipStatus === 'incoming' && result.friendRequestId ? (
                        <button
                          type="button"
                          onClick={() => void handleRespond(result.friendRequestId!, 'accept')}
                          className="h-9 px-3 bg-[#198038] hover:bg-[#24A148] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => void handleAddFriend(result)}
                          className="h-9 px-3 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Add friend</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </section>

        {/* Incoming & Outgoing Friend Requests */}
        {(incomingRequests.length > 0 || outgoingRequests.length > 0) && (
          <section aria-label="Friend requests" className="space-y-3">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A8A8]">
              Friend requests
            </h2>
            <div className="bg-[#212121] border border-[#333333] divide-y divide-[#2E2E2E]">
              {incomingRequests.map((req) => (
                <div key={req.id} className="p-3.5 flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setProfileModalUser(req.user)}
                    className="flex items-center gap-3 min-w-0 text-left cursor-pointer"
                  >
                    <Avatar
                      name={req.user.displayName}
                      initials={req.user.initials}
                      color={req.user.avatarColor}
                      avatarUrl={req.user.avatarUrl ?? undefined}
                      size="md"
                      presence={req.user.isOnline ? 'online' : 'offline'}
                      showPresence
                      equippedAccessories={req.user.equippedAccessories}
                    />
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#F4F4F4] truncate">
                        {req.user.displayName}
                      </div>
                      <div className="text-xs text-[#A8A8A8]">
                        @{req.user.username} • Incoming request
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void handleRespond(req.id, 'accept')}
                      className="h-9 px-3 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Accept</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleRespond(req.id, 'decline')}
                      aria-label={`Decline request from ${req.user.username}`}
                      className="h-9 px-2.5 bg-[#262626] hover:bg-[#333333] border border-[#393939] text-xs text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

              {outgoingRequests.map((req) => (
                <div key={req.id} className="p-3.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar
                      name={req.user.displayName}
                      initials={req.user.initials}
                      color={req.user.avatarColor}
                      avatarUrl={req.user.avatarUrl ?? undefined}
                      size="md"
                      presence={req.user.isOnline ? 'online' : 'offline'}
                      showPresence
                      equippedAccessories={req.user.equippedAccessories}
                    />
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#F4F4F4] truncate">
                        {req.user.displayName}
                      </div>
                      <div className="text-xs text-[#A8A8A8]">
                        @{req.user.username} • Sent request
                      </div>
                    </div>
                  </div>
                  <span className="text-xs text-[#8D8D8D]">Pending</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Friends List */}
        <section aria-label="Friends list" className="space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A8A8]">
            Your friends
          </h2>

          {friends.length === 0 ? (
            <div className="bg-[#212121] border border-[#333333] p-8 text-center">
              <div className="w-11 h-11 mx-auto bg-[#262626] border border-[#393939] flex items-center justify-center text-[#A8A8A8] mb-3">
                <Users className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-[#F4F4F4] mb-1">No friends yet</p>
              <p className="text-xs text-[#A8A8A8] max-w-sm mx-auto">
                Use the username search above to find real Spark accounts and send a friend request.
              </p>
            </div>
          ) : (
            <div className="bg-[#212121] border border-[#333333] divide-y divide-[#2E2E2E]">
              {friends.map((friend) => (
                <div key={friend.id} className="p-3.5 flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setProfileModalUser(friend)}
                    className="flex items-center gap-3 min-w-0 text-left hover:opacity-90 cursor-pointer"
                  >
                    <Avatar
                      name={friend.displayName}
                      initials={friend.initials}
                      color={friend.avatarColor}
                      avatarUrl={friend.avatarUrl ?? undefined}
                      size="md"
                      presence={friend.isOnline ? 'online' : 'offline'}
                      showPresence
                      equippedAccessories={friend.equippedAccessories}
                    />
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#F4F4F4] truncate">
                        {friend.displayName}
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-[#A8A8A8]">@{friend.username}</span>
                        <span className="text-[#525252]">•</span>
                        <span className={friend.isOnline ? 'text-[#42BE65]' : 'text-[#8D8D8D]'}>
                          {formatLastSeen(friend.lastSeenAt, friend.isOnline)}
                        </span>
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void openDirectChat(friend.id)}
                      className="h-9 px-3 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Message</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => void removeFriend(friend.id)}
                      aria-label={`Remove ${friend.username}`}
                      title="Remove friend"
                      className="h-9 w-9 flex items-center justify-center bg-[#262626] hover:bg-[#333333] border border-[#393939] text-[#A8A8A8] hover:text-[#FA4D56] cursor-pointer"
                    >
                      <UserMinus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
