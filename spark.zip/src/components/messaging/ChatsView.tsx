import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  CheckCheck,
  ImagePlus,
  MessageSquare,
  Search,
  Send,
  UserPlus,
  X,
} from 'lucide-react';
import { GIFTS_CATALOG, toGiftArtworkModel } from '../../data/giftsCatalog';
import { useSparkStore } from '../../store/useSparkStore';
import { formatLastSeen, formatMessageTimestamp } from '../../utils/sparkLogic';
import { GiftArtwork } from '../gifts/GiftArtwork';
import { Avatar } from '../ui/Avatar';

export const ChatsView: React.FC = () => {
  const {
    user,
    conversations,
    activeConversationId,
    messagesByConversation,
    selectConversation,
    sendMessage,
    setActiveSection,
    setProfileModalUser,
  } = useSparkStore();

  const [filterText, setFilterText] = useState('');
  const [composerText, setComposerText] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const threadEndRef = useRef<HTMLDivElement>(null);

  const activeConversation = useMemo(
    () => conversations.find((c) => c.id === activeConversationId) ?? null,
    [conversations, activeConversationId]
  );

  const activeMessages = activeConversation
    ? messagesByConversation[activeConversation.id] ?? []
    : [];

  const filteredConversations = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) =>
        c.peer.username.toLowerCase().includes(q) ||
        c.peer.displayName.toLowerCase().includes(q)
    );
  }, [conversations, filterText]);

  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages.length, activeConversationId]);

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_800_000) {
      setSendError('Please choose an image smaller than 1.8 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAttachedImage(reader.result);
        setSendError(null);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!activeConversation || sending) return;
    const trimmed = composerText.trim();
    if (!trimmed && !attachedImage) return;

    setSending(true);
    setSendError(null);
    try {
      await sendMessage(activeConversation.id, trimmed, attachedImage);
      setComposerText('');
      setAttachedImage(null);
    } catch (err: unknown) {
      setSendError(err instanceof Error ? err.message : 'Failed to send message.');
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };

  if (!user) return null;

  return (
    <div className="flex-1 flex h-full min-h-0 bg-[#161616]">
      {/* Left Conversation List */}
      <section
        aria-label="Conversations"
        className={`${
          activeConversation ? 'hidden md:flex' : 'flex'
        } flex-col w-full md:w-80 lg:w-96 shrink-0 border-r border-[#333333] bg-[#1B1B1B]`}
      >
        <div className="h-14 px-4 flex items-center justify-between border-b border-[#333333]">
          <h1 className="font-display text-base font-semibold text-[#F4F4F4]">Chats</h1>
          <button
            type="button"
            onClick={() => setActiveSection('friends')}
            className="h-9 px-2.5 flex items-center gap-1.5 text-xs text-[#78A9FF] hover:bg-[#262626] transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add friend</span>
          </button>
        </div>

        {conversations.length > 0 && (
          <div className="p-3 border-b border-[#2B2B2B]">
            <div className="relative">
              <Search className="w-4 h-4 text-[#8D8D8D] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder="Filter chats..."
                className="w-full h-9 pl-9 pr-3 bg-[#161616] border border-[#393939] text-xs text-[#F4F4F4] placeholder-[#6F6F6F] focus:outline-none focus:border-[#0F62FE]"
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto pb-16 md:pb-0">
          {conversations.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center">
              <div className="w-12 h-12 bg-[#262626] border border-[#393939] flex items-center justify-center text-[#A8A8A8] mb-4">
                <MessageSquare className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-[#F4F4F4] mb-1">No conversations yet</p>
              <p className="text-xs text-[#A8A8A8] max-w-[220px] mb-5">
                Search for someone by username in Friends to connect and start chatting.
              </p>
              <button
                type="button"
                onClick={() => setActiveSection('friends')}
                className="h-10 px-4 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium transition-colors cursor-pointer"
              >
                Find friends
              </button>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#A8A8A8]">
              No matching conversations.
            </div>
          ) : (
            <div className="divide-y divide-[#292929]">
              {filteredConversations.map((conv) => {
                const selected = conv.id === activeConversationId;
                return (
                  <button
                    key={conv.id}
                    type="button"
                    onClick={() => void selectConversation(conv.id)}
                    className={`w-full px-4 py-3.5 flex items-center gap-3 text-left transition-colors cursor-pointer ${
                      selected
                        ? 'bg-[#262626] border-l-2 border-[#0F62FE]'
                        : 'hover:bg-[#222222]'
                    }`}
                  >
                    <Avatar
                      name={conv.peer.displayName}
                      initials={conv.peer.initials}
                      color={conv.peer.avatarColor}
                      avatarUrl={conv.peer.avatarUrl ?? undefined}
                      size="md"
                      presence={conv.peer.isOnline ? 'online' : 'offline'}
                      showPresence
                      equippedAccessories={conv.peer.equippedAccessories}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="text-sm font-medium text-[#F4F4F4] truncate">
                          {conv.peer.displayName}
                        </span>
                        {conv.lastMessage && (
                          <span className="text-[11px] font-mono-tabular text-[#8D8D8D] shrink-0">
                            {formatMessageTimestamp(conv.lastMessage.createdAt)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-[#A8A8A8] truncate">
                          {conv.lastMessage
                            ? conv.lastMessage.body ||
                              (conv.lastMessage.mediaUrl ? 'Photo' : 'Sent a gift')
                            : `@${conv.peer.username}`}
                        </span>
                        {conv.unreadCount > 0 && (
                          <span className="min-w-[18px] h-[18px] px-1 bg-[#0F62FE] text-white text-[10px] font-mono-tabular flex items-center justify-center shrink-0">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Right Spacious Message Thread */}
      <section
        aria-label="Active conversation"
        className={`${
          activeConversation ? 'flex' : 'hidden md:flex'
        } flex-1 flex-col min-w-0 bg-[#161616]`}
      >
        {!activeConversation ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <p className="text-sm font-medium text-[#F4F4F4] mb-1">Select a chat</p>
            <p className="text-xs text-[#A8A8A8] max-w-xs">
              {conversations.length > 0
                ? 'Choose a conversation from the left to read and send messages in real time.'
                : 'Your inbox is empty. Add a friend to begin a real-time conversation.'}
            </p>
          </div>
        ) : (
          <>
            <header className="h-14 px-4 flex items-center justify-between gap-3 border-b border-[#333333] bg-[#212121] shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => void selectConversation(null)}
                  aria-label="Back to chats"
                  className="md:hidden w-10 h-10 -ml-2 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={() => setProfileModalUser(activeConversation.peer)}
                  className="flex items-center gap-3 min-w-0 text-left hover:opacity-90 cursor-pointer"
                >
                  <Avatar
                    name={activeConversation.peer.displayName}
                    initials={activeConversation.peer.initials}
                    color={activeConversation.peer.avatarColor}
                    avatarUrl={activeConversation.peer.avatarUrl ?? undefined}
                    size="sm"
                    presence={activeConversation.peer.isOnline ? 'online' : 'offline'}
                    showPresence
                    equippedAccessories={activeConversation.peer.equippedAccessories}
                  />
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-[#F4F4F4] truncate">
                      {activeConversation.peer.displayName}
                    </div>
                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="text-[#8D8D8D]">@{activeConversation.peer.username}</span>
                      <span className="text-[#525252]">•</span>
                      <span
                        className={
                          activeConversation.peer.isOnline ? 'text-[#42BE65]' : 'text-[#A8A8A8]'
                        }
                      >
                        {formatLastSeen(
                          activeConversation.peer.lastSeenAt,
                          activeConversation.peer.isOnline
                        )}
                      </span>
                    </div>
                  </div>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setProfileModalUser(activeConversation.peer)}
                className="h-9 px-3 border border-[#393939] hover:bg-[#262626] text-xs text-[#F4F4F4] transition-colors shrink-0 cursor-pointer"
              >
                Profile
              </button>
            </header>

            <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-5 space-y-3">
              {activeMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12">
                  <p className="text-sm text-[#A8A8A8]">
                    Say hello to @{activeConversation.peer.username}. Messages appear instantly.
                  </p>
                </div>
              ) : (
                activeMessages.map((msg) => {
                  const isMine = msg.senderId === user.id;
                  const catalogGift = msg.giftCatalogId
                    ? GIFTS_CATALOG.find((g) => g.id === msg.giftCatalogId)
                    : null;

                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[82%] sm:max-w-[68%] px-3.5 py-2.5 border ${
                          isMine
                            ? 'bg-[#0F62FE]/18 border-[#0F62FE]/50 text-[#F4F4F4]'
                            : 'bg-[#262626] border-[#393939] text-[#F4F4F4]'
                        }`}
                      >
                        {catalogGift && (
                          <div className="mb-2 p-2.5 bg-[#161616] border border-[#333333] flex items-center gap-3">
                            <GiftArtwork
                              gift={toGiftArtworkModel(catalogGift, {
                                level: ((msg.giftLevel ?? 1) as 1 | 2 | 3 | 4 | 5),
                              })}
                              size="sm"
                            />
                            <div className="min-w-0">
                              <div className="text-xs font-semibold text-[#F4F4F4]">
                                {catalogGift.name}
                              </div>
                              <div className="text-[11px] text-[#78A9FF]">
                                Collectible Gift • {catalogGift.rarity}
                              </div>
                            </div>
                          </div>
                        )}

                        {msg.mediaUrl && (
                          <img
                            src={msg.mediaUrl}
                            alt="Message attachment"
                            className="mb-2 max-h-64 w-auto object-contain border border-[#333333]"
                          />
                        )}

                        {msg.body && (
                          <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                            {msg.body}
                          </p>
                        )}

                        <div
                          className={`mt-1.5 flex items-center gap-1.5 text-[10px] font-mono-tabular ${
                            isMine ? 'justify-end text-[#A8C7FA]' : 'text-[#8D8D8D]'
                          }`}
                        >
                          <span>{formatMessageTimestamp(msg.createdAt)}</span>
                          {isMine &&
                            (msg.deliveryStatus === 'read' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-[#78A9FF]" aria-label="Read" />
                            ) : msg.deliveryStatus === 'delivered' ? (
                              <CheckCheck className="w-3.5 h-3.5 text-[#A8A8A8]" aria-label="Delivered" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-[#8D8D8D]" aria-label="Sent" />
                            ))}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={threadEndRef} />
            </div>

            <footer className="border-t border-[#333333] bg-[#212121] p-3 pb-20 md:pb-3 shrink-0">
              {sendError && (
                <div className="mb-2 text-xs text-[#FFB3B8]">{sendError}</div>
              )}

              {attachedImage && (
                <div className="mb-2 flex items-center gap-2 p-2 bg-[#161616] border border-[#393939]">
                  <img src={attachedImage} alt="Preview" className="h-12 w-12 object-cover" />
                  <span className="text-xs text-[#A8A8A8] flex-1">Image attached</span>
                  <button
                    type="button"
                    onClick={() => setAttachedImage(null)}
                    aria-label="Remove attachment"
                    className="w-8 h-8 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              <form onSubmit={handleSend} className="flex items-end gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImagePick}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Attach image"
                  title="Attach image"
                  className="w-11 h-11 shrink-0 flex items-center justify-center bg-[#161616] border border-[#393939] text-[#A8A8A8] hover:text-[#F4F4F4] transition-colors cursor-pointer"
                >
                  <ImagePlus className="w-4 h-4" />
                </button>

                <textarea
                  rows={1}
                  value={composerText}
                  onChange={(e) => setComposerText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`Message @${activeConversation.peer.username}...`}
                  className="flex-1 min-h-[44px] max-h-32 px-3.5 py-2.5 bg-[#161616] border border-[#393939] text-sm text-[#F4F4F4] placeholder-[#6F6F6F] resize-none focus:outline-none focus:border-[#0F62FE]"
                />

                <button
                  type="submit"
                  disabled={sending || (!composerText.trim() && !attachedImage)}
                  aria-label="Send message"
                  className="h-11 px-4 shrink-0 bg-[#0F62FE] hover:bg-[#0353E9] disabled:opacity-40 text-white text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span className="hidden sm:inline">Send</span>
                </button>
              </form>
            </footer>
          </>
        )}
      </section>
    </div>
  );
};
