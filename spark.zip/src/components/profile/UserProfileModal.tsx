import React, { useEffect, useState } from 'react';
import { Check, Clock, MessageSquare, UserPlus, X } from 'lucide-react';
import { toGiftArtworkModel } from '../../data/giftsCatalog';
import { useSparkStore } from '../../store/useSparkStore';
import type { OwnedGiftItem, PublicUser } from '../../types/spark';
import { formatLastSeen } from '../../utils/sparkLogic';
import { GiftArtwork } from '../gifts/GiftArtwork';
import { Avatar } from '../ui/Avatar';
import { BannerDisplay } from '../ui/BannerDisplay';

export const UserProfileModal: React.FC = () => {
  const {
    profileModalUser,
    setProfileModalUser,
    sendFriendRequest,
    respondToFriendRequest,
    openDirectChat,
    giftCatalog,
  } = useSparkStore();

  const [freshUser, setFreshUser] = useState<PublicUser | null>(null);
  const [userGifts, setUserGifts] = useState<OwnedGiftItem[]>([]);

  useEffect(() => {
    if (!profileModalUser) {
      setFreshUser(null);
      setUserGifts([]);
      return;
    }
    setFreshUser(profileModalUser);
    let cancelled = false;
    fetch(`/api/users/${encodeURIComponent(profileModalUser.username)}`, {
      credentials: 'include',
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { user?: PublicUser; gifts?: OwnedGiftItem[] } | null) => {
        if (!cancelled && data?.user) {
          setFreshUser(data.user);
          setUserGifts(data.gifts ?? []);
        }
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [profileModalUser]);

  if (!profileModalUser) return null;
  const target = freshUser ?? profileModalUser;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#212121] border border-[#393939] overflow-hidden">
        <div className="relative">
          <BannerDisplay
            banner={{
              id: `peer-${target.id}`,
              name: 'Banner',
              mode: target.bannerUrl ? 'upload' : 'template',
              templateId: (target.bannerTemplate || 'obsidian-grid') as
                | 'obsidian-grid'
                | 'alpine'
                | 'cobalt-mesh'
                | 'mono-slate'
                | 'nocturne-rain'
                | 'amber-studio',
              imageUrl: target.bannerUrl ?? undefined,
              zoom: 1,
              posX: 50,
              posY: 50,
              brightness: 100,
            }}
            accentColor={target.accentColor}
            className="h-28"
          />
          <button
            type="button"
            onClick={() => setProfileModalUser(null)}
            aria-label="Close profile"
            className="absolute top-3 right-3 w-8 h-8 bg-[#161616]/80 border border-[#393939] flex items-center justify-center text-[#F4F4F4] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-5 pb-6">
          <div className="-mt-8 flex items-end justify-between gap-3 mb-4">
            <Avatar
              name={target.displayName}
              initials={target.initials}
              color={target.avatarColor}
              avatarUrl={target.avatarUrl ?? undefined}
              size="lg"
              presence={target.isOnline ? 'online' : 'offline'}
              showPresence
              equippedAccessories={target.equippedAccessories}
            />

            <div className="flex items-center gap-2">
              {target.friendshipStatus === 'friends' ? (
                <button
                  type="button"
                  onClick={async () => {
                    await openDirectChat(target.id);
                    setProfileModalUser(null);
                  }}
                  className="h-9 px-3.5 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Message</span>
                </button>
              ) : target.friendshipStatus === 'outgoing' ? (
                <span className="h-9 px-3 bg-[#262626] border border-[#393939] text-xs text-[#A8A8A8] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Requested</span>
                </span>
              ) : target.friendshipStatus === 'incoming' && target.friendRequestId ? (
                <button
                  type="button"
                  onClick={async () => {
                    await respondToFriendRequest(target.friendRequestId!, 'accept');
                    setProfileModalUser(null);
                  }}
                  className="h-9 px-3.5 bg-[#198038] hover:bg-[#24A148] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Accept friend</span>
                </button>
              ) : target.friendshipStatus === 'none' ? (
                <button
                  type="button"
                  onClick={async () => {
                    await sendFriendRequest(target.id);
                    setProfileModalUser(null);
                  }}
                  className="h-9 px-3.5 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Add friend</span>
                </button>
              ) : null}
            </div>
          </div>

          <h2 className="font-display text-lg font-semibold text-[#F4F4F4]">
            {target.displayName}
          </h2>
          <div className="flex items-center gap-2 text-xs mb-4">
            <span className="text-[#A8A8A8]">@{target.username}</span>
            <span className="text-[#525252]">•</span>
            <span className={target.isOnline ? 'text-[#42BE65]' : 'text-[#8D8D8D]'}>
              {formatLastSeen(target.lastSeenAt, target.isOnline)}
            </span>
          </div>

          {target.bio && (
            <p className="text-sm text-[#D6D6D6] mb-4 whitespace-pre-wrap">{target.bio}</p>
          )}

          {userGifts.length > 0 && (
            <div className="pt-3 border-t border-[#2E2E2E]">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#A8A8A8] mb-2">
                Collectible Gifts ({userGifts.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {userGifts.slice(0, 6).map((owned) => {
                  const cat = giftCatalog.find((g) => g.id === owned.catalogGiftId);
                  if (!cat) return null;
                  return (
                    <div
                      key={owned.id}
                      title={cat.name}
                      className="p-1.5 bg-[#161616] border border-[#333333]"
                    >
                      <GiftArtwork
                        gift={toGiftArtworkModel(cat, {
                          serialNumber: owned.serialNumber,
                          level: owned.level,
                        })}
                        size="sm"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
