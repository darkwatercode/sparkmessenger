import React, { useRef, useState } from 'react';
import { Calendar, Edit3, Gift, LogOut, Settings, Upload, X } from 'lucide-react';
import { INITIAL_ACCESSORIES } from '../../data/accessoriesData';
import { toGiftArtworkModel } from '../../data/giftsCatalog';
import { useSparkStore } from '../../store/useSparkStore';
import type { AccessorySlot, EquippedAccessoriesMap } from '../../types/spark';
import { DEFAULT_ACCESSORY_TRANSFORM } from '../../utils/sparkLogic';
import { GiftArtwork, RARITY_COLOR } from '../gifts/GiftArtwork';
import { Avatar } from '../ui/Avatar';
import { BannerDisplay } from '../ui/BannerDisplay';

const BANNER_TEMPLATES = [
  { id: 'obsidian-grid', label: 'Obsidian Grid' },
  { id: 'cobalt-mesh', label: 'Cobalt Mesh' },
  { id: 'nocturne-rain', label: 'Nocturne' },
  { id: 'amber-studio', label: 'Amber Studio' },
  { id: 'mono-slate', label: 'Mono Slate' },
  { id: 'alpine', label: 'Alpine Ridge' },
] as const;

const ACCENT_SWATCHES = ['#0F62FE', '#4589FF', '#198038', '#8A3FFC', '#D97706', '#FA4D56'];

export const ProfileView: React.FC = () => {
  const {
    user,
    ownedGifts,
    giftCatalog,
    updateProfile,
    setSettingsOpen,
    logout,
    setActiveSection,
  } = useSparkStore();

  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [bannerTemplate, setBannerTemplate] = useState<string>('obsidian-grid');
  const [accentColor, setAccentColor] = useState<string>('#0F62FE');
  const [equipped, setEquipped] = useState<EquippedAccessoriesMap>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const avatarFileRef = useRef<HTMLInputElement>(null);

  if (!user) return null;

  const starterAccessories = INITIAL_ACCESSORIES.filter((a) => a.unlockType === 'starter');

  const openEditor = () => {
    setDisplayName(user.displayName);
    setBio(user.bio);
    setAvatarUrl(user.avatarUrl);
    setBannerTemplate(user.bannerTemplate || 'obsidian-grid');
    setAccentColor(user.accentColor || '#0F62FE');
    setEquipped(user.equippedAccessories || {});
    setError(null);
    setEditing(true);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      setError('Avatar image must be smaller than 1.5 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatarUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const toggleAccessory = (slot: AccessorySlot, accessoryId: string) => {
    setEquipped((prev) => {
      const next = { ...prev };
      if (next[slot]?.accessoryId === accessoryId) {
        delete next[slot];
      } else {
        next[slot] = {
          accessoryId,
          transform: { ...DEFAULT_ACCESSORY_TRANSFORM },
        };
      }
      return next;
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      await updateProfile({
        displayName,
        bio,
        avatarUrl,
        bannerTemplate,
        accentColor,
        equippedAccessories: equipped,
      });
      setEditing(false);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to save profile.');
    } finally {
      setSaving(false);
    }
  };

  const joinedLabel = new Date(user.createdAt).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#161616] pb-20 md:pb-8">
      <div className="max-w-3xl mx-auto">
        <BannerDisplay
          banner={{
            id: 'user-banner',
            name: 'Profile Banner',
            mode: user.bannerUrl ? 'upload' : 'template',
            templateId: (user.bannerTemplate || 'obsidian-grid') as
              | 'obsidian-grid'
              | 'alpine'
              | 'cobalt-mesh'
              | 'mono-slate'
              | 'nocturne-rain'
              | 'amber-studio',
            imageUrl: user.bannerUrl ?? undefined,
            zoom: 1,
            posX: 50,
            posY: 50,
            brightness: 100,
          }}
          accentColor={user.accentColor}
          className="h-36 sm:h-44"
        />

        <div className="px-4 sm:px-6 pb-8">
          <div className="-mt-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
            <div className="flex items-end gap-4">
              <Avatar
                name={user.displayName}
                initials={user.initials}
                color={user.avatarColor}
                avatarUrl={user.avatarUrl ?? undefined}
                size="xl"
                presence={user.settings.hideOnlineStatus ? 'offline' : 'online'}
                showPresence
                equippedAccessories={user.equippedAccessories}
              />
              <div className="pb-1">
                <h1 className="font-display text-xl font-semibold text-[#F4F4F4]">
                  {user.displayName}
                </h1>
                <p className="text-xs text-[#A8A8A8]">@{user.username}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={openEditor}
                className="h-9 px-3.5 bg-[#0F62FE] hover:bg-[#0353E9] text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit profile</span>
              </button>
              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                aria-label="Open settings"
                className="h-9 w-9 flex items-center justify-center bg-[#212121] border border-[#393939] text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => void logout()}
                aria-label="Log out"
                className="md:hidden h-9 w-9 flex items-center justify-center bg-[#212121] border border-[#393939] text-[#A8A8A8] hover:text-[#FA4D56] cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="bg-[#212121] border border-[#333333] p-5 space-y-4 mb-6">
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A8A8] mb-1.5">
                Bio
              </h2>
              <p className="text-sm text-[#F4F4F4] whitespace-pre-wrap">
                {user.bio ? user.bio : 'No bio added yet.'}
              </p>
            </div>

            <div className="pt-3 border-t border-[#2E2E2E] flex items-center gap-2 text-xs text-[#A8A8A8]">
              <Calendar className="w-3.5 h-3.5" />
              <span>Joined {joinedLabel}</span>
            </div>
          </div>

          <section aria-label="Profile gifts" className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A8A8]">
                Owned Gifts ({ownedGifts.length})
              </h2>
              <button
                type="button"
                onClick={() => setActiveSection('gifts')}
                className="text-xs text-[#78A9FF] hover:underline cursor-pointer"
              >
                Open Gift Shop
              </button>
            </div>

            {ownedGifts.length === 0 ? (
              <div className="bg-[#212121] border border-[#333333] p-6 flex items-center gap-3 text-xs text-[#A8A8A8]">
                <Gift className="w-4 h-4 shrink-0" />
                <span>No collectible gifts owned yet.</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {ownedGifts.map((owned) => {
                  const cat = giftCatalog.find((g) => g.id === owned.catalogGiftId);
                  if (!cat) return null;
                  return (
                    <div
                      key={owned.id}
                      className="bg-[#212121] border border-[#333333] p-3.5 flex items-center gap-3"
                    >
                      <GiftArtwork
                        gift={toGiftArtworkModel(cat, {
                          serialNumber: owned.serialNumber,
                          level: owned.level,
                        })}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[#F4F4F4] truncate">
                          {cat.name}
                        </div>
                        <div
                          className="text-[11px]"
                          style={{ color: RARITY_COLOR[cat.rarity] }}
                        >
                          {cat.rarity} • Lvl {owned.level} • {owned.serialNumber}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {editing && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#212121] border border-[#393939] p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-base font-semibold text-[#F4F4F4]">Edit Profile</h2>
              <button
                type="button"
                onClick={() => setEditing(false)}
                aria-label="Close"
                className="w-8 h-8 flex items-center justify-center text-[#A8A8A8] hover:text-[#F4F4F4] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {error && (
              <div className="mb-4 px-3 py-2 bg-[#DA1E28]/15 border border-[#FA4D56]/60 text-xs text-[#FFB3B8]">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar
                  name={displayName || user.username}
                  initials={user.initials}
                  color={user.avatarColor}
                  avatarUrl={avatarUrl ?? undefined}
                  size="lg"
                  equippedAccessories={equipped}
                />
                <div className="flex items-center gap-2">
                  <input
                    ref={avatarFileRef}
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => avatarFileRef.current?.click()}
                    className="h-9 px-3 bg-[#262626] hover:bg-[#333333] border border-[#393939] text-xs text-[#F4F4F4] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload avatar</span>
                  </button>
                  {avatarUrl && (
                    <button
                      type="button"
                      onClick={() => setAvatarUrl(null)}
                      className="h-9 px-2.5 text-xs text-[#A8A8A8] hover:text-[#FA4D56] cursor-pointer"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs text-[#A8A8A8] mb-1.5">Display name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={40}
                  required
                  className="w-full h-10 px-3 bg-[#161616] border border-[#393939] text-sm text-[#F4F4F4] focus:outline-none focus:border-[#0F62FE]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#A8A8A8] mb-1.5">Bio</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  maxLength={280}
                  placeholder="Write a short bio..."
                  className="w-full px-3 py-2 bg-[#161616] border border-[#393939] text-sm text-[#F4F4F4] resize-none focus:outline-none focus:border-[#0F62FE]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#A8A8A8] mb-1.5">Banner style</label>
                  <select
                    value={bannerTemplate}
                    onChange={(e) => setBannerTemplate(e.target.value)}
                    className="w-full h-10 px-3 bg-[#161616] border border-[#393939] text-xs text-[#F4F4F4]"
                  >
                    {BANNER_TEMPLATES.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#A8A8A8] mb-1.5">Accent color</label>
                  <div className="flex items-center gap-2 h-10">
                    {ACCENT_SWATCHES.map((hex) => (
                      <button
                        key={hex}
                        type="button"
                        onClick={() => setAccentColor(hex)}
                        aria-label={`Select color ${hex}`}
                        className={`w-7 h-7 border cursor-pointer ${
                          accentColor === hex ? 'border-white scale-110' : 'border-[#393939]'
                        }`}
                        style={{ backgroundColor: hex }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs text-[#A8A8A8] mb-2">
                  Avatar Accessories (Starter Pack)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {starterAccessories.map((acc) => {
                    const active = equipped[acc.slot]?.accessoryId === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => toggleAccessory(acc.slot, acc.id)}
                        className={`px-3 py-2 text-left border text-xs transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#0F62FE]/20 border-[#0F62FE] text-[#F4F4F4]'
                            : 'bg-[#161616] border-[#393939] text-[#A8A8A8] hover:text-[#F4F4F4]'
                        }`}
                      >
                        <div className="font-medium truncate">{acc.name}</div>
                        <div className="text-[10px] text-[#8D8D8D]">{acc.categoryLabel}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2E2E2E]">
                <button
                  type="button"
                  onClick={() => setEditing(false)}
                  className="h-10 px-4 bg-[#262626] border border-[#393939] text-xs text-[#F4F4F4] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="h-10 px-5 bg-[#0F62FE] hover:bg-[#0353E9] disabled:opacity-50 text-white text-xs font-medium cursor-pointer"
                >
                  {saving ? 'Saving...' : 'Save changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
