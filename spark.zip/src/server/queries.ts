import { and, desc, eq, ilike, inArray, lt, ne, or, sql } from 'drizzle-orm';
import { GIFTS_CATALOG } from '../data/giftsCatalog.ts';
import { db } from '../db/index.ts';
import {
  conversationParticipants,
  conversations,
  friendRequests,
  friendships,
  giftOwnership,
  messages,
  presence,
  userSettings,
  users,
} from '../db/schema.ts';
import type {
  AuthUser,
  ChatMessage,
  DirectConversation,
  EquippedAccessoriesMap,
  FriendRequestItem,
  FriendshipStatus,
  OwnedGiftItem,
  PublicUser,
  UserSettings,
} from '../types/spark.ts';
import {
  computeEffectivePresence,
  getDirectConversationKey,
  getInitials,
  STALE_PRESENCE_MS,
} from '../utils/sparkLogic.ts';

type UserRow = typeof users.$inferSelect;
type SettingsRow = typeof userSettings.$inferSelect;
type PresenceRow = typeof presence.$inferSelect;

const DEFAULT_SETTINGS: UserSettings = {
  hideOnlineStatus: false,
  showLastSeen: true,
  readReceipts: true,
  reduceMotion: false,
};

function sanitizeSettings(row?: SettingsRow): UserSettings {
  if (!row) return { ...DEFAULT_SETTINGS };
  return {
    hideOnlineStatus: row.hideOnlineStatus,
    showLastSeen: row.showLastSeen,
    readReceipts: row.readReceipts,
    reduceMotion: row.reduceMotion,
  };
}

function buildPublicUser(
  userRow: UserRow,
  settingsRow: SettingsRow | undefined,
  presenceRow: PresenceRow | undefined,
  relation: { status: FriendshipStatus; requestId?: number }
): PublicUser {
  const settings = sanitizeSettings(settingsRow);
  const effectivePresence = computeEffectivePresence(
    {
      isOnline: presenceRow?.isOnline ?? false,
      lastHeartbeatAt: presenceRow?.lastHeartbeatAt ?? null,
      lastSeenAt: presenceRow?.lastSeenAt ?? null,
      hideOnlineStatus: settings.hideOnlineStatus,
      showLastSeen: settings.showLastSeen,
    },
    STALE_PRESENCE_MS
  );

  return {
    id: userRow.id,
    username: userRow.username,
    displayName: userRow.displayName,
    bio: userRow.bio,
    avatarUrl: userRow.avatarUrl ?? null,
    avatarColor: userRow.avatarColor,
    initials: getInitials(userRow.displayName || userRow.username),
    bannerTemplate: userRow.bannerTemplate,
    bannerUrl: userRow.bannerUrl ?? null,
    accentColor: userRow.accentColor,
    equippedAccessories: (userRow.equippedAccessories ?? {}) as EquippedAccessoriesMap,
    isOnline: effectivePresence.isOnline,
    lastSeenAt: effectivePresence.lastSeenAt,
    friendshipStatus: relation.status,
    friendRequestId: relation.requestId,
    createdAt: userRow.createdAt.toISOString(),
  };
}

async function getRelationsMapForViewer(
  viewerId: number,
  targetIds: number[]
): Promise<Map<number, { status: FriendshipStatus; requestId?: number }>> {
  const map = new Map<number, { status: FriendshipStatus; requestId?: number }>();
  if (targetIds.length === 0) return map;

  for (const id of targetIds) {
    if (id === viewerId) {
      map.set(id, { status: 'self' });
    } else {
      map.set(id, { status: 'none' });
    }
  }

  const friendRows = await db
    .select()
    .from(friendships)
    .where(or(eq(friendships.userAId, viewerId), eq(friendships.userBId, viewerId)));

  for (const row of friendRows) {
    const otherId = row.userAId === viewerId ? row.userBId : row.userAId;
    if (map.has(otherId)) {
      map.set(otherId, { status: 'friends' });
    }
  }

  const pendingRows = await db
    .select()
    .from(friendRequests)
    .where(
      and(
        eq(friendRequests.status, 'pending'),
        or(eq(friendRequests.senderId, viewerId), eq(friendRequests.receiverId, viewerId))
      )
    );

  for (const req of pendingRows) {
    const otherId = req.senderId === viewerId ? req.receiverId : req.senderId;
    if (!map.has(otherId)) continue;
    if (map.get(otherId)?.status === 'friends') continue;
    map.set(otherId, {
      status: req.senderId === viewerId ? 'outgoing' : 'incoming',
      requestId: req.id,
    });
  }

  return map;
}

async function hydratePublicUsers(viewerId: number, userRows: UserRow[]): Promise<PublicUser[]> {
  if (userRows.length === 0) return [];
  const ids = userRows.map((u) => u.id);

  const [settingsRows, presenceRows, relationsMap] = await Promise.all([
    db.select().from(userSettings).where(inArray(userSettings.userId, ids)),
    db.select().from(presence).where(inArray(presence.userId, ids)),
    getRelationsMapForViewer(viewerId, ids),
  ]);

  const settingsMap = new Map(settingsRows.map((s) => [s.userId, s]));
  const presenceMap = new Map(presenceRows.map((p) => [p.userId, p]));

  return userRows.map((u) =>
    buildPublicUser(
      u,
      settingsMap.get(u.id),
      presenceMap.get(u.id),
      relationsMap.get(u.id) ?? { status: 'none' }
    )
  );
}

export async function getAuthUserById(userId: number): Promise<AuthUser | null> {
  try {
    const [userRow] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!userRow) return null;

    const [[settingsRow], [presenceRow]] = await Promise.all([
      db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1),
      db.select().from(presence).where(eq(presence.userId, userId)).limit(1),
    ]);

    const pub = buildPublicUser(userRow, settingsRow, presenceRow, { status: 'self' });
    return {
      ...pub,
      coins: userRow.coins,
      settings: sanitizeSettings(settingsRow),
    };
  } catch (error) {
    console.error('getAuthUserById error:', error);
    throw new Error('Failed to load authenticated user.', { cause: error });
  }
}

export async function searchUsers(viewerId: number, query: string): Promise<PublicUser[]> {
  try {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return [];
    const matched = await db
      .select()
      .from(users)
      .where(
        and(
          ne(users.id, viewerId),
          or(ilike(users.username, `%${trimmed}%`), ilike(users.displayName, `%${trimmed}%`))
        )
      )
      .limit(20);

    return hydratePublicUsers(viewerId, matched);
  } catch (error) {
    console.error('searchUsers error:', error);
    throw new Error('Failed to search users.', { cause: error });
  }
}

export async function getPublicUserProfile(
  viewerId: number,
  targetUsernameOrId: string | number
): Promise<{ user: PublicUser; gifts: OwnedGiftItem[] } | null> {
  try {
    const whereClause =
      typeof targetUsernameOrId === 'number'
        ? eq(users.id, targetUsernameOrId)
        : eq(users.username, targetUsernameOrId.trim().toLowerCase());

    const [row] = await db.select().from(users).where(whereClause).limit(1);
    if (!row) return null;

    const [hydrated] = await hydratePublicUsers(viewerId, [row]);
    const gifts = await listOwnedGiftsForUser(row.id, viewerId === row.id);
    return { user: hydrated, gifts };
  } catch (error) {
    console.error('getPublicUserProfile error:', error);
    throw new Error('Failed to load user profile.', { cause: error });
  }
}

export async function getFriendUserIds(userId: number): Promise<number[]> {
  const rows = await db
    .select()
    .from(friendships)
    .where(or(eq(friendships.userAId, userId), eq(friendships.userBId, userId)));
  return rows.map((r) => (r.userAId === userId ? r.userBId : r.userAId));
}

export async function getFriendsAndRequests(viewerId: number): Promise<{
  friends: PublicUser[];
  incomingRequests: FriendRequestItem[];
  outgoingRequests: FriendRequestItem[];
}> {
  try {
    const [friendIds, pendingRows] = await Promise.all([
      getFriendUserIds(viewerId),
      db
        .select()
        .from(friendRequests)
        .where(
          and(
            eq(friendRequests.status, 'pending'),
            or(eq(friendRequests.senderId, viewerId), eq(friendRequests.receiverId, viewerId))
          )
        )
        .orderBy(desc(friendRequests.createdAt)),
    ]);

    const requestUserIds = pendingRows.map((r) =>
      r.senderId === viewerId ? r.receiverId : r.senderId
    );
    const allNeededIds = Array.from(new Set([...friendIds, ...requestUserIds]));

    const allUserRows =
      allNeededIds.length > 0
        ? await db.select().from(users).where(inArray(users.id, allNeededIds))
        : [];
    const hydrated = await hydratePublicUsers(viewerId, allUserRows);
    const userMap = new Map(hydrated.map((u) => [u.id, u]));

    const friends = friendIds
      .map((id) => userMap.get(id))
      .filter((u): u is PublicUser => Boolean(u))
      .sort((a, b) => Number(b.isOnline) - Number(a.isOnline) || a.username.localeCompare(b.username));

    const incomingRequests: FriendRequestItem[] = [];
    const outgoingRequests: FriendRequestItem[] = [];

    for (const req of pendingRows) {
      const otherId = req.senderId === viewerId ? req.receiverId : req.senderId;
      const otherUser = userMap.get(otherId);
      if (!otherUser) continue;
      const item: FriendRequestItem = {
        id: req.id,
        senderId: req.senderId,
        receiverId: req.receiverId,
        status: 'pending',
        direction: req.receiverId === viewerId ? 'incoming' : 'outgoing',
        user: otherUser,
        createdAt: req.createdAt.toISOString(),
      };
      if (item.direction === 'incoming') {
        incomingRequests.push(item);
      } else {
        outgoingRequests.push(item);
      }
    }

    return { friends, incomingRequests, outgoingRequests };
  } catch (error) {
    console.error('getFriendsAndRequests error:', error);
    throw new Error('Failed to load friends list.', { cause: error });
  }
}

export async function createFriendRequest(
  senderId: number,
  receiverId: number
): Promise<{ status: 'requested' | 'accepted'; requestId: number }> {
  try {
    if (senderId === receiverId) {
      throw new Error('You cannot add yourself as a friend.');
    }

    const [target] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, receiverId))
      .limit(1);
    if (!target) {
      throw new Error('User not found.');
    }

    const low = Math.min(senderId, receiverId);
    const high = Math.max(senderId, receiverId);
    const [existingFriendship] = await db
      .select()
      .from(friendships)
      .where(and(eq(friendships.userAId, low), eq(friendships.userBId, high)))
      .limit(1);
    if (existingFriendship) {
      throw new Error('You are already friends.');
    }

    // Check if receiver already sent a pending request to sender — if so, accept automatically
    const [reversePending] = await db
      .select()
      .from(friendRequests)
      .where(
        and(
          eq(friendRequests.senderId, receiverId),
          eq(friendRequests.receiverId, senderId),
          eq(friendRequests.status, 'pending')
        )
      )
      .limit(1);

    if (reversePending) {
      await db
        .update(friendRequests)
        .set({ status: 'accepted', updatedAt: new Date() })
        .where(eq(friendRequests.id, reversePending.id));
      await db
        .insert(friendships)
        .values({ userAId: low, userBId: high })
        .onConflictDoNothing();
      return { status: 'accepted', requestId: reversePending.id };
    }

    const [alreadySent] = await db
      .select()
      .from(friendRequests)
      .where(
        and(
          eq(friendRequests.senderId, senderId),
          eq(friendRequests.receiverId, receiverId),
          eq(friendRequests.status, 'pending')
        )
      )
      .limit(1);
    if (alreadySent) {
      return { status: 'requested', requestId: alreadySent.id };
    }

    const [inserted] = await db
      .insert(friendRequests)
      .values({
        senderId,
        receiverId,
        status: 'pending',
      })
      .returning();

    return { status: 'requested', requestId: inserted.id };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'You cannot add yourself as a friend.' ||
        error.message === 'User not found.' ||
        error.message === 'You are already friends.')
    ) {
      throw error;
    }
    console.error('createFriendRequest error:', error);
    throw new Error('Failed to send friend request.', { cause: error });
  }
}

export async function respondFriendRequest(
  viewerId: number,
  requestId: number,
  action: 'accept' | 'decline'
): Promise<{ senderId: number; receiverId: number; status: 'accepted' | 'declined' }> {
  try {
    const [reqRow] = await db
      .select()
      .from(friendRequests)
      .where(eq(friendRequests.id, requestId))
      .limit(1);

    if (!reqRow || reqRow.receiverId !== viewerId) {
      throw new Error('Friend request not found.');
    }
    if (reqRow.status !== 'pending') {
      throw new Error('Friend request already processed.');
    }

    const nextStatus = action === 'accept' ? 'accepted' : 'declined';
    await db
      .update(friendRequests)
      .set({ status: nextStatus, updatedAt: new Date() })
      .where(eq(friendRequests.id, reqRow.id));

    if (action === 'accept') {
      const low = Math.min(reqRow.senderId, reqRow.receiverId);
      const high = Math.max(reqRow.senderId, reqRow.receiverId);
      await db
        .insert(friendships)
        .values({ userAId: low, userBId: high })
        .onConflictDoNothing();
    }

    return {
      senderId: reqRow.senderId,
      receiverId: reqRow.receiverId,
      status: nextStatus,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Friend request not found.' ||
        error.message === 'Friend request already processed.')
    ) {
      throw error;
    }
    console.error('respondFriendRequest error:', error);
    throw new Error('Failed to update friend request.', { cause: error });
  }
}

export async function removeFriendship(viewerId: number, otherUserId: number): Promise<void> {
  try {
    const low = Math.min(viewerId, otherUserId);
    const high = Math.max(viewerId, otherUserId);
    await db
      .delete(friendships)
      .where(and(eq(friendships.userAId, low), eq(friendships.userBId, high)));
  } catch (error) {
    console.error('removeFriendship error:', error);
    throw new Error('Failed to remove friend.', { cause: error });
  }
}

export async function getOrCreateDirectConversation(
  viewerId: number,
  peerId: number
): Promise<DirectConversation> {
  try {
    if (viewerId === peerId) {
      throw new Error('Cannot start a conversation with yourself.');
    }
    const [peerRow] = await db.select().from(users).where(eq(users.id, peerId)).limit(1);
    if (!peerRow) {
      throw new Error('User not found.');
    }

    const directKey = getDirectConversationKey(viewerId, peerId);
    let [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.directKey, directKey))
      .limit(1);

    if (!conv) {
      const [inserted] = await db
        .insert(conversations)
        .values({
          type: 'direct',
          directKey,
        })
        .onConflictDoNothing({ target: conversations.directKey })
        .returning();

      if (inserted) {
        conv = inserted;
      } else {
        const [refetched] = await db
          .select()
          .from(conversations)
          .where(eq(conversations.directKey, directKey))
          .limit(1);
        conv = refetched;
      }
    }

    await db
      .insert(conversationParticipants)
      .values([
        { conversationId: conv.id, userId: viewerId },
        { conversationId: conv.id, userId: peerId },
      ])
      .onConflictDoNothing();

    const list = await listConversationsForUser(viewerId, conv.id);
    if (!list[0]) {
      throw new Error('Failed to hydrate conversation.');
    }
    return list[0];
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Cannot start a conversation with yourself.' ||
        error.message === 'User not found.')
    ) {
      throw error;
    }
    console.error('getOrCreateDirectConversation error:', error);
    throw new Error('Failed to open conversation.', { cause: error });
  }
}

export async function listConversationsForUser(
  viewerId: number,
  onlyConversationId?: number
): Promise<DirectConversation[]> {
  try {
    const myMemberships = await db
      .select()
      .from(conversationParticipants)
      .where(
        onlyConversationId
          ? and(
              eq(conversationParticipants.userId, viewerId),
              eq(conversationParticipants.conversationId, onlyConversationId)
            )
          : eq(conversationParticipants.userId, viewerId)
      );

    if (myMemberships.length === 0) return [];
    const convIds = myMemberships.map((m) => m.conversationId);
    const myReadMap = new Map(myMemberships.map((m) => [m.conversationId, m.lastReadMessageId ?? 0]));

    const [convRows, allParticipants, recentMessages] = await Promise.all([
      db
        .select()
        .from(conversations)
        .where(inArray(conversations.id, convIds))
        .orderBy(desc(conversations.updatedAt)),
      db
        .select()
        .from(conversationParticipants)
        .where(inArray(conversationParticipants.conversationId, convIds)),
      db
        .select()
        .from(messages)
        .where(inArray(messages.conversationId, convIds))
        .orderBy(desc(messages.id)),
    ]);

    const peerIdByConv = new Map<number, number>();
    for (const part of allParticipants) {
      if (part.userId !== viewerId) {
        peerIdByConv.set(part.conversationId, part.userId);
      }
    }

    const peerIds = Array.from(new Set(peerIdByConv.values()));
    const peerUserRows =
      peerIds.length > 0 ? await db.select().from(users).where(inArray(users.id, peerIds)) : [];
    const hydratedPeers = await hydratePublicUsers(viewerId, peerUserRows);
    const peerMap = new Map(hydratedPeers.map((u) => [u.id, u]));

    const lastMessageByConv = new Map<number, typeof messages.$inferSelect>();
    const unreadCountByConv = new Map<number, number>();

    for (const msg of recentMessages) {
      if (!lastMessageByConv.has(msg.conversationId)) {
        lastMessageByConv.set(msg.conversationId, msg);
      }
      const lastReadId = myReadMap.get(msg.conversationId) ?? 0;
      if (msg.senderId !== viewerId && msg.id > lastReadId) {
        unreadCountByConv.set(msg.conversationId, (unreadCountByConv.get(msg.conversationId) ?? 0) + 1);
      }
    }

    const result: DirectConversation[] = [];
    for (const conv of convRows) {
      const peerId = peerIdByConv.get(conv.id);
      if (!peerId) continue;
      const peer = peerMap.get(peerId);
      if (!peer) continue;
      const rawLast = lastMessageByConv.get(conv.id);

      result.push({
        id: conv.id,
        peer,
        lastMessage: rawLast ? serializeMessage(rawLast) : null,
        unreadCount: unreadCountByConv.get(conv.id) ?? 0,
        updatedAt: conv.updatedAt.toISOString(),
      });
    }

    return result;
  } catch (error) {
    console.error('listConversationsForUser error:', error);
    throw new Error('Failed to load conversations.', { cause: error });
  }
}

export function serializeMessage(
  row: typeof messages.$inferSelect,
  giftLevel?: number | null
): ChatMessage {
  return {
    id: row.id,
    conversationId: row.conversationId,
    senderId: row.senderId,
    body: row.body,
    giftCatalogId: row.giftCatalogId ?? null,
    giftOwnershipId: row.giftOwnershipId ?? null,
    giftLevel: giftLevel ?? null,
    mediaUrl: row.mediaUrl ?? null,
    deliveryStatus: (row.deliveryStatus as ChatMessage['deliveryStatus']) || 'sent',
    createdAt: row.createdAt.toISOString(),
  };
}

export async function isConversationParticipant(
  conversationId: number,
  userId: number
): Promise<boolean> {
  const [row] = await db
    .select()
    .from(conversationParticipants)
    .where(
      and(
        eq(conversationParticipants.conversationId, conversationId),
        eq(conversationParticipants.userId, userId)
      )
    )
    .limit(1);
  return Boolean(row);
}

export async function getConversationParticipantIds(conversationId: number): Promise<number[]> {
  const rows = await db
    .select({ userId: conversationParticipants.userId })
    .from(conversationParticipants)
    .where(eq(conversationParticipants.conversationId, conversationId));
  return rows.map((r) => r.userId);
}

export async function listConversationMessages(
  viewerId: number,
  conversationId: number,
  limit = 100
): Promise<ChatMessage[]> {
  try {
    const allowed = await isConversationParticipant(conversationId, viewerId);
    if (!allowed) {
      throw new Error('Conversation access denied.');
    }

    const rows = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(desc(messages.id))
      .limit(limit);

    const ordered = [...rows].reverse();
    const ownershipIds = ordered
      .map((m) => m.giftOwnershipId)
      .filter((id): id is number => typeof id === 'number');

    const levelMap = new Map<number, number>();
    if (ownershipIds.length > 0) {
      const ownedRows = await db
        .select({ id: giftOwnership.id, level: giftOwnership.level })
        .from(giftOwnership)
        .where(inArray(giftOwnership.id, ownershipIds));
      for (const o of ownedRows) levelMap.set(o.id, o.level);
    }

    return ordered.map((r) =>
      serializeMessage(r, r.giftOwnershipId ? levelMap.get(r.giftOwnershipId) ?? 1 : null)
    );
  } catch (error) {
    if (error instanceof Error && error.message === 'Conversation access denied.') {
      throw error;
    }
    console.error('listConversationMessages error:', error);
    throw new Error('Failed to load messages.', { cause: error });
  }
}

export async function createConversationMessage(
  senderId: number,
  conversationId: number,
  payload: {
    body: string;
    mediaUrl?: string | null;
    giftCatalogId?: string | null;
    giftOwnershipId?: number | null;
    peerOnline?: boolean;
  }
): Promise<{ message: ChatMessage; participantIds: number[] }> {
  try {
    const allowed = await isConversationParticipant(conversationId, senderId);
    if (!allowed) {
      throw new Error('Conversation access denied.');
    }

    const textBody = payload.body.trim();
    if (!textBody && !payload.mediaUrl && !payload.giftCatalogId) {
      throw new Error('Message cannot be empty.');
    }

    const [inserted] = await db
      .insert(messages)
      .values({
        conversationId,
        senderId,
        body: textBody,
        mediaUrl: payload.mediaUrl ?? null,
        giftCatalogId: payload.giftCatalogId ?? null,
        giftOwnershipId: payload.giftOwnershipId ?? null,
        deliveryStatus: payload.peerOnline ? 'delivered' : 'sent',
      })
      .returning();

    await db
      .update(conversations)
      .set({ updatedAt: inserted.createdAt })
      .where(eq(conversations.id, conversationId));

    await db
      .update(conversationParticipants)
      .set({ lastReadMessageId: inserted.id })
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, senderId)
        )
      );

    const participantIds = await getConversationParticipantIds(conversationId);
    return {
      message: serializeMessage(inserted, payload.giftOwnershipId ? 1 : null),
      participantIds,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Conversation access denied.' ||
        error.message === 'Message cannot be empty.')
    ) {
      throw error;
    }
    console.error('createConversationMessage error:', error);
    throw new Error('Failed to send message.', { cause: error });
  }
}

export async function markConversationAsRead(
  viewerId: number,
  conversationId: number
): Promise<{ lastReadMessageId: number | null; participantIds: number[] }> {
  try {
    const allowed = await isConversationParticipant(conversationId, viewerId);
    if (!allowed) {
      throw new Error('Conversation access denied.');
    }

    const [latest] = await db
      .select({ id: messages.id })
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(desc(messages.id))
      .limit(1);

    if (!latest) {
      return { lastReadMessageId: null, participantIds: [] };
    }

    await db
      .update(conversationParticipants)
      .set({ lastReadMessageId: latest.id })
      .where(
        and(
          eq(conversationParticipants.conversationId, conversationId),
          eq(conversationParticipants.userId, viewerId)
        )
      );

    await db
      .update(messages)
      .set({ deliveryStatus: 'read' })
      .where(
        and(
          eq(messages.conversationId, conversationId),
          ne(messages.senderId, viewerId),
          ne(messages.deliveryStatus, 'read')
        )
      );

    const participantIds = await getConversationParticipantIds(conversationId);
    return { lastReadMessageId: latest.id, participantIds };
  } catch (error) {
    console.error('markConversationAsRead error:', error);
    throw new Error('Failed to mark conversation as read.', { cause: error });
  }
}

export async function listOwnedGiftsForUser(
  ownerId: number,
  includeHidden = true
): Promise<OwnedGiftItem[]> {
  try {
    const rows = await db
      .select()
      .from(giftOwnership)
      .where(
        includeHidden
          ? eq(giftOwnership.ownerId, ownerId)
          : and(eq(giftOwnership.ownerId, ownerId), eq(giftOwnership.hiddenFromProfile, false))
      )
      .orderBy(desc(giftOwnership.createdAt));

    const senderIds = Array.from(
      new Set(rows.map((r) => r.senderId).filter((id): id is number => typeof id === 'number'))
    );
    const senderRows =
      senderIds.length > 0
        ? await db
            .select({ id: users.id, username: users.username })
            .from(users)
            .where(inArray(users.id, senderIds))
        : [];
    const senderMap = new Map(senderRows.map((u) => [u.id, u.username]));

    return rows.map((r) => ({
      id: r.id,
      catalogGiftId: r.catalogGiftId,
      ownerId: r.ownerId,
      senderId: r.senderId ?? null,
      senderUsername: r.senderId ? senderMap.get(r.senderId) ?? null : null,
      serialNumber: r.serialNumber,
      level: Math.min(5, Math.max(1, r.level)) as 1 | 2 | 3 | 4 | 5,
      hiddenFromProfile: r.hiddenFromProfile,
      createdAt: r.createdAt.toISOString(),
    }));
  } catch (error) {
    console.error('listOwnedGiftsForUser error:', error);
    throw new Error('Failed to load owned gifts.', { cause: error });
  }
}

export async function purchaseCatalogGift(
  buyerId: number,
  catalogGiftId: string
): Promise<{ owned: OwnedGiftItem; coinsRemaining: number }> {
  try {
    const item = GIFTS_CATALOG.find((g) => g.id === catalogGiftId);
    if (!item) {
      throw new Error('Gift not found in catalog.');
    }

    const updatedUsers = await db
      .update(users)
      .set({ coins: sql`${users.coins} - ${item.priceCredits}` })
      .where(and(eq(users.id, buyerId), sql`${users.coins} >= ${item.priceCredits}`))
      .returning({ coins: users.coins });

    if (!updatedUsers[0]) {
      throw new Error('Insufficient Spark credits.');
    }

    const serialSuffix = Math.floor(1 + Math.random() * 999)
      .toString()
      .padStart(3, '0');
    const [inserted] = await db
      .insert(giftOwnership)
      .values({
        catalogGiftId,
        ownerId: buyerId,
        senderId: null,
        serialNumber: `#${serialSuffix}`,
        level: 1,
      })
      .returning();

    return {
      owned: {
        id: inserted.id,
        catalogGiftId: inserted.catalogGiftId,
        ownerId: inserted.ownerId,
        senderId: null,
        senderUsername: null,
        serialNumber: inserted.serialNumber,
        level: 1,
        hiddenFromProfile: false,
        createdAt: inserted.createdAt.toISOString(),
      },
      coinsRemaining: updatedUsers[0].coins,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Gift not found in catalog.' ||
        error.message === 'Insufficient Spark credits.')
    ) {
      throw error;
    }
    console.error('purchaseCatalogGift error:', error);
    throw new Error('Failed to purchase gift.', { cause: error });
  }
}

export async function sendCatalogGiftToUser(
  senderId: number,
  recipientId: number,
  catalogGiftId: string,
  note?: string
): Promise<{
  owned: OwnedGiftItem;
  coinsRemaining: number;
  conversationId: number;
  message: ChatMessage;
  participantIds: number[];
}> {
  try {
    if (senderId === recipientId) {
      throw new Error('Cannot send a gift to yourself. Purchase it directly.');
    }
    const item = GIFTS_CATALOG.find((g) => g.id === catalogGiftId);
    if (!item) {
      throw new Error('Gift not found in catalog.');
    }

    const [recipient] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.id, recipientId))
      .limit(1);
    if (!recipient) {
      throw new Error('Recipient not found.');
    }

    const updatedUsers = await db
      .update(users)
      .set({ coins: sql`${users.coins} - ${item.priceCredits}` })
      .where(and(eq(users.id, senderId), sql`${users.coins} >= ${item.priceCredits}`))
      .returning({ coins: users.coins, username: users.username });

    if (!updatedUsers[0]) {
      throw new Error('Insufficient Spark credits.');
    }

    const serialSuffix = Math.floor(1 + Math.random() * 999)
      .toString()
      .padStart(3, '0');
    const [insertedGift] = await db
      .insert(giftOwnership)
      .values({
        catalogGiftId,
        ownerId: recipientId,
        senderId,
        serialNumber: `#${serialSuffix}`,
        level: 1,
      })
      .returning();

    const conv = await getOrCreateDirectConversation(senderId, recipientId);
    const { message, participantIds } = await createConversationMessage(senderId, conv.id, {
      body: note?.trim() || `Sent collectible gift: ${item.name}`,
      giftCatalogId: catalogGiftId,
      giftOwnershipId: insertedGift.id,
    });

    return {
      owned: {
        id: insertedGift.id,
        catalogGiftId: insertedGift.catalogGiftId,
        ownerId: insertedGift.ownerId,
        senderId,
        senderUsername: updatedUsers[0].username,
        serialNumber: insertedGift.serialNumber,
        level: 1,
        hiddenFromProfile: false,
        createdAt: insertedGift.createdAt.toISOString(),
      },
      coinsRemaining: updatedUsers[0].coins,
      conversationId: conv.id,
      message,
      participantIds,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Gift not found in catalog.' ||
        error.message === 'Insufficient Spark credits.' ||
        error.message === 'Recipient not found.' ||
        error.message === 'Cannot send a gift to yourself. Purchase it directly.')
    ) {
      throw error;
    }
    console.error('sendCatalogGiftToUser error:', error);
    throw new Error('Failed to send gift.', { cause: error });
  }
}

export async function upgradeUserGift(
  ownerId: number,
  ownershipId: number
): Promise<{ owned: OwnedGiftItem; coinsRemaining: number }> {
  try {
    const [row] = await db
      .select()
      .from(giftOwnership)
      .where(and(eq(giftOwnership.id, ownershipId), eq(giftOwnership.ownerId, ownerId)))
      .limit(1);
    if (!row) {
      throw new Error('Gift not found in your collection.');
    }
    if (row.level >= 5) {
      throw new Error('Gift is already at maximum level.');
    }

    const upgradeCost = row.level * 150;
    const updatedUsers = await db
      .update(users)
      .set({ coins: sql`${users.coins} - ${upgradeCost}` })
      .where(and(eq(users.id, ownerId), sql`${users.coins} >= ${upgradeCost}`))
      .returning({ coins: users.coins });

    if (!updatedUsers[0]) {
      throw new Error(`Need ${upgradeCost} Spark credits to upgrade.`);
    }

    const nextLevel = row.level + 1;
    const [updatedGift] = await db
      .update(giftOwnership)
      .set({ level: nextLevel })
      .where(eq(giftOwnership.id, ownershipId))
      .returning();

    return {
      owned: {
        id: updatedGift.id,
        catalogGiftId: updatedGift.catalogGiftId,
        ownerId: updatedGift.ownerId,
        senderId: updatedGift.senderId ?? null,
        serialNumber: updatedGift.serialNumber,
        level: Math.min(5, Math.max(1, updatedGift.level)) as 1 | 2 | 3 | 4 | 5,
        hiddenFromProfile: updatedGift.hiddenFromProfile,
        createdAt: updatedGift.createdAt.toISOString(),
      },
      coinsRemaining: updatedUsers[0].coins,
    };
  } catch (error) {
    if (
      error instanceof Error &&
      (error.message === 'Gift not found in your collection.' ||
        error.message === 'Gift is already at maximum level.' ||
        error.message.startsWith('Need '))
    ) {
      throw error;
    }
    console.error('upgradeUserGift error:', error);
    throw new Error('Failed to upgrade gift.', { cause: error });
  }
}

export async function setPresenceOnline(userId: number): Promise<void> {
  const now = new Date();
  await db
    .insert(presence)
    .values({
      userId,
      isOnline: true,
      lastSeenAt: now,
      lastHeartbeatAt: now,
    })
    .onConflictDoUpdate({
      target: presence.userId,
      set: {
        isOnline: true,
        lastSeenAt: now,
        lastHeartbeatAt: now,
      },
    });
}

export async function touchPresenceHeartbeat(userId: number): Promise<void> {
  const now = new Date();
  await db
    .insert(presence)
    .values({
      userId,
      isOnline: true,
      lastSeenAt: now,
      lastHeartbeatAt: now,
    })
    .onConflictDoUpdate({
      target: presence.userId,
      set: {
        isOnline: true,
        lastHeartbeatAt: now,
      },
    });
}

export async function setPresenceOffline(userId: number): Promise<Date> {
  const now = new Date();
  await db
    .insert(presence)
    .values({
      userId,
      isOnline: false,
      lastSeenAt: now,
      lastHeartbeatAt: now,
    })
    .onConflictDoUpdate({
      target: presence.userId,
      set: {
        isOnline: false,
        lastSeenAt: now,
      },
    });
  return now;
}

export async function expireStalePresenceRows(staleMs = STALE_PRESENCE_MS): Promise<number[]> {
  const cutoff = new Date(Date.now() - staleMs);
  const expired = await db
    .update(presence)
    .set({
      isOnline: false,
      lastSeenAt: sql`${presence.lastHeartbeatAt}`,
    })
    .where(and(eq(presence.isOnline, true), lt(presence.lastHeartbeatAt, cutoff)))
    .returning({ userId: presence.userId });
  return expired.map((r) => r.userId);
}
