import { create } from 'zustand';
import type {
  AuthUser,
  CatalogGift,
  ChatMessage,
  DirectConversation,
  EquippedAccessoriesMap,
  FriendRequestItem,
  NavSection,
  OwnedGiftItem,
  PublicUser,
  UserSettings,
} from '../types/spark';
import {
  mergeMessageDeduplicated,
  upsertConversationOrder,
} from '../utils/sparkLogic';

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  });
  const data = (await res.json().catch(() => ({}))) as T & {
    error?: string;
    fieldErrors?: Record<string, string>;
  };
  if (!res.ok) {
    const err = new Error(data.error || `Request failed (${res.status})`) as Error & {
      status?: number;
      fieldErrors?: Record<string, string>;
    };
    err.status = res.status;
    err.fieldErrors = data.fieldErrors;
    throw err;
  }
  return data;
}

interface SparkState {
  user: AuthUser | null;
  authInitialized: boolean;
  authBusy: boolean;
  activeSection: NavSection;
  settingsOpen: boolean;
  profileModalUser: PublicUser | null;

  friends: PublicUser[];
  incomingRequests: FriendRequestItem[];
  outgoingRequests: FriendRequestItem[];

  conversations: DirectConversation[];
  activeConversationId: number | null;
  messagesByConversation: Record<number, ChatMessage[]>;

  giftCatalog: CatalogGift[];
  ownedGifts: OwnedGiftItem[];

  bootstrapSession: () => Promise<void>;
  register: (payload: {
    username: string;
    password: string;
    confirmPassword: string;
    rememberMe: boolean;
  }) => Promise<void>;
  login: (payload: {
    username: string;
    password: string;
    rememberMe: boolean;
  }) => Promise<void>;
  logout: () => Promise<void>;

  setActiveSection: (section: NavSection) => void;
  setSettingsOpen: (open: boolean) => void;
  setProfileModalUser: (user: PublicUser | null) => void;

  refreshFriends: () => Promise<void>;
  refreshChats: () => Promise<void>;
  refreshGifts: () => Promise<void>;

  searchUsers: (query: string) => Promise<PublicUser[]>;
  sendFriendRequest: (userId: number) => Promise<void>;
  respondToFriendRequest: (requestId: number, action: 'accept' | 'decline') => Promise<void>;
  removeFriend: (friendId: number) => Promise<void>;

  openDirectChat: (peerId: number) => Promise<void>;
  selectConversation: (conversationId: number | null) => Promise<void>;
  sendMessage: (conversationId: number, body: string, mediaUrl?: string | null) => Promise<void>;
  markConversationRead: (conversationId: number) => Promise<void>;

  updateProfile: (payload: {
    displayName?: string;
    bio?: string;
    avatarUrl?: string | null;
    bannerTemplate?: string;
    bannerUrl?: string | null;
    accentColor?: string;
    equippedAccessories?: EquippedAccessoriesMap;
  }) => Promise<void>;
  updateSettings: (payload: Partial<UserSettings>) => Promise<void>;

  purchaseGift: (catalogGiftId: string) => Promise<OwnedGiftItem>;
  sendGiftToFriend: (recipientId: number, catalogGiftId: string, note?: string) => Promise<void>;
  upgradeGift: (ownershipId: number) => Promise<void>;

  connectWebSocket: () => void;
  disconnectWebSocket: () => void;
}

let activeWs: WebSocket | null = null;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let intentionalDisconnect = false;

function stopWsTimers() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

export const useSparkStore = create<SparkState>((set, get) => ({
  user: null,
  authInitialized: false,
  authBusy: false,
  activeSection: 'chats',
  settingsOpen: false,
  profileModalUser: null,

  friends: [],
  incomingRequests: [],
  outgoingRequests: [],

  conversations: [],
  activeConversationId: null,
  messagesByConversation: {},

  giftCatalog: [],
  ownedGifts: [],

  bootstrapSession: async () => {
    try {
      const data = await apiJson<{ user: AuthUser | null }>('/api/auth/session');
      if (!data.user) {
        set({ user: null, authInitialized: true });
        return;
      }
      set({ user: data.user, authInitialized: true });
      await Promise.all([get().refreshFriends(), get().refreshChats(), get().refreshGifts()]);
      get().connectWebSocket();
    } catch {
      set({ user: null, authInitialized: true });
    }
  },

  register: async (payload) => {
    set({ authBusy: true });
    try {
      const data = await apiJson<{ user: AuthUser }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      set({
        user: data.user,
        authBusy: false,
        authInitialized: true,
        activeSection: 'chats',
        friends: [],
        incomingRequests: [],
        outgoingRequests: [],
        conversations: [],
        activeConversationId: null,
        messagesByConversation: {},
        ownedGifts: [],
      });
      await get().refreshGifts();
      get().connectWebSocket();
    } catch (err) {
      set({ authBusy: false });
      throw err;
    }
  },

  login: async (payload) => {
    set({ authBusy: true });
    try {
      const data = await apiJson<{ user: AuthUser }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      set({
        user: data.user,
        authBusy: false,
        authInitialized: true,
        activeSection: 'chats',
        activeConversationId: null,
        messagesByConversation: {},
      });
      await Promise.all([get().refreshFriends(), get().refreshChats(), get().refreshGifts()]);
      get().connectWebSocket();
    } catch (err) {
      set({ authBusy: false });
      throw err;
    }
  },

  logout: async () => {
    get().disconnectWebSocket();
    try {
      await apiJson('/api/auth/logout', { method: 'POST' });
    } catch {
      // clear client state regardless
    }
    set({
      user: null,
      authInitialized: true,
      activeSection: 'chats',
      settingsOpen: false,
      profileModalUser: null,
      friends: [],
      incomingRequests: [],
      outgoingRequests: [],
      conversations: [],
      activeConversationId: null,
      messagesByConversation: {},
      ownedGifts: [],
    });
  },

  setActiveSection: (section) => set({ activeSection: section }),
  setSettingsOpen: (open) => set({ settingsOpen: open }),
  setProfileModalUser: (user) => set({ profileModalUser: user }),

  refreshFriends: async () => {
    if (!get().user) return;
    const data = await apiJson<{
      friends: PublicUser[];
      incomingRequests: FriendRequestItem[];
      outgoingRequests: FriendRequestItem[];
    }>('/api/friends');
    set({
      friends: data.friends,
      incomingRequests: data.incomingRequests,
      outgoingRequests: data.outgoingRequests,
    });
  },

  refreshChats: async () => {
    if (!get().user) return;
    const data = await apiJson<{ chats: DirectConversation[] }>('/api/chats');
    set({ conversations: data.chats });
    const activeId = get().activeConversationId;
    if (activeId && data.chats.some((c) => c.id === activeId)) {
      const msgData = await apiJson<{ messages: ChatMessage[] }>(`/api/chats/${activeId}/messages`);
      set((s) => ({
        messagesByConversation: {
          ...s.messagesByConversation,
          [activeId]: msgData.messages,
        },
      }));
    }
  },

  refreshGifts: async () => {
    if (!get().user) return;
    const [catData, ownedData] = await Promise.all([
      apiJson<{ catalog: CatalogGift[] }>('/api/gifts/catalog'),
      apiJson<{ owned: OwnedGiftItem[] }>('/api/gifts/owned'),
    ]);
    set({
      giftCatalog: catData.catalog,
      ownedGifts: ownedData.owned,
    });
  },

  searchUsers: async (query) => {
    const q = query.trim();
    if (!q) return [];
    const data = await apiJson<{ users: PublicUser[] }>(
      `/api/users/search?q=${encodeURIComponent(q)}`
    );
    return data.users;
  },

  sendFriendRequest: async (userId) => {
    const data = await apiJson<{
      friends: PublicUser[];
      incomingRequests: FriendRequestItem[];
      outgoingRequests: FriendRequestItem[];
    }>('/api/friends/request', {
      method: 'POST',
      body: JSON.stringify({ userId }),
    });
    set({
      friends: data.friends,
      incomingRequests: data.incomingRequests,
      outgoingRequests: data.outgoingRequests,
    });
  },

  respondToFriendRequest: async (requestId, action) => {
    const data = await apiJson<{
      friends: PublicUser[];
      incomingRequests: FriendRequestItem[];
      outgoingRequests: FriendRequestItem[];
    }>('/api/friends/respond', {
      method: 'POST',
      body: JSON.stringify({ requestId, action }),
    });
    set({
      friends: data.friends,
      incomingRequests: data.incomingRequests,
      outgoingRequests: data.outgoingRequests,
    });
  },

  removeFriend: async (friendId) => {
    const data = await apiJson<{
      friends: PublicUser[];
      incomingRequests: FriendRequestItem[];
      outgoingRequests: FriendRequestItem[];
    }>(`/api/friends/${friendId}`, { method: 'DELETE' });
    set({
      friends: data.friends,
      incomingRequests: data.incomingRequests,
      outgoingRequests: data.outgoingRequests,
    });
  },

  openDirectChat: async (peerId) => {
    const data = await apiJson<{ chat: DirectConversation }>('/api/chats/direct', {
      method: 'POST',
      body: JSON.stringify({ peerId }),
    });
    set((s) => ({
      conversations: upsertConversationOrder(s.conversations, data.chat),
      activeSection: 'chats',
    }));
    await get().selectConversation(data.chat.id);
  },

  selectConversation: async (conversationId) => {
    set({ activeConversationId: conversationId });
    if (!conversationId) return;
    const data = await apiJson<{ messages: ChatMessage[] }>(
      `/api/chats/${conversationId}/messages`
    );
    set((s) => ({
      messagesByConversation: {
        ...s.messagesByConversation,
        [conversationId]: data.messages,
      },
      conversations: s.conversations.map((c) =>
        c.id === conversationId ? { ...c, unreadCount: 0 } : c
      ),
    }));
    await get().markConversationRead(conversationId);
  },

  sendMessage: async (conversationId, body, mediaUrl = null) => {
    const data = await apiJson<{ message: ChatMessage }>(`/api/chats/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ body, mediaUrl }),
    });
    set((s) => {
      const existing = s.messagesByConversation[conversationId] ?? [];
      const conv = s.conversations.find((c) => c.id === conversationId);
      const nextConvs = conv
        ? upsertConversationOrder(s.conversations, {
            ...conv,
            lastMessage: data.message,
            updatedAt: data.message.createdAt,
          })
        : s.conversations;
      return {
        messagesByConversation: {
          ...s.messagesByConversation,
          [conversationId]: mergeMessageDeduplicated(existing, data.message),
        },
        conversations: nextConvs,
      };
    });
  },

  markConversationRead: async (conversationId) => {
    try {
      await apiJson(`/api/chats/${conversationId}/read`, { method: 'POST' });
      set((s) => ({
        conversations: s.conversations.map((c) =>
          c.id === conversationId ? { ...c, unreadCount: 0 } : c
        ),
      }));
    } catch {
      // ignore transient read sync error
    }
  },

  updateProfile: async (payload) => {
    const data = await apiJson<{ user: AuthUser }>('/api/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    set({ user: data.user });
  },

  updateSettings: async (payload) => {
    const data = await apiJson<{ user: AuthUser }>('/api/settings', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    set({ user: data.user });
  },

  purchaseGift: async (catalogGiftId) => {
    const data = await apiJson<{ owned: OwnedGiftItem; coinsRemaining: number }>(
      '/api/gifts/purchase',
      {
        method: 'POST',
        body: JSON.stringify({ catalogGiftId }),
      }
    );
    set((s) => ({
      ownedGifts: [data.owned, ...s.ownedGifts],
      user: s.user ? { ...s.user, coins: data.coinsRemaining } : null,
    }));
    return data.owned;
  },

  sendGiftToFriend: async (recipientId, catalogGiftId, note) => {
    const data = await apiJson<{
      owned: OwnedGiftItem;
      coinsRemaining: number;
      conversationId: number;
      message: ChatMessage;
    }>('/api/gifts/send', {
      method: 'POST',
      body: JSON.stringify({ recipientId, catalogGiftId, note }),
    });
    set((s) => ({
      user: s.user ? { ...s.user, coins: data.coinsRemaining } : null,
      messagesByConversation: {
        ...s.messagesByConversation,
        [data.conversationId]: mergeMessageDeduplicated(
          s.messagesByConversation[data.conversationId] ?? [],
          data.message
        ),
      },
    }));
    await get().refreshChats();
  },

  upgradeGift: async (ownershipId) => {
    const data = await apiJson<{ owned: OwnedGiftItem; coinsRemaining: number }>(
      `/api/gifts/${ownershipId}/upgrade`,
      { method: 'POST' }
    );
    set((s) => ({
      ownedGifts: s.ownedGifts.map((g) => (g.id === ownershipId ? data.owned : g)),
      user: s.user ? { ...s.user, coins: data.coinsRemaining } : null,
    }));
  },

  connectWebSocket: () => {
    if (typeof window === 'undefined' || !get().user) return;
    if (activeWs && (activeWs.readyState === WebSocket.OPEN || activeWs.readyState === WebSocket.CONNECTING)) {
      return;
    }

    intentionalDisconnect = false;
    stopWsTimers();

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    activeWs = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'heartbeat' }));
      heartbeatTimer = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'heartbeat' }));
        }
      }, 8000);
    };

    ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data) as {
          type: string;
          userId?: number;
          isOnline?: boolean;
          lastSeenAt?: string | null;
          conversationId?: number;
          message?: ChatMessage;
          readerId?: number;
          lastReadMessageId?: number;
        };

        if (msg.type === 'presence:update' && typeof msg.userId === 'number') {
          const targetId = msg.userId;
          const nextOnline = Boolean(msg.isOnline);
          const nextLastSeen = msg.lastSeenAt ?? null;
          set((s) => ({
            friends: s.friends.map((f) =>
              f.id === targetId ? { ...f, isOnline: nextOnline, lastSeenAt: nextLastSeen } : f
            ),
            conversations: s.conversations.map((c) =>
              c.peer.id === targetId
                ? { ...c, peer: { ...c.peer, isOnline: nextOnline, lastSeenAt: nextLastSeen } }
                : c
            ),
            incomingRequests: s.incomingRequests.map((r) =>
              r.user.id === targetId
                ? { ...r, user: { ...r.user, isOnline: nextOnline, lastSeenAt: nextLastSeen } }
                : r
            ),
            outgoingRequests: s.outgoingRequests.map((r) =>
              r.user.id === targetId
                ? { ...r, user: { ...r.user, isOnline: nextOnline, lastSeenAt: nextLastSeen } }
                : r
            ),
            profileModalUser:
              s.profileModalUser && s.profileModalUser.id === targetId
                ? { ...s.profileModalUser, isOnline: nextOnline, lastSeenAt: nextLastSeen }
                : s.profileModalUser,
          }));
        } else if (msg.type === 'friend:updated') {
          await get().refreshFriends();
        } else if (msg.type === 'message:new' && msg.conversationId && msg.message) {
          const convId = msg.conversationId;
          const incoming = msg.message;
          const me = get().user;
          const isActiveChat =
            get().activeSection === 'chats' && get().activeConversationId === convId;
          const existingConv = get().conversations.find((c) => c.id === convId);

          set((s) => ({
            messagesByConversation: {
              ...s.messagesByConversation,
              [convId]: mergeMessageDeduplicated(s.messagesByConversation[convId] ?? [], incoming),
            },
            conversations: existingConv
              ? upsertConversationOrder(s.conversations, {
                  ...existingConv,
                  lastMessage: incoming,
                  unreadCount:
                    isActiveChat || incoming.senderId === me?.id
                      ? existingConv.unreadCount
                      : existingConv.unreadCount + 1,
                  updatedAt: incoming.createdAt,
                })
              : s.conversations,
          }));

          if (!existingConv) {
            await get().refreshChats();
          }
          if (isActiveChat && incoming.senderId !== me?.id) {
            await get().markConversationRead(convId);
          }
        } else if (msg.type === 'message:read' && msg.conversationId && msg.lastReadMessageId) {
          const convId = msg.conversationId;
          const maxId = msg.lastReadMessageId;
          const readerId = msg.readerId;
          set((s) => ({
            messagesByConversation: {
              ...s.messagesByConversation,
              [convId]: (s.messagesByConversation[convId] ?? []).map((m) =>
                m.id <= maxId && m.senderId !== readerId ? { ...m, deliveryStatus: 'read' } : m
              ),
            },
          }));
        } else if (msg.type === 'gift:received') {
          await get().refreshGifts();
        }
      } catch {
        // ignore malformed frames
      }
    };

    ws.onclose = () => {
      stopWsTimers();
      if (activeWs === ws) activeWs = null;
      if (!intentionalDisconnect && get().user) {
        reconnectTimer = setTimeout(() => {
          get().connectWebSocket();
          void get().refreshFriends();
          void get().refreshChats();
        }, 2000);
      }
    };
  },

  disconnectWebSocket: () => {
    intentionalDisconnect = true;
    stopWsTimers();
    if (activeWs) {
      try {
        activeWs.close(1000, 'Client disconnect');
      } catch {
        // ignore
      }
      activeWs = null;
    }
  },
}));
