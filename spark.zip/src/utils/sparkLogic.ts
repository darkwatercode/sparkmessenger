import type { AccessoryTransform, ChatMessage, DirectConversation } from '../types/spark';

export const DEFAULT_ACCESSORY_TRANSFORM: AccessoryTransform = {
  offsetX: 0,
  offsetY: 0,
  scale: 1,
  rotation: 0,
};

export const USERNAME_TAKEN_ERROR = 'This username is already taken.';
export const INVALID_CREDENTIALS_ERROR = 'Invalid username or password.';
export const USERNAME_NOT_FOUND_ERROR = 'No account found with this username.';
export const STALE_PRESENCE_MS = 18_000;

export const AVATAR_COLORS = [
  '#0F62FE',
  '#4589FF',
  '#198038',
  '#8A3FFC',
  '#D97706',
  '#0072C3',
  '#DA1E28',
];

export function normalizeUsername(raw: string): string {
  return raw.trim().toLowerCase();
}

export function getInitials(nameOrUsername: string): string {
  const cleaned = nameOrUsername.trim();
  if (!cleaned) return 'SP';
  const parts = cleaned.split(/[\s._-]+/).filter(Boolean);
  if (parts.length >= 2) {
    return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
  }
  return cleaned.slice(0, 2).toUpperCase();
}

export function pickAvatarColor(username: string): string {
  let hash = 0;
  for (let i = 0; i < username.length; i += 1) {
    hash = (hash * 31 + username.charCodeAt(i)) >>> 0;
  }
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export interface RegistrationValidationResult {
  valid: boolean;
  normalizedUsername: string;
  errors: {
    username?: string;
    password?: string;
    confirmPassword?: string;
  };
}

export function validateRegistrationInput(input: {
  username: string;
  password: string;
  confirmPassword: string;
}): RegistrationValidationResult {
  const normalizedUsername = normalizeUsername(input.username);
  const errors: RegistrationValidationResult['errors'] = {};

  if (!normalizedUsername) {
    errors.username = 'Username is required.';
  } else if (normalizedUsername.length < 3 || normalizedUsername.length > 24) {
    errors.username = 'Username must be between 3 and 24 characters.';
  } else if (!/^[a-z0-9][a-z0-9_.-]*$/.test(normalizedUsername)) {
    errors.username =
      'Username must start with a letter or number and only use letters, numbers, "_", ".", or "-".';
  }

  if (!input.password) {
    errors.password = 'Password is required.';
  } else if (input.password.length < 8) {
    errors.password = 'Password must be at least 8 characters.';
  } else if (input.password.length > 128) {
    errors.password = 'Password must be 128 characters or fewer.';
  }

  if (!input.confirmPassword) {
    errors.confirmPassword = 'Please confirm your password.';
  } else if (input.password !== input.confirmPassword) {
    errors.confirmPassword = 'Passwords do not match.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    normalizedUsername,
    errors,
  };
}

export function validateLoginInput(input: {
  username: string;
  password: string;
}): { valid: boolean; normalizedUsername: string; error?: string } {
  const normalizedUsername = normalizeUsername(input.username);
  if (!normalizedUsername) {
    return { valid: false, normalizedUsername, error: 'Enter your username.' };
  }
  if (!input.password) {
    return { valid: false, normalizedUsername, error: 'Enter your password.' };
  }
  return { valid: true, normalizedUsername };
}

export function getDirectConversationKey(userIdA: number, userIdB: number): string {
  const low = Math.min(userIdA, userIdB);
  const high = Math.max(userIdA, userIdB);
  return `${low}:${high}`;
}

export function computeEffectivePresence(
  params: {
    isOnline: boolean;
    lastHeartbeatAt: Date | string | number | null;
    lastSeenAt: Date | string | number | null;
    hideOnlineStatus: boolean;
    showLastSeen: boolean;
    nowMs?: number;
  },
  staleMs = STALE_PRESENCE_MS
): { isOnline: boolean; lastSeenAt: string | null } {
  if (params.hideOnlineStatus) {
    return { isOnline: false, lastSeenAt: null };
  }

  const now = params.nowMs ?? Date.now();
  const heartbeatMs = params.lastHeartbeatAt
    ? new Date(params.lastHeartbeatAt).getTime()
    : 0;
  const effectiveOnline = Boolean(params.isOnline && heartbeatMs > 0 && now - heartbeatMs <= staleMs);

  const lastSeenIso =
    params.showLastSeen && params.lastSeenAt
      ? new Date(params.lastSeenAt).toISOString()
      : null;

  return {
    isOnline: effectiveOnline,
    lastSeenAt: effectiveOnline ? null : lastSeenIso,
  };
}

export function formatLastSeen(lastSeenAt: string | null, isOnline: boolean, nowMs = Date.now()): string {
  if (isOnline) return 'Online';
  if (!lastSeenAt) return 'Offline';
  const diffSec = Math.max(0, Math.floor((nowMs - new Date(lastSeenAt).getTime()) / 1000));
  if (diffSec < 60) return 'Last seen just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `Last seen ${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `Last seen ${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  return `Last seen ${diffDays}d ago`;
}

export function formatMessageTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
}

export function mergeMessageDeduplicated(
  existing: ChatMessage[],
  incoming: ChatMessage
): ChatMessage[] {
  const index = existing.findIndex((m) => m.id === incoming.id);
  const next =
    index >= 0
      ? existing.map((m, idx) => (idx === index ? incoming : m))
      : [...existing, incoming];
  return [...next].sort((a, b) => a.id - b.id);
}

export function upsertConversationOrder(
  conversations: DirectConversation[],
  updated: DirectConversation
): DirectConversation[] {
  const filtered = conversations.filter((c) => c.id !== updated.id);
  return [updated, ...filtered].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

export function clampAccessoryTransform(transform: AccessoryTransform): AccessoryTransform {
  return {
    offsetX: Math.max(-20, Math.min(20, Math.round(transform.offsetX))),
    offsetY: Math.max(-20, Math.min(20, Math.round(transform.offsetY))),
    scale: Math.max(0.65, Math.min(1.45, Number(transform.scale.toFixed(2)))),
    rotation: Math.max(-45, Math.min(45, Math.round(transform.rotation))),
  };
}
