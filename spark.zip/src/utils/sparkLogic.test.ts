import assert from 'node:assert/strict';
import test from 'node:test';
import {
  computeEffectivePresence,
  formatLastSeen,
  getDirectConversationKey,
  mergeMessageDeduplicated,
  normalizeUsername,
  STALE_PRESENCE_MS,
  validateLoginInput,
  validateRegistrationInput,
} from './sparkLogic.ts';

test('normalizeUsername trims and lowercases cleanly', () => {
  assert.equal(normalizeUsername('  DarkWater  '), 'darkwater');
  assert.equal(normalizeUsername('Alice_99'), 'alice_99');
});

test('validateRegistrationInput validates username, password length, and confirmation', () => {
  const ok = validateRegistrationInput({
    username: 'DarkWater',
    password: 'strongpassword123',
    confirmPassword: 'strongpassword123',
  });
  assert.equal(ok.valid, true);
  assert.equal(ok.normalizedUsername, 'darkwater');

  const shortUser = validateRegistrationInput({
    username: 'ab',
    password: 'strongpassword123',
    confirmPassword: 'strongpassword123',
  });
  assert.equal(shortUser.valid, false);
  assert.ok(shortUser.errors.username);

  const badChars = validateRegistrationInput({
    username: 'bad user!',
    password: 'strongpassword123',
    confirmPassword: 'strongpassword123',
  });
  assert.equal(badChars.valid, false);
  assert.ok(badChars.errors.username);

  const shortPass = validateRegistrationInput({
    username: 'darkwater',
    password: '123',
    confirmPassword: '123',
  });
  assert.equal(shortPass.valid, false);
  assert.ok(shortPass.errors.password);

  const mismatch = validateRegistrationInput({
    username: 'darkwater',
    password: 'password123',
    confirmPassword: 'password456',
  });
  assert.equal(mismatch.valid, false);
  assert.equal(mismatch.errors.confirmPassword, 'Passwords do not match.');
});

test('validateLoginInput checks empty fields cleanly', () => {
  assert.equal(validateLoginInput({ username: '', password: 'secret' }).valid, false);
  assert.equal(validateLoginInput({ username: 'darkwater', password: '' }).valid, false);
  const ok = validateLoginInput({ username: '  DarkWater ', password: 'secret' });
  assert.equal(ok.valid, true);
  assert.equal(ok.normalizedUsername, 'darkwater');
});

test('getDirectConversationKey is order-independent', () => {
  assert.equal(getDirectConversationKey(12, 3), '3:12');
  assert.equal(getDirectConversationKey(3, 12), '3:12');
});

test('computeEffectivePresence respects stale heartbeat and hideOnlineStatus privacy', () => {
  const now = 1_700_000_000_000;
  const active = computeEffectivePresence({
    isOnline: true,
    lastHeartbeatAt: now - 5_000,
    lastSeenAt: now - 5_000,
    hideOnlineStatus: false,
    showLastSeen: true,
    nowMs: now,
  });
  assert.equal(active.isOnline, true);
  assert.equal(active.lastSeenAt, null);

  const stale = computeEffectivePresence({
    isOnline: true,
    lastHeartbeatAt: now - (STALE_PRESENCE_MS + 1_000),
    lastSeenAt: now - 25_000,
    hideOnlineStatus: false,
    showLastSeen: true,
    nowMs: now,
  });
  assert.equal(stale.isOnline, false);
  assert.ok(stale.lastSeenAt);

  const hidden = computeEffectivePresence({
    isOnline: true,
    lastHeartbeatAt: now - 1_000,
    lastSeenAt: now - 1_000,
    hideOnlineStatus: true,
    showLastSeen: true,
    nowMs: now,
  });
  assert.equal(hidden.isOnline, false);
  assert.equal(hidden.lastSeenAt, null);
});

test('formatLastSeen produces accurate human labels', () => {
  const now = 1_700_000_000_000;
  assert.equal(formatLastSeen(null, true, now), 'Online');
  assert.equal(formatLastSeen(null, false, now), 'Offline');
  assert.equal(formatLastSeen(new Date(now - 30_000).toISOString(), false, now), 'Last seen just now');
  assert.equal(formatLastSeen(new Date(now - 5 * 60_000).toISOString(), false, now), 'Last seen 5m ago');
});

test('mergeMessageDeduplicated prevents duplicates and sorts ascending', () => {
  const m1 = {
    id: 1,
    conversationId: 10,
    senderId: 1,
    body: 'First',
    giftCatalogId: null,
    giftOwnershipId: null,
    mediaUrl: null,
    deliveryStatus: 'sent' as const,
    createdAt: '2026-11-23T10:00:00Z',
  };
  const m2 = { ...m1, id: 2, body: 'Second' };
  const merged = mergeMessageDeduplicated([m2, m1], { ...m1, deliveryStatus: 'read' });
  assert.equal(merged.length, 2);
  assert.equal(merged[0].id, 1);
  assert.equal(merged[0].deliveryStatus, 'read');
  assert.equal(merged[1].id, 2);
});
